﻿# TODO: Translation updated at 2026-04-20 21:34

translate english strings:

    # game/screens.rpy:30
    old "致谢名单"
    new "Credits"

    # game/screens.rpy:38
    old "感谢所有支持我们的人！"
    new "Thank you to everyone who supported us!"

    # game/screens.rpy:42
    old "特别鸣谢："
    new "Special Thanks:"

    # game/screens.rpy:46
    old "91免费.apk!!!!!"
    new "91Free.apk!!!!!"

    # game/screens.rpy:52
    old "关闭"
    new "Close"

    # game/screens.rpy:315
    old "回退"
    new "Back"

    # game/screens.rpy:316
    old "历史"
    new "History"

    # game/screens.rpy:317
    old "快进"
    new "Skip"

    # game/screens.rpy:318
    old "自动"
    new "Auto"

    # game/screens.rpy:319
    old "保存"
    new "Save"

    # game/screens.rpy:320
    old "快存"
    new "Q.Save"

    # game/screens.rpy:321
    old "快读"
    new "Q.Load"

    # game/screens.rpy:322
    old "设置"
    new "Settings"

    # game/screens.rpy:361
    old "开始游戏"
    new "Start Game"

    # game/screens.rpy:369
    old "读取游戏"
    new "Load Game"

    # game/screens.rpy:375
    old "结束回放"
    new "End Replay"

    # game/screens.rpy:379
    old "标题菜单"
    new "Main Menu"

    # game/screens.rpy:381
    old "致谢"
    new "Credits"

    # game/screens.rpy:394
    old "帮助"
    new "Help"

    # game/screens.rpy:399
    old "退出"
    new "Quit"

    # game/screens.rpy:455
    old "致谢&介绍"
    new "Credits & Intro"

    # game/screens.rpy:460
    old "后日谈"
    new "Epilogue"

    # game/screens.rpy:464
    old "真实结局"
    new "True Ending"

    # game/screens.rpy:569
    old "返回"
    new "Return"

    # game/screens.rpy:652
    old "版本 [config.version!t]\n"
    new "Version [config.version!t]\n"

    # game/screens.rpy:658
    old "引擎：{a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]\n\n[renpy.license!t]"
    new "Engine: {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]\n\n[renpy.license!t]"

    # game/screens.rpy:693
    old "第 {} 页"
    new "Page {}"

    # game/screens.rpy:693
    old "自动存档"
    new "Auto Save"

    # game/screens.rpy:693
    old "快速存档"
    new "Quick Save"

    # game/screens.rpy:734
    old "{#file_time}%Y-%m-%d %H:%M"
    new "{#file_time}%Y-%m-%d %H:%M"

    # game/screens.rpy:734
    old "空存档位"
    new "Empty Slot"

    # game/screens.rpy:754
    old "<"
    new "<"

    # game/screens.rpy:758
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:761
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:767
    old ">"
    new ">"

    # game/screens.rpy:772
    old "上传同步"
    new "Upload Sync"

    # game/screens.rpy:776
    old "下载同步"
    new "Download Sync"

    # game/screens.rpy:834
    old "显示"
    new "Display"

    # game/screens.rpy:835
    old "窗口"
    new "Window"

    # game/screens.rpy:836
    old "全屏"
    new "Fullscreen"

    # game/screens.rpy:841
    old "Language/语言"
    new "Language"

    # game/screens.rpy:842
    old "中文/Chinese"
    new "Chinese"

    # game/screens.rpy:843
    old "英文/English"
    new "English"

    # game/screens.rpy:863
    old "关于作者"
    new "About Author"

    # game/screens.rpy:864
    old "作者bilibili"
    new "Author's Bilibili"

    # game/screens.rpy:865
    old "作者github"
    new "Author's GitHub"

    # game/screens.rpy:866
    old "作者抖音"
    new "Author's TikTok"

    # game/screens.rpy:867
    old "作者个人网站"
    new "Author's Website"

    # game/screens.rpy:868
    old "作者的X"
    new "Author's X"

    # game/screens.rpy:873
    old "未读文本"
    new "Unseen Text"

    # game/screens.rpy:874
    old "选项后继续"
    new "After Choices"

    # game/screens.rpy:875
    old "忽略转场"
    new "Skip Transitions"

    # game/screens.rpy:888
    old "文字速度"
    new "Text Speed"

    # game/screens.rpy:892
    old "自动前进时间"
    new "Auto-Forward Time"

    # game/screens.rpy:899
    old "音乐音量"
    new "Music Volume"

    # game/screens.rpy:906
    old "音效音量"
    new "Sound Volume"

    # game/screens.rpy:912
    old "测试"
    new "Test"

    # game/screens.rpy:916
    old "语音音量"
    new "Voice Volume"

    # game/screens.rpy:927
    old "全部静音"
    new "Mute All"

    # game/screens.rpy:1045
    old "尚无对话历史记录。"
    new "No dialogue history yet."

    # game/screens.rpy:1112
    old "键盘"
    new "Keyboard"

    # game/screens.rpy:1113
    old "鼠标"
    new "Mouse"

    # game/screens.rpy:1116
    old "手柄"
    new "Gamepad"

    # game/screens.rpy:1129
    old "回车"
    new "Enter"

    # game/screens.rpy:1130
    old "推进对话并激活界面。"
    new "Advance dialogue and activate interface."

    # game/screens.rpy:1133
    old "空格"
    new "Space"

    # game/screens.rpy:1134
    old "在没有选择的情况下推进对话。"
    new "Advance dialogue without selecting choices."

    # game/screens.rpy:1137
    old "方向键"
    new "Arrow Keys"

    # game/screens.rpy:1138
    old "导航界面。"
    new "Navigate interface."

    # game/screens.rpy:1141
    old "Esc"
    new "Esc"

    # game/screens.rpy:1142
    old "访问游戏菜单。"
    new "Access game menu."

    # game/screens.rpy:1146
    old "按住时快进对话。"
    new "Hold to skip dialogue."

    # game/screens.rpy:1149
    old "Tab"
    new "Tab"

    # game/screens.rpy:1150
    old "切换对话快进。"
    new "Toggle dialogue skipping."

    # game/screens.rpy:1153
    old "上一页"
    new "Page Up"

    # game/screens.rpy:1154
    old "回退至先前的对话。"
    new "Rollback to previous dialogue."

    # game/screens.rpy:1157
    old "下一页"
    new "Page Down"

    # game/screens.rpy:1158
    old "向前至后来的对话。"
    new "Roll forward to later dialogue."

    # game/screens.rpy:1162
    old "隐藏用户界面。"
    new "Hide user interface."

    # game/screens.rpy:1166
    old "截图。"
    new "Take screenshot."

    # game/screens.rpy:1170
    old "切换辅助{a=https://doc.renpy.cn/zh-CN/self_voicing.html}机器朗读{/a}。"
    new "Toggle assistive {a=https://www.renpy.org/doc/html/self_voicing.html}self-voicing{/a}."

    # game/screens.rpy:1174
    old "打开无障碍菜单。"
    new "Open accessibility menu."

    # game/screens.rpy:1180
    old "左键点击"
    new "Left Click"

    # game/screens.rpy:1184
    old "中键点击"
    new "Middle Click"

    # game/screens.rpy:1188
    old "右键点击"
    new "Right Click"

    # game/screens.rpy:1192
    old "鼠标滚轮上"
    new "Mouse Wheel Up"

    # game/screens.rpy:1196
    old "鼠标滚轮下"
    new "Mouse Wheel Down"

    # game/screens.rpy:1203
    old "右扳机键\nA/底键"
    new "Right Trigger\nA/Bottom Button"

    # game/screens.rpy:1207
    old "左扳机键\n左肩键"
    new "Left Trigger\nLeft Shoulder"

    # game/screens.rpy:1211
    old "右肩键"
    new "Right Shoulder"

    # game/screens.rpy:1215
    old "十字键，摇杆"
    new "D-Pad, Sticks"

    # game/screens.rpy:1219
    old "开始，向导，B/右键"
    new "Start, Guide, B/Right Button"

    # game/screens.rpy:1223
    old "Y/顶键"
    new "Y/Top Button"

    # game/screens.rpy:1290
    old "确定"
    new "OK"

    # game/screens.rpy:1291
    old "取消"
    new "Cancel"

    # game/screens.rpy:1336
    old "正在快进"
    new "Skipping"

    # game/screens.rpy:1644
    old "菜单"
    new "Menu"