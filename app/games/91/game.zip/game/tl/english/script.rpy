﻿# TODO: Translation updated at 2026-04-20 21:34

# game/script.rpy:16
translate english splashscreen_b5da12e9:

    # "@出来你那个喜欢看片的朋友"
    "@Bring out that friend of yours who likes watching porn."

# game/script.rpy:24
translate english start_5268d3a3:

    # "我叫苏月，是个普通的大学生。"
    "My name is Su Yue, an ordinary college student."

# game/script.rpy:25
translate english start_fa445a7b:

    # "一天，我在网上看到一个广告，声称可以提供免费的片。"
    "One day, I saw an ad online claiming to offer free porn."

# game/script.rpy:26
translate english start_6274e674:

    # sy "OS:这...."
    sy "OS: This..."

# game/script.rpy:27
translate english start_a295b283:

    # sy "😍"
    sy "😍"

# game/script.rpy:28
translate english start_181a34e1:

    # "我点击了广告，进入了一个看起来很....的网站。"
    "I clicked the ad and entered a website that looked very...."

# game/script.rpy:29
translate english start_d47d25cf:

    # f91 "欢迎来到91免费！我们提供最新最全的慌片！"
    f91 "Welcome to 91 Free! We provide the latest and most comprehensive porn!"

# game/script.rpy:30
translate english start_433cfbcd:

    # sy "(我去不早说)"
    sy "(Damn, why didn't you say so earlier)"

# game/script.rpy:31
translate english start_346bd292:

    # sy "让我看看"
    sy "Let me see."

# game/script.rpy:32
translate english start_85c16f4b:

    # "我随手点入了那个视频"
    "I casually clicked on the video."

# game/script.rpy:34
translate english start_955a9ae8:

    # "18岁的小萝莉被........."
    "18-year-old loli gets........."

# game/script.rpy:35
translate english start_27f81f21:

    # "我进去了"
    "I went in."

# game/script.rpy:36
translate english start_1aa3c67a:

    # sy "🤩"
    sy "🤩"

# game/script.rpy:37
translate english start_32cdae16:

    # "我看了几分钟，突然感觉有点不对劲。"
    "I watched for a few minutes, then suddenly felt something was off."

# game/script.rpy:38
translate english start_e3eae714:

    # sy "666这是什么"
    sy "WTF is this?"

# game/script.rpy:39
translate english start_05a97768:

    # sy "可以举报虚假宣传吗"
    sy "Can I report false advertising?"

# game/script.rpy:40
translate english start_a41c4bcf:

    # "只见,标题上写的萝莉,其实是一个成年男子的照片。"
    "Turns out, the 'loli' in the title was actually a photo of a grown man."

# game/script.rpy:41
translate english start_f8e573c2:

    # sy "这...."
    sy "This...."

# game/script.rpy:42
translate english start_597027ba:

    # sy "我直接拿那个筷子我******🤬"
    sy "I'm gonna grab those chopsticks and ******🤬"

# game/script.rpy:43
translate english start_a12892fc:

    # "此时的后台"
    "Meanwhile, behind the scenes"

# game/script.rpy:44
translate english start_3ea46e6a:

    # ht "哈哈哈，91免费就是这么牛逼！"
    ht "Hahaha, 91 Free is just that awesome!"

# game/script.rpy:45
translate english start_f8fc83c2:

    # ht "我们就是靠这种虚假宣传骗你的！"
    ht "We scam you with this exact kind of false advertising!"

# game/script.rpy:46
translate english start_e6eb2b4a:

    # ht "让你进入,然后,你的电脑或者手机被我们植入了木马病毒！"
    ht "Once you enter, your computer or phone gets infected with our Trojan virus!"

# game/script.rpy:47
translate english start_4536b76b:

    # ht "我们可以远程控制你的设备，窃取你的隐私，甚至勒索你！"
    ht "We can remotely control your device, steal your privacy, and even blackmail you!"

# game/script.rpy:48
translate english start_f3907005:

    # ht "😋😋😋"
    ht "😋😋😋"

# game/script.rpy:49
translate english start_32e6ef4c:

    # "我决定睡一觉，第二天再..."
    "I decided to sleep it off and check again tomorrow..."

# game/script.rpy:50
translate english start_1ec75529:

    # "看另一个"
    "Watch another one."

# game/script.rpy:51
translate english start_7f7bd59f:

    # "此时"
    "At this moment"

# game/script.rpy:52
translate english start_2d27decd:

    # ht "终于上当了😋"
    ht "Finally fell for it 😋"

# game/script.rpy:53
translate english start_1d0759cb:

    # ht "现在我们已经控制了你的设备了！"
    ht "We have now taken control of your device!"

# game/script.rpy:54
translate english start_c95da49e:

    # "那个91打开了我的银行"
    "That '91' guy opened my banking app"

# game/script.rpy:55
translate english start_2356836a:

    # bank "欢迎来到银行，请问有什么可以帮您？"
    bank "Welcome to the bank, how may I help you?"

# game/script.rpy:56
translate english start_c8699137:

    # sy2 "我...我想查询一下我的账户余额。"
    sy2 "I... I'd like to check my account balance."

# game/script.rpy:57
translate english start_c57bc6de:

    # bank "好的，请稍等一下。"
    bank "Alright, please hold on a moment."

# game/script.rpy:58
translate english start_5045594d:

    # "银行正在查询我的信息"
    "The bank is checking my information."

# game/script.rpy:59
translate english start_7c758a80:

    # bank "您的账户余额是100000元。"
    bank "Your account balance is 100,000 Yuan."

# game/script.rpy:60
translate english start_75f9f7de:

    # sy2 "好的😋"
    sy2 "Okay 😋"

# game/script.rpy:61
translate english start_b360a055:

    # sy2 "我...我想转账一下。"
    sy2 "I... I'd like to make a transfer."

# game/script.rpy:62
translate english start_68e442bd:

    # bank "好的，请问您要转账多少？"
    bank "Alright, how much would you like to transfer?"

# game/script.rpy:63
translate english start_b3dd74d5:

    # sy2 "我...我想转账50000元,到账户164238463271。"
    sy2 "I... I want to transfer 50,000 Yuan, to account 164238463271."

# game/script.rpy:64
translate english start_c57bc6de_1:

    # bank "好的，请稍等一下。"
    bank "Alright, please hold on a moment."

# game/script.rpy:65
translate english start_9c6706d1:

    # "银行正在处理我的请求"
    "The bank is processing my request."

# game/script.rpy:66
translate english start_86daf207:

    # bank "转账成功！"
    bank "Transfer successful!"

# game/script.rpy:67
translate english start_82f8a2b0:

    # bank "您的账户余额是50000元。"
    bank "Your remaining balance is 50,000 Yuan."

# game/script.rpy:68
translate english start_26a3d44b:

    # sy2 "好的,再转账50000元,到账户164238463271。"
    sy2 "Okay, transfer another 50,000 Yuan, to account 164238463271."

# game/script.rpy:69
translate english start_c57bc6de_2:

    # bank "好的，请稍等一下。"
    bank "Alright, please hold on a moment."

# game/script.rpy:70
translate english start_9c6706d1_1:

    # "银行正在处理我的请求"
    "The bank is processing my request."

# game/script.rpy:71
translate english start_86daf207_1:

    # bank "转账成功！"
    bank "Transfer successful!"

# game/script.rpy:72
translate english start_c3bfa750:

    # bank "您的账户余额是0元。"
    bank "Your account balance is 0 Yuan."

# game/script.rpy:73
translate english start_a9612543:

    # sy2 "好的😋,办理注销业务"
    sy2 "Great 😋, I'd like to close my account now."

# game/script.rpy:74
translate english start_145a53df:

    # bankkf "好的，请稍等一下。"
    bankkf "Alright, please hold on a moment."

# game/script.rpy:75
translate english start_9c6706d1_2:

    # "银行正在处理我的请求"
    "The bank is processing my request."

# game/script.rpy:76
translate english start_ccf23fec:

    # bankkf "注销成功！"
    bankkf "Account closure successful!"

# game/script.rpy:77
translate english start_9a3591ac:

    # bankkf "您的账户已经被注销了！现在,您将无法再使用这个账户了！"
    bankkf "Your account has been closed! You can no longer use this account!"

# game/script.rpy:78
translate english start_75f9f7de_1:

    # sy2 "好的😋"
    sy2 "Great 😋"

# game/script.rpy:79
translate english start_7d445905:

    # "第二天"
    "The Next Day"

# game/script.rpy:80
translate english start_529abcdd:

    # sy "额..."
    sy "Uh..."

# game/script.rpy:81
translate english start_05e84b7b:

    # "sy正在盯着自己的电脑"
    "Sy is staring at his computer."

# game/script.rpy:82
translate english start_c2355aea:

    # "只见,平常处于登录状态的银行网站突然弹出了一个登录界面。"
    "He saw that the bank website, which usually keeps him logged in, suddenly popped up a login screen."

# game/script.rpy:83
translate english start_1734cbcf:

    # sy "这是怎么回事？"
    sy "What's going on?"

# game/script.rpy:84
translate english start_a6736927:

    # "我输入了我的账户和密码，结果显示登录失败。"
    "I entered my account and password, but it showed login failed."

# game/script.rpy:85
translate english start_d5250f5b:

    # sy "这是怎么回事!!!!!!!!"
    sy "What the hell is going on!!!!!!!!"

# game/script.rpy:86
translate english start_3e5170bd:

    # "我试图重新登录，但每次都显示登录失败。"
    "I tried to log in again, but it failed every time."

# game/script.rpy:87
translate english start_fa1a1606:

    # "我开始怀疑自己的账户被盗了。"
    "I started to suspect my account had been stolen."

# game/script.rpy:88
translate english start_501a1475:

    # "我联系了一下客服"
    "I contacted customer service."

# game/script.rpy:89
translate english start_57887d2e:

    # bankkf "您好，这里是银行客服，请问有什么可以帮您？"
    bankkf "Hello, this is bank customer service. How can I help you?"

# game/script.rpy:90
translate english start_1441b8dd:

    # sy "你好，我的账户突然登录不上了，显示密码错误，能帮我查一下吗？"
    sy "Hi, I suddenly can't log into my account. It says wrong password. Can you check for me?"

# game/script.rpy:91
translate english start_2b103802:

    # bankkf "好的，请提供您的身份证号和姓名，我帮您核实一下信息。"
    bankkf "Sure, please provide your ID number and name so I can verify the information."

# game/script.rpy:92
translate english start_33ca7a41:

    # sy "我叫苏月，身份证号是......"
    sy "My name is Su Yue, ID number is......"

# game/script.rpy:93
translate english start_1761cfb2:

    # bankkf "好的，请稍等......"
    bankkf "Alright, please wait a moment......"

# game/script.rpy:94
translate english start_454d5a8e:

    # bankkf "您好，苏先生，根据系统显示，您的账户在今天凌晨3:30已经办理了注销业务。"
    bankkf "Hello, Mr. Su. According to our system, your account was closed at 3:30 AM today."

# game/script.rpy:95
translate english start_db06f3ae:

    # sy "什么？！"
    sy "What?!"

# game/script.rpy:96
translate english start_98e7bc9f:

    # "听见这个消息，我整个人都傻了。"
    "Hearing this news, I was completely dumbfounded."

# game/script.rpy:97
translate english start_85c7019d:

    # sy "注销？！我没有注销啊！我的钱呢？我卡里还有十万块钱呢！"
    sy "Closed?! I didn't close it! Where's my money? I had a hundred thousand Yuan in that account!"

# game/script.rpy:98
translate english start_6840ff40:

    # bankkf "根据记录，您的账户在注销前分两次转账了50000元到账户164238463271，余额为0后办理了注销。"
    bankkf "According to records, before closing, your account transferred 50,000 Yuan twice to account 164238463271. The account was closed after the balance reached zero."

# game/script.rpy:99
translate english start_def69967:

    # sy "不可能！我根本没操作过！我那时候在睡觉啊！"
    sy "Impossible! I didn't do any of that! I was sleeping!"

# game/script.rpy:100
translate english start_e90eecde:

    # bankkf "苏先生，请您冷静。这笔转账操作是通过您的设备进行的，IP地址也与您常用设备一致。如果您确定不是本人操作，建议您立即报警处理。"
    bankkf "Mr. Su, please calm down. These transfers were made from your device, and the IP address matches your usual device. If you are certain you didn't do this, I suggest you report it to the police immediately."

# game/script.rpy:101
translate english start_b97f805c:

    # sy "报警......对，报警！"
    sy "Police... Right, the police!"

# game/script.rpy:103
translate english start_7d445905_1:

    # "第二天"
    "The Next Day"

# game/script.rpy:104
translate english start_c6110950:

    # "警察给我了一个惊人的消息"
    "The police gave me some shocking news."

# game/script.rpy:105
translate english start_db8b6936:

    # pol1 "苏先生，我们已经找到您的设备了。"
    pol1 "Mr. Su, we have located your device."

# game/script.rpy:106
translate english start_45172a93:

    # pol2 "是的，您的设备被黑客远程控制了。"
    pol2 "Yes, your device was remotely controlled by a hacker."

# game/script.rpy:107
translate english start_db06f3ae_1:

    # sy "什么？！"
    sy "What?!"

# game/script.rpy:108
translate english start_f92621b3:

    # pol1 "根据我们的调查，黑客通过一个钓鱼网站获取了您的信息。"
    pol1 "According to our investigation, the hacker obtained your information through a phishing website."

# game/script.rpy:109
translate english start_eea5bc66:

    # pol2 "然后利用这些信息对您的账户进行了操作。"
    pol2 "Then used that information to access and operate your account."

# game/script.rpy:110
translate english start_e4ec86e8:

    # sy "这......"
    sy "This..."

# game/script.rpy:111
translate english start_016da28d:

    # sy "我该怎么办？"
    sy "What should I do?"

# game/script.rpy:112
translate english start_4f0e069e:

    # pol1 "我们建议您立即更改所有账户的密码，并启用双重验证。"
    pol1 "We recommend you immediately change passwords for all your accounts and enable two-factor authentication."

# game/script.rpy:113
translate english start_63e6e379:

    # pol2 "同时，我们会对这个案件进行进一步调查。"
    pol2 "Meanwhile, we will conduct a further investigation into this case."

# game/script.rpy:114
translate english start_166e7d00:

    # "完"
    "The End"

# game/script.rpy:116
translate english start_226c06f5:

    # "真实事件改编!"
    "Based on a true story!"

# game/script.rpy:117
translate english start_d0ffeea0:

    # "对,就是我"
    "Yes, it happened to me."

# game/script.rpy:118
translate english start_48ef5f04:

    # "我的经历告诉我,网络安全真的很重要！"
    "My experience tells me, online security is really important!"