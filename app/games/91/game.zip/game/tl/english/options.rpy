﻿# TODO: Translation updated at 2026-04-20 21:34

translate english strings:

    # game/options.rpy:14
    old "兄弟你不要看片了!!!!"
    new "Bro, Stop Watching Porn!!!!"

    # game/options.rpy:30
    old "我的好兄弟\n\n不要再看片了\n\n91免费😋😍🤩\n\n是假的\n\n不要再被骗了\n\n作者:ciallo0721-cmd\n\n岛管,兄弟们,开导\n\n"
    new "My dear brother\n\nStop watching porn\n\n91 Free 😋😍🤩\n\nis FAKE\n\nDon't get scammed again\n\nAuthor: ciallo0721-cmd\n\n*Bonk*, go to horny jail\n\n"