# after.rpy - 病娇契约后日谈
# 版本：1.0
# 作者：墨羽
# 日期：2025年12月

# 后日谈相关变量（已经在script.rpy中定义，这里只做引用）
# 注意：这些变量在script.rpy中已经用default定义过了
# default persistent.afterstory_unlocked = False
# default persistent.special_mode_unlocked = False
# default persistent.true_ending_unlocked = False
# default persistent.secret_counter = 0
# default persistent.ending_collection = []
# default persistent.photo_gallery = []

init python:
    # 后日谈解锁条件
    def check_afterstory_unlock():
        # 解锁条件：完成至少一个结局
        if persistent.ending_unlocked:
            persistent.afterstory_unlocked = True
        return persistent.afterstory_unlocked
    
    # 特别模式解锁条件检查
    def check_special_mode_unlock():
        required_endings = ["healing", "professional", "reject", "redemption"]
        if all(ending in persistent.ending_collection for ending in required_endings):
            if persistent.secret_counter >= 4:
                persistent.special_mode_unlocked = True
        return persistent.special_mode_unlocked

# 后日谈主菜单入口
label after_story_main:
    scene bg black
    with dissolve
    
    "后日谈 - 那些结束之后的故事"
    
    if not persistent.afterstory_unlocked:
        "后日谈内容尚未解锁。"
        "请先完成至少一个游戏结局。"
        return
    
    menu:
        "选择要观看的后日谈："
        
        "治愈结局后日谈" if "healing" in persistent.ending_collection:
            jump after_healing
        
        "专业结局后日谈" if "professional" in persistent.ending_collection:
            jump after_professional
        
        "拒绝结局后日谈" if "reject" in persistent.ending_collection:
            jump after_reject
        
        "救赎结局后日谈" if "redemption" in persistent.ending_collection:
            jump after_redemption
        
        "特别模式" if persistent.special_mode_unlocked:
            jump special_mode_intro
        
        "返回":
            return

# 治愈结局后日谈
label after_healing:
    scene bg park
    show a happy at center
    play music bgm_gentle fadein 2.0
    
    "半年后，春季，同一个公园。"
    
    a "时间过得真快呢，已经半年了。"
    a "樱花又开了，和去年一样美。"
    
    "我们并肩坐在长椅上，看着飘落的樱花瓣。"
    
    a "还记得去年这时候吗？我们第一次在这里见面。"
    a "那时候的我，好紧张，又好期待。"
    
    menu:
        "我记得很清楚":
            show a love at center
            a "我也是……每一个细节都记得。"
            a "你穿着灰色外套，提前到了半小时。"
        
        "那时候的你好可爱":
            show a shy at center
            a "别、别说出来啊……"
            a "不过，谢谢你还记得。"
        
        "我们已经走了好远":
            show a smile at center
            a "是啊……从互相伤害，到互相治愈。"
            a "这条路，我们一起走过来的。"
    
    "她轻轻靠在我的肩上。"
    
    a "心理医生说，我的情况稳定了很多。"
    a "虽然还是会有不安的时候，但已经能控制了。"
    a "谢谢你……一直陪在我身边。"
    
    "我握住了她的手。"
    
    menu:
        "我会一直陪着你":
            show a love at center
            a "嗯……我相信。"
            a "这次，我真的相信了。"
        
        "我们一起成长":
            show a happy at center
            a "嗯！我们一起变得更好。"
            a "不是为了别人，是为了我们自己。"
    
    nvl clear
    scene bg chat
    
    nvl_pf "兄弟，最近怎么样？"
    nvl_player "挺好的，在慢慢变好"
    nvl_pf "听说你们还在接受心理咨询？"
    nvl_player "嗯，但现在是定期维护，不是治疗了"
    nvl_pf "为你骄傲，真的"
    nvl_player "谢谢，这多亏了有你们这些朋友"
    
    nvl clear
    nvl_af "小雅，最近状态不错啊"
    nvl_a "嗯，工作也顺利，感情也稳定"
    nvl_af "看到你这样，真好"
    nvl_a "谢谢关心，我会继续努力的"
    
    nvl clear
    scene bg cafe
    show a normal at center
    
    "咖啡馆里，我们相对而坐。"
    
    a "其实……有件事我想告诉你。"
    a "我联系了小雨。"
    
    menu:
        "惊讶":
            "为什么？"
            show a sad at center
            a "因为想正式道歉，也为当年的事做个了结。"
        
        "理解":
            "这样也好，是该有个正式的结束。"
            show a smile at center
            a "嗯，你理解我……"
    
    a "我们聊了很久。"
    a "她说她也成长了很多，现在有了新的感情。"
    a "我祝福了她……真心地。"
    a "嫉妒和不安，终于能放下了。"
    
    "她端起咖啡杯，手很稳。"
    
    a "这不是原谅，而是释怀。"
    a "为了我自己，也为了我们能更好前行。"
    
    menu:
        "你变得坚强了":
            show a happy at center
            a "是因为有你在身边啊。"
            a "因为你让我相信，被爱不需要害怕。"
        
        "我们都在成长":
            show a smile at center
            a "嗯，我们都在成为更好的自己。"
            a "不是为了对方，是为了自己。"
    
    "夕阳透过窗户洒进来，给她的侧脸镀上金边。"
    
    a "以后……我们还会遇到各种困难吧。"
    a "但没关系，我们一起面对。"
    a "因为现在的我们，已经学会了如何爱，也学会了如何被爱。"
    
    "治愈结局·后日谈 完"
    "【真正的治愈，是带着伤痕依然勇敢去爱】"
    
    $ persistent.secret_counter += 1
    jump after_story_end

# 专业结局后日谈
label after_professional:
    scene bg hospital
    show doctor normal at center
    play music bgm_memory fadein 2.0
    
    "一年后，心理诊所。"
    
    doctor "最近感觉怎么样？"
    
    "我坐在咨询室里，这是第32次咨询。"
    
    menu:
        "稳定了很多":
            "情绪波动少了很多，能正常工作和社交了。"
            doctor "很好，这是很大的进步。"
        
        "还在适应":
            "有时候还是会突然情绪低落，但能控制了。"
            doctor "这很正常，康复是个过程。"
    
    doctor "你知道她最近的情况吗？"
    
    menu:
        "知道一点":
            "听说她也在接受治疗，恢复得不错。"
            doctor "是的，你们分开治疗，但都在进步。"
        
        "没联系了":
            "我们约定暂时不联系，各自专注治疗。"
            doctor "这是明智的选择。"
    
    doctor "心理咨询不只是解决问题，更是重新认识自己。"
    doctor "你们都在学习健康的爱与被爱。"
    
    "窗外的阳光很温暖。"
    
    nvl clear
    scene bg chat
    
    nvl_pf "兄弟，咨询还在继续？"
    nvl_player "嗯，快一年了"
    nvl_pf "有效果吗？"
    nvl_player "有，开始理解自己为什么会有那些行为"
    nvl_pf "为你骄傲"
    nvl_player "谢谢，我也为自己骄傲"
    
    nvl clear
    scene bg park
    show a conflicted at center
    
    "偶然在公园遇见她。"
    "她没有看到我，正坐在长椅上画素描。"
    
    "画的是樱花树，笔触温柔而坚定。"
    
    "她的表情很平静，专注而认真。"
    
    "我没有上前打招呼，只是远远看着。"
    "然后转身离开，给她也给自己空间。"
    
    "有些相遇，不一定要有对话。"
    "有些离别，也不一定要有仪式。"
    
    "我们都在各自的轨道上，向着更好的方向前行。"
    "这就够了。"
    
    scene bg room
    "夜晚，我翻开日记本。"
    
    "『2024年4月27日，晴』"
    "『今天在公园看到她了，在画画。』"
    "『没有上前，但心里很平静。』"
    "『我们都还在治愈的路上，但方向是对的。』"
    "『这就够了。』"
    
    "专业结局·后日谈 完"
    "【各自安好，便是最好的结局】"
    
    $ persistent.secret_counter += 1
    jump after_story_end

# 拒绝结局后日谈
label after_reject:
    scene bg city_rain
    play music bgm_sad fadein 2.0
    
    "两年后，雨夜。"
    
    "我独自走在回家的路上。"
    "雨不大，但很密，像记忆的网。"
    
    "手机震动，是陌生号码。"
    "接通，那边是久违的声音。"
    
    a "是我……"
    a "别挂，就说几句话。"
    
    menu:
        "你说":
            "听筒里传来她的呼吸声。"
        
        "什么事？":
            a "没什么事，就是……想听听你的声音。"
    
    a "我下个月要出国了，去法国学艺术。"
    a "去很久，也许不回来了。"
    
    menu:
        "恭喜你":
            a "谢谢……"
            a "这两年在国外治疗，学到了很多。"
        
        "一路平安":
            a "嗯，你也是。"
            a "要照顾好自己。"
    
    a "那年的事……我想正式道歉。"
    a "对不起，用伤害的方式表达爱。"
    a "对不起，让你经历了那些痛苦。"
    
    "雨声在耳边淅沥。"
    
    a "也谢谢你……"
    a "谢谢你让我明白，爱不应该以伤害为代价。"
    a "谢谢你让我有勇气面对自己的问题。"
    
    menu:
        "我也该道歉":
            "对不起，用欺骗的方式逃避问题。"
            "对不起，伤害了你而不自知。"
        
        "我们都成长了":
            "是的，我们都付出了代价，也都有所成长。"
            "这也许就是那段关系的意义。"
    
    a "那就……到这里吧。"
    a "再见，或者再也不见。"
    a "祝你……幸福。"
    
    "电话挂断了。"
    "雨还在下。"
    
    "我收起伞，让雨淋在脸上。"
    "分不清是雨水还是泪水。"
    
    "有些告别，不需要仪式。"
    "有些释怀，不需要原谅。"
    
    "只是放下，然后前行。"
    
    scene bg room
    "几天后，收到一封邮件。"
    
    "发件人：xiaoya.art@bjqy.com"
    "主题：最后一幅画"
    
    "附件是一幅素描。"
    "画的是雨中撑伞的背影，渐行渐远。"
    
    "画名：《告别与开始》"
    
    "拒绝结局·后日谈 完"
    "【有些爱，结束比继续更需要勇气】"
    
    $ persistent.secret_counter += 1
    jump after_story_end

# 救赎结局后日谈
label after_redemption:
    scene bg wedding
    play music bgm_love fadein 2.0
    
    "三年后，教堂。"
    
    "我穿着西装，站在红毯的一端。"
    "手心有些汗，心跳很快。"
    
    "音乐响起，门打开了。"
    
    show a love at center
    with dissolve
    
    "她穿着白色婚纱，美得不真实。"
    "手里捧着一束蓝色绣球花。"
    
    "一步一步，向我走来。"
    "每一步，都是这三年的点点滴滴。"
    
    "第一次争吵后的彻夜长谈。"
    "第一次共同完成的咨询作业。"
    "第一次不再为晚归而焦虑。"
    "第一次真正信任的微笑。"
    
    "她走到我面前，眼眶微红。"
    
    a "我来了。"
    a "让你久等了。"
    
    menu:
        "值得等待":
            "多久都值得。"
            show a happy at center
            a "我也是。"
        
        "我们终于走到了这里":
            "是啊，终于。"
            show a smile at center
            a "一起走过来的。"
    
    "神父开始念誓词。"
    
    "『你是否愿意娶/嫁这个女人/男人为妻，』"
    "『无论贫穷还是富有，疾病还是健康，』"
    "『都爱她/他，照顾她/他，尊重她/他，接纳她/他，』"
    "『永远对她/他忠贞不渝直至生命尽头？』"
    
    "我们同时开口。"
    
    "『我愿意。』"
    
    "声音重叠，坚定而清晰。"
    
    "交换戒指时，她的手在微微颤抖。"
    "我的也是。"
    
    "不是紧张，是感动。"
    
    "『现在我宣布你们成为夫妻。』"
    "『新郎可以亲吻新娘了。』"
    
    "我掀开她的头纱。"
    "她的眼睛里闪烁着泪光。"
    
    "轻轻吻上去。"
    "温柔而珍重。"
    
    scene bg reception
    "婚宴上，朋友们围坐一桌。"
    
    show pf normal at left
    show af normal at right
    
    pf "真没想到会有这一天。"
    pf "看到你们这样，真好。"
    
    af "小雅变了好多。"
    af "不再是那个躲在阴影里的小女孩了。"
    
    show a shy at center
    a "别取笑我啦……"
    a "不过，谢谢你们一直以来的支持。"
    
    "她看向我，眼中满是温柔。"
    
    a "也谢谢你……"
    a "没有放弃我，也没有放弃我们。"
    
    menu:
        "因为爱你":
            "所以愿意陪你走这段路。"
            show a love at center
            a "我也是……"
            a "因为爱你，所以愿意改变。"
        
        "我们值得幸福":
            "我们都值得被爱，也值得幸福。"
            show a happy at center
            a "嗯！我们值得。"
    
    "婚礼进行曲再次响起。"
    "我们在舞池中央，相拥而舞。"
    
    a "还记得第一次跳舞吗？"
    a "在我家客厅，你踩了我好多次脚。"
    
    menu:
        "记得":
            "你还说我是舞蹈白痴。"
            show a smile at center
            a "现在进步多了呢。"
        
        "现在不会踩到了":
            "练习了很久。"
            show a happy at center
            a "为了今天，对吧？"
    
    "音乐渐缓，我们停在舞池中央。"
    
    a "以后的日子，请多关照。"
    
    "救赎结局·后日谈 完"
    "【爱情最美的样子，是两个人都成为更好的自己】"
    
    $ persistent.secret_counter += 1
    jump after_story_end

# 特别模式介绍
label special_mode_intro:
    scene bg black
    with dissolve
    
    "特别模式 - 开发者的话"
    
    "欢迎来到特别模式。"
    "这里是一些开发过程中的心路历程，还有一些未能放进正式版的内容。"
    
    menu:
        "开发心路历程":
            jump developer_diary
        
        "被删除的内容":
            jump deleted_content
        
        "游戏设计理念":
            jump design_philosophy
        
       
        
        "返回":
            jump after_story_main

# 开发者日记
label developer_diary:
    scene bg desk
    play music bgm_memory fadein 2.0
    
    "《病娇契约》开发日记摘录"
    
    nvl clear
    nvl_narrator "2025年10月3日"
    nvl_narrator "今天开始构思这个游戏。"
    nvl_narrator "想做一个不一样的病娇游戏，不只是恐怖，更想探讨创伤与治愈。"
    nvl_narrator "小雅这个角色，我想让她不只是反派，更是一个需要被理解的人。"
    
    nvl clear
    nvl_narrator "2025年10月5日"
    nvl_narrator "写到背叛被发现的那段时，心里很难受。"
    nvl_narrator "伤害和被伤害，有时候是同时发生的。"
    nvl_narrator "希望玩家能感受到这种复杂性。"
    
    nvl clear
    nvl_narrator "2025年11月28日"
    nvl_narrator "增强版的想法出现了。"
    nvl_narrator "想让游戏更有沉浸感，但也要小心不要太过火。"
    nvl_narrator '移除了摄像头功能，觉得那样有点侵犯隐私了。'
    nvl_narrator "游戏是游戏，现实是现实，要保持界限。"
    
    nvl clear
    nvl_narrator "2025年12月20日"
    nvl_narrator "写完最后一个结局，有点感慨。"
    nvl_narrator "希望每个玩家都能在游戏里找到一些思考。"
    nvl_narrator "关于爱，关于责任，关于如何在不伤害彼此的情况下相爱。"
    
    nvl clear
    scene bg black
    "开发日记 完"
    
    jump special_mode_intro

# 被删除的内容
label deleted_content:
    scene bg monitors
    play music bgm_dark fadein 2.0
    
    "被删除的内容"
    
    "最初的设计中，有一些内容因为种种原因被移除了："
    
    "1. 摄像头监控系统"
    "   原计划有小雅通过摄像头实时监视玩家的剧情。"
    "   考虑到隐私问题，最终移除了。"
    
    "2. 更极端的系统入侵"
    "   原计划有修改玩家桌面背景、锁屏等更侵入性的内容。"
    "   觉得太过分了，可能会让玩家不舒服。"
    
    "3. 更突破第四面墙的互动"
    " 在原作中,我想让小雅访问摄像头或者麦克风。"
    "   隐私风险太大，最后只能访问摄像头了。"
    
    "4. 设计不可描述的场景"
    "   原计划有一些场景无法公开，考虑到玩家的接受度，最终决定不加入。"
    "   这些场景虽然有趣，但可能会引发不适。"

    "5 . 政治内容"
    "   最初想加入一些政治隐喻和评论，后来觉得不合适。"
    "   因为这个,我还被一些审查制度困扰过。"
    
    "删除这些内容，是希望游戏能在冲击性和舒适性之间找到平衡。"
    
    jump special_mode_intro

# 设计理念
label design_philosophy:
    scene bg classroom
    play music bgm_gentle fadein 2.0
    
    "游戏设计理念"
    
    "《病娇契约》有几个核心设计理念："
    
    "1. 打破第四面墙"
    "   希望通过系统交互，让玩家更有沉浸感。"
    "   但也要保持游戏和现实的界限。"
    
    "2. 角色的复杂性"
    "   小雅不是纯粹的反派，主角也不是纯粹的受害者。"
    "   每个人都有自己的创伤和问题。"
    
    "3. 选择的分量"
    "   每个选择都会影响剧情走向和结局。"
    "   希望玩家认真对待自己的选择。"
    
    "4. 治愈的可能性"
    "   即使是创伤性的关系，也有治愈的可能。"
    "   但不是所有关系都值得挽救。"
    
    "5. 现实的警示"
    "   游戏虽然是虚构的，但病娇和控制行为在现实中是真实存在的。"
    "   希望游戏能让玩家警惕不健康的关系。"
    
    jump special_mode_intro


# 后日谈结束
label after_story_end:
    scene bg black
    
    "后日谈观看结束。"
    
    if persistent.secret_counter >= 4:
        if not persistent.special_mode_unlocked:
            $ persistent.special_mode_unlocked = True
            "恭喜！你已观看所有后日谈内容。"
            "特别模式已解锁。"
        else:
            "所有后日谈内容已观看。"
    else:
        "还有后日谈内容尚未观看。"
        "完成更多结局以解锁。"
    
    return

# 真实结局 - 需要完成所有内容
label true_ending:
    if not persistent.special_mode_unlocked:
        "真实结局尚未解锁。"
        "请先完成所有结局，观看所有后日谈，并解锁特别模式。"
        return
    
    scene bg white
    show a normal at center
    with dissolve
    
    play music bgm_gentle fadein 3.0
    
    a "感谢你体验《病娇契约》的全部内容。"
    a "从开始到现在，我们走过了很长的路。"
    
    "她的形象开始变得模糊，像是要消失。"
    
    a "游戏到这里，是真的要结束了。"
    a "但我想在最后，以开发者的身份说几句话。"
    
    "我是这个游戏的开发者之一。"
    "小雅这个角色，寄托了很多对创伤与治愈的思考。"
    "希望这个游戏能让你有所思考，有所收获。"
    
    "关于爱，关于伤害，关于成长。"
    "关于如何在不完美中寻找完美。"
    "关于如何在伤痛后重新开始。"
    
    "游戏中的系统交互，是希望增强沉浸感。"
    "但请记住，游戏中的行为在现实中是不可取的。"
    "健康的爱，应该建立在尊重和信任的基础上。"
    
    "如果你或你认识的人正在经历类似的关系问题，"
    "请勇敢地寻求帮助。"
    "心理咨询师、信任的朋友、家人……"
    "都会是很好的支持。"
    
    "最后，"
    "感谢你花时间体验这个故事。"
    "希望它能留在你的记忆里，"
    "成为一段特别的经历。"
    
    "再见了，玩家。"
    "祝你，在现实中，找到健康而美好的爱。"
    
    hide a
    with dissolve
    
    scene bg black
    with dissolve
    
    "真实结局 达成"
    "【游戏结束，但思考与成长永远继续】"
    
    $ persistent.true_ending_unlocked = True
    
    return




label ceshitest_a1:
    "这是一个测试"
    "正常来说你应该看不见这句话"
    "开发者用"
    "11111"
    "这是一条新添加的测试信息。"
    a "12345678"
    y "12345678"
    af "12345678"
    pf "12345678"
    machine "12345678"
    doctor "12345678"
    
    nvl_doctor "12345678"
    nvl_pf "12345678"
    nvl_af "12345678"
    nvl_a "12345678"
    nvl_player "12345678"
    nvl_y "12345678"
    nvl_narrator "12345678"
    nvl clear


    "没人了"
    "其实这个游戏并没有什么彩蛋"
    "这是一个额外的测试信息。"
    
    return