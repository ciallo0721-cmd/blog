﻿#病娇契约完整版-增强版
#ciallo
#ps:之前本来想用unity做的
#但是破电脑发力了
#所以就用renpy做了
#2025年12月2日
#增强版更新：2025年12月11日
#后日谈更新：2025年12月21日

#define角色
define a = Character("小雅", what_color="#fff")
define machine = Character("系统", what_color="#0ff")
define y = Character("小雨", what_color="#6cf")
define af = Character("小雅朋友", what_color="#f9f")
define pf = Character("主角朋友", what_color="#9f9")
define doctor = Character("心理医生", what_color="#9cf")

#NVL
define nvl_y = Character("小雨", kind=nvl, what_color="#6cf")
define nvl_player = Character("我", kind=nvl, what_color="#9f9")
define nvl_a = Character("小雅", kind=nvl, what_color="#fff")
define nvl_af = Character("小雅朋友", kind=nvl, what_color="#f9f")
define nvl_pf = Character("主角朋友", kind=nvl, what_color="#9f9")
define nvl_doctor = Character("心理医生", kind=nvl, what_color="#9cf")

#音效和音乐
define audio.bgm_main = "audio/gentle.ogg"  
define audio.bgm_gentle = "audio/gentle.ogg" 
define audio.bgm_sad = "audio/sad.ogg"  
define audio.bgm_crazy = "audio/crazy.ogg"
define audio.bgm_dark = "audio/dark.ogg"
define audio.bgm_love = "audio/love.ogg"
define audio.bgm_memory = "audio/memory.ogg"

#持久化变量
default persistent.camera_permission = False
default persistent.location_permission = False
default persistent.quit_count = 0
default persistent.recorded_video = False
default persistent.accepted_disclaimer = False
default persistent.game_progress = 0
default persistent.dialogue_count = 0
default persistent.intimacy_level = 0
default persistent.seen_dialogues = []
default persistent.puzzles_solved = 0
default persistent.secrets_found = 0
default persistent.ending_unlocked = False
default persistent.first_run_time = 0
default persistent.betrayal_discovered = False
default persistent.other_lover_name = ""
default persistent.betrayal_time = 0
default persistent.relationship_days = 0
default persistent.microphone_permission = False
default persistent.screenshot_permission = False

#后日谈相关变量
default persistent.afterstory_unlocked = False
default persistent.special_mode_unlocked = False
default persistent.true_ending_unlocked = False
default persistent.secret_counter = 0
default persistent.ending_collection = []
default persistent.photo_gallery = []

#临时变量
default current_location = "未知"
default is_recording = False
default computer_name = "玩家"
default player_name = ""
default last_dialogue_time = 0.0
default current_chapter = 1
default found_clues = []
default current_puzzle = None
default puzzle_solved = False
default diary_pages = 0
default locker_code = ""
default mirror_broken = False
default basement_key = False
default final_choice = None
default locker_wrong_count = 0
default found_diary_hint = False
default locker_opened = False
default chapter1_completed = False
default chapter2_completed = False
default betrayal_stage = 0
default jealousy_level = 0
default mental_state = "normal"
default system_scan_complete = False
default ip_address_found = ""
default antivirus_detected = False

#角色背景和关系发展变量
default player_loneliness_level = 0
default player_insecurity_level = 0
default a_abandonment_trauma = True
default a_previous_betrayal = True
default a_parents_divorced = True
default player_family_issues = True
default first_meet_date = "2023-03-15"
default first_date_date = "2023-04-27"
default relationship_start_date = "2023-05-20"
default betrayal_start_date = "2023-08-10"
default current_story_date = "2023-03-15"
default relationship_phase = "initial"

#立绘(表情包)
image a normal = Text("😊 小雅", size=40, color="#fff")
image a yandere = Text("😈 小雅", size=40, color="#f00")
image a crazy = Text("👹 小雅", size=40, color="#c00")
image a smile = Text("😄 小雅", size=40, color="#ff6")
image a demon = Text("👿 小雅", size=40, color="#600")
image a suspicious = Text("🤨 小雅", size=40, color="#f90")
image a ghost = Text("👻 小雅", size=40, color="#ccc")
image a happy = Text("😊 小雅", size=40, color="#fff")
image a angry = Text("😠 小雅", size=40, color="#f00")
image a sad = Text("😢 小雅", size=40, color="#66f")
image a love = Text("😍 小雅", size=40, color="#f6f")
image a broken = Text("💔 小雅", size=40, color="#f66")
image a conflicted = Text("😔 小雅", size=40, color="#99f")
image a shy = Text("😳 小雅", size=40, color="#fcc")
image a worried = Text("😟 小雅", size=40, color="#ccf")

image y normal = Text("😊 小雨", size=40, color="#6cf")
image y sad = Text("😢 小雨", size=40, color="#6cf")
image y angry = Text("😠 小雨", size=40, color="#6cf")
image y shocked = Text("😲 小雨", size=40, color="#6cf")
image y happy = Text("😄 小雨", size=40, color="#6cf")

image af normal = Text("😊 小雅朋友", size=40, color="#f9f")
image af worried = Text("😟 小雅朋友", size=40, color="#f9f")

image pf normal = Text("😊 主角朋友", size=40, color="#9f9")
image pf serious = Text("😐 主角朋友", size=40, color="#9f9")

image doctor normal = Text("👨‍⚕️ 心理医生", size=40, color="#9cf")

#背景
image bg black = Solid("#000")
image bg white = Solid("#fff")
image bg room = Solid("#346856")
image bg room_dark = Solid("#123456")
image bg desk = Solid("#567890")
image bg bed = Solid("#789abc")
image bg locker = Solid("#456789")
image bg corridor = Solid("#567890")
image bg classroom = Solid("#4682B4")
image bg bathroom = Solid("#345678")
image bg basement = Solid("#223344")
image bg computer = Solid("#334455")
image bg monitors = Solid("#445566")
image bg ending_good = Solid("#006600")
image bg ending_bad = Solid("#660000")
image bg ending_hidden = Solid("#330033")
image bg chat = Solid("#1a1a1a")
image bg terminal = Solid("#000")
image bg city_rain = Solid("#2a2a2a")
image bg park = Solid("#228822")
image bg cafe = Solid("#876543")
image bg cinema = Solid("#334455")
image bg hospital = Solid("#ffffff")
image bg office = Solid("#666666")
image bg wedding = Solid("#f8f8ff")
image bg reception = Solid("#fffaf0")

#开幕警告图片
image soft = Solid("#209175bd")

#变换
transform shake:
    linear 0.1 xoffset 10
    linear 0.1 xoffset -10
    linear 0.1 xoffset 8
    linear 0.1 xoffset -8
    linear 0.1 xoffset 0

transform gentle:
    linear 0.5 xoffset 5
    linear 0.5 xoffset -5
    repeat

transform ghost_appear:
    alpha 0.0
    linear 2.0 alpha 1.0

transform center:
    xalign 0.5 yalign 0.5

#开幕警告
label opening_warning:
    scene soft
    with dissolve
    
    "警告：本游戏包含以下内容："
    "• 心理恐怖元素"
    "• 强烈的情感依赖表现"
    "• 创伤后应激障碍描写"
    ""
    "本游戏仅为虚构作品，"
    "请不要模仿游戏中的任何行为。"
    "如果您在现实中遇到类似情况，"
    "请及时寻求专业帮助。"
    
    menu:
        "我理解并继续游戏":
            hide soft
            with dissolve
            return
        
        "我需要了解更多":
            show a normal at center
            a "游戏中的角色关系是虚构的，"
            a "现实中的健康关系应该建立在互相尊重的基础上。"
            a "请记住，游戏是游戏，现实是现实。"
            hide a
            jump opening_warning

#游戏开始
label start:
    call opening_warning
    
    if persistent.first_run_time == 0:
        $ persistent.first_run_time = time.time()
    
    play music bgm_memory fadein 2.0
    
    scene bg city_rain
    
    "2023年3月15日，雨夜。"
    "我一个人坐在空荡荡的公寓里，窗外是湿漉漉的城市。"
    "父母上个月正式离婚了，我被夹在中间，感觉自己像个多余的累赘。"
    "父亲搬去了另一个城市，母亲陷入了深深的抑郁。"
    "而我，25岁的程序员，每天对着代码，却无法编出人生的答案。"
    
    "在开始这段故事之前，我需要知道你的名字……"
    $ player_name = renpy.input("你的名字是？", default="", length=20)
    if player_name == "":
        $ player_name = "玩家"
    
    "我叫[player_name]，在这个陌生的城市里，我感觉自己像个透明人。"
    "每天重复着上班、下班、独处的循环，这种孤独几乎要把我吞噬。"
    
    nvl clear
    scene bg chat
    
    nvl_pf "兄弟，最近怎么样？"
    nvl_player "还好吧，就是有点累"
    nvl_pf "你爸妈的事……处理得怎么样了？"
    nvl_player "就那样吧，离婚证领了，家也散了"
    nvl_pf "需要出来喝一杯吗？"
    nvl_player "不用了，我想一个人静静"
    nvl_pf "别这样封闭自己，人需要社交"
    nvl_player "我知道……但就是提不起劲"
    
    nvl clear
    "朋友的关心是真诚的，但我无法接受。"
    "每次看到别人完整的家庭，我就感到一阵刺痛。"
    "也许这就是为什么我会在网络上寻求慰藉……"
    
    scene bg chat
    show a shy at center
    
    "那是在一个叫'心灵港湾'的心理互助论坛上……"
    "我发了一个帖子：『家庭破碎后，如何重新找到生活的意义？』"
    a "你好，看到你发的帖子……你的文字让我感同身受。"
    a "我父母在我高中时离婚了，我知道那种被抛弃的感觉。"
    
    menu:
        "你怎么知道的？":
            a "因为你的文字里透着同样的孤独和迷茫……我能感觉到。"
            $ player_loneliness_level += 5
        "我不需要同情":
            a "不是同情，是理解。我们都懂那种家庭破碎的痛苦。"
            $ player_insecurity_level += 5
        "谢谢你的关心":
            a "不用谢……只是不想看到有人像我当年一样独自承受。"
            $ player_loneliness_level += 3
    
    "那天晚上，我们聊了很多。"
    
    nvl clear
    scene bg chat
    nvl_a "我父亲离开时，连一张纸条都没留。"
    nvl_a "那天我放学回家，发现他的东西全都不见了。"
    nvl_a "母亲因此精神崩溃，住了半年医院"
    nvl_a "从那时起，我就害怕失去重要的人……"
    nvl_a "你真的能理解吗？那种被最信任的人背叛的感觉？"
    nvl_a "那我们就是同类了……受伤的同类"
    
    nvl clear
    "她的名字叫小雅，24岁，是一名插画师。"
    "我们的对话持续到深夜，像是找到了理解彼此的知己。"
    
    scene bg chat
    show a normal at center
    a "早安，昨晚睡得好吗？"
    a "我一直在想我们的对话……你让我感到不那么孤单了。"
    
    menu:
        "我也是，谢谢你的理解":
            show a smile at center
            a "能遇到理解的人真好。你今天心情怎么样？"
            $ persistent.intimacy_level += 5
        "我睡得不太好，一直在想家里的事":
            show a worried at center
            a "那种感觉我懂……要聊聊吗？我随时都在。"
            $ persistent.intimacy_level += 8
        "还好，就是有点累":
            show a sad at center
            a "累了就休息一下，别太勉强自己。"
            $ persistent.intimacy_level += 3
    
    "从那天起，我们开始了频繁的交流。"
    
    nvl clear
    scene bg chat
    nvl_a "今天工作顺利吗？"
    nvl_player "还好，就是代码有点bug，调了一下午"
    nvl_a "辛苦了，程序员真不容易呢"
    nvl_player "你的插画工作怎么样？"
    nvl_a "在画一个系列，关于破碎家庭的孩子……可能有点沉重"
    nvl_player "艺术本来就应该表达真实的情感"
    nvl_a "谢谢你的理解，很少有人这么说"
    
    nvl clear
    nvl_a "今天下雨了，我喜欢雨天的味道"
    nvl_player "为什么？"
    nvl_a "因为下雨的时候，大家都待在室内，世界变得很安静"
    nvl_player "我懂，雨天有种让人安心的孤独感"
    nvl_a "对！就是这种感觉！"
    
    nvl clear
    "我们发现了越来越多的共同点。"
    "喜欢的音乐、电影、书籍……甚至对生活的感悟都如此相似。"
    "她填补了我内心的空洞，而我似乎也治愈了她的伤痛。"
    
    scene bg room
    show a shy at center
    
    "一周后，我们第一次通了电话。"
    a "你好……我是小雅。"
    "她的声音很温柔，带着一丝紧张。"
    
    menu:
        "你的声音很好听":
            a "真、真的吗？我有点紧张……"
            $ persistent.intimacy_level += 10
        "终于听到你的声音了":
            a "我也是……感觉好奇妙，像是认识了很久"
            $ persistent.intimacy_level += 8
        "晚上好，小雅":
            a "晚上好……不知道为什么，心跳得好快"
            $ persistent.intimacy_level += 5
    
    "那通电话我们聊了三个小时，直到手机发烫。"
    "挂断后，我感到一种久违的温暖。"
    
    nvl clear
    scene bg chat
    
    nvl_pf "听说你最近在网恋？"
    nvl_player "不算网恋吧，就是聊得来的朋友"
    nvl_pf "小心点，网络上什么人都有"
    nvl_player "她不一样，我们能理解彼此的伤痛"
    nvl_pf "就是因为有共同伤痛才危险，容易产生依赖"
    nvl_player "我知道分寸的"
    
    nvl clear
    "朋友说得对，但我已经无法控制地期待每天与她的对话。"
    "她成了我灰色生活中的一抹亮色。"
    
    scene bg chat
    show a shy at center
    
    a "那个……[player_name]，我想见你。"
    a "我知道这样可能有点突然，但是……"
    a "我真的很想见见能够理解我的人。"
    
    menu:
        "好啊，我也很想见你":
            show a happy at center
            a "真的吗？太好了！那我们约在哪里？"
            $ relationship_phase = "developing"
        "再等等吧，我还没准备好":
            show a sad at center
            a "好吧……我理解。等你准备好了再告诉我。"
            $ relationship_phase = "initial"
        "见面后会不会破坏现在的美好？":
            show a worried at center
            a "我也担心这个……但我想冒险试试。"
            $ relationship_phase = "developing"
    
    if relationship_phase == "developing":
        nvl clear
        scene bg chat
        nvl_a "你觉得中央公园怎么样？那里人不多，环境也很好"
        nvl_player "好啊，什么时间合适？"
        nvl_a "周六下午三点可以吗？我会穿一件蓝色的连衣裙"
        nvl_player "那我穿灰色外套，这样好认一点"
        nvl_a "好的，好期待……也好紧张"
        nvl_player "放轻松，就像平时聊天一样"
        nvl_a "嗯！那周六见！"
        
        nvl clear
        "第一次见面的日子定在了4月27日，周六。"
        "那几天，我既期待又紧张，像是回到了青涩的学生时代。"
    
    scene bg park
    show a shy at center
    play music bgm_love fadein 2.0
    
    "4月27日，中央公园。"
    "我提前到了半小时，坐在长椅上等待。"
    "春天的阳光很温暖，空气中弥漫着花香。"
    
    "三点整，一个穿着蓝色连衣裙的女孩出现在视线中。"
    "她比照片上还要秀气，眼神中带着一丝不安和期待。"
    
    a "你好……是[player_name]吗？"
    "她的声音比电话里还要轻柔。"
    
    menu:
        "小雅？你今天很漂亮":
            show a happy at center
            a "谢谢……你也很帅。"
            $ persistent.intimacy_level += 15
        "终于见到你了，小雅":
            show a smile at center
            a "嗯，终于见到你了……感觉好奇妙。"
            $ persistent.intimacy_level += 12
        "你好，我是[player_name]":
            show a normal at center
            a "我知道……和我想象中一样。"
            $ persistent.intimacy_level += 10
    
    "我们在公园里散步，聊了很多。"
    
    nvl clear
    scene bg park
    nvl_a "这里的樱花真美……"
    nvl_player "是啊，春天总是让人心情变好"
    nvl_a "和你聊天比在网上更自在"
    nvl_player "我也是，感觉我们真的认识了很久"
    nvl_a "可能是因为我们都经历过类似的事情吧"
    nvl_player "伤痛让人更容易理解彼此"
    nvl_a "但我不希望我们只是因为伤痛才在一起……"
    nvl_player "当然不是，我喜欢的是你整个人"
    
    nvl clear
    "那天我们一直聊到夕阳西下。"
    "送她到地铁站时，她突然停下脚步。"
    
    show a shy at center
    a "今天……我很开心。"
    a "谢谢你愿意来见我。"
    
    menu:
        "我也很开心，希望能再见到你":
            show a love at center
            a "真的吗？那……下周还可以见面吗？"
            $ persistent.intimacy_level += 20
        "你今天比我想象中还要可爱":
            show a happy at center
            a "别、别这么说……我会不好意思的。"
            $ persistent.intimacy_level += 18
        "我送你回去吧":
            show a smile at center
            a "不用了，我自己可以。下次……下次再约吧。"
            $ persistent.intimacy_level += 15
    
    "第一次见面后，我们的关系迅速升温。"
    
    scene bg cafe
    show a happy at center
    
    "我们开始频繁约会。"
    "咖啡馆、电影院、美术馆……城市的每个角落都留下了我们的足迹。"
    
    a "这家咖啡馆的拿铁很好喝，你要尝尝吗？"
    a "我知道你不喜欢太甜，所以特意点了无糖的。"
    
    menu:
        "谢谢你记得我的喜好":
            show a love at center
            a "你的所有事情我都记得很清楚。"
            $ persistent.intimacy_level += 10
        "你真贴心":
            show a smile at center
            a "因为是你的事情，所以特别在意。"
            $ persistent.intimacy_level += 8
        "我自己来就好":
            show a normal at center
            a "好吧……下次你自己点。"
            $ persistent.intimacy_level += 5
    
    nvl clear
    scene bg chat
    nvl_a "今天看电影时，我偷偷看了你好几次"
    nvl_player "为什么偷偷看？"
    nvl_a "因为你的侧脸很好看，而且认真的样子很迷人"
    nvl_player "你才是，今天特别可爱"
    nvl_a "真的吗？我好开心……"
    nvl_player "小雅，我好像……越来越喜欢你了"
    nvl_a "我也是……比想象中还要喜欢"
    
    nvl clear
    "5月20日，在一个星空特别明亮的夜晚……"
    
    scene bg park
    show a shy at center
    
    a "[player_name]，我……有话想对你说。"
    "她的声音有些颤抖，眼神中充满了期待和不安。"
    
    a "从认识你开始，我的世界就变得不一样了。"
    a "你理解我的伤痛，包容我的不安……"
    a "我想永远和你在一起。"
    
    menu:
        "我也爱你，小雅":
            show a love at center
            a "真的吗？你真的愿意和我在一起？"
            $ relationship_phase = "intimate"
            $ persistent.intimacy_level += 50
        "我会好好珍惜你的":
            show a happy at center
            a "嗯！我也会好好珍惜你的！"
            $ relationship_phase = "intimate"
            $ persistent.intimacy_level += 45
        "让我们正式交往吧":
            show a smile at center
            a "好！从今天开始，我们就是恋人了！"
            $ relationship_phase = "intimate"
            $ persistent.intimacy_level += 40
    
    "从那天起，我们正式成为了恋人。"
    "那段日子，是我人生中最幸福的时光。"
    
    scene bg room
    show a happy at center
    
    "热恋期的每一天都充满甜蜜。"
    
    a "早安，今天也要想我哦～"
    a "我给你做了便当，放在你公司前台了。"
    a "记得拍照给我看，我想知道你喜不喜欢。"
    
    menu:
        "谢谢你，你真贴心":
            show a love at center
            a "因为是你的事情，所以特别用心。"
            $ persistent.intimacy_level += 10
        "不用这么麻烦的":
            show a sad at center
            a "你不喜欢吗？那我明天不做了……"
            $ persistent.intimacy_level += 5
        "你做的我都喜欢":
            show a happy at center
            a "真的吗？那我明天还给你做！"
            $ persistent.intimacy_level += 15
    
    "但渐渐地，她的关心开始变得有些过度……"
    
    scene bg chat
    show a suspicious at center
    
    a "你刚才和谁通话了？我听到女生的声音。"
    a "只是同事？哪个同事？叫什么名字？"
    
    menu:
        "真的是同事，你别多想":
            show a sad at center
            a "我不是多想……只是害怕。你知道我经历过什么。"
            $ jealousy_level += 5
            $ mental_state = "suspicious"
        "你在监视我吗？":
            show a angry at center
            a "监视？我只是关心你！为什么你要这样想我？"
            $ jealousy_level += 8
            $ mental_state = "angry"
        "我需要一点私人空间":
            show a broken at center
            a "空间？你要离开我吗？像他们所有人一样？"
            $ jealousy_level += 10
            $ mental_state = "broken"
    
    nvl clear
    scene bg chat
    
    nvl_pf "兄弟，你女朋友是不是太黏人了？"
    nvl_player "她只是缺乏安全感"
    nvl_pf "这已经不是缺乏安全感了，这是控制欲"
    nvl_player "你不懂她的过去……"
    nvl_pf "我是不懂，但我看到你在失去自我"
    nvl_player "我知道，但我不能离开她"
    nvl_pf "为什么？因为愧疚？"
    nvl_player "也许吧……我知道她的创伤，抛弃她就等于重复她父亲的背叛"
    
    nvl clear
    "朋友说得对，但我无法离开小雅。"
    "不是因为爱，而是因为愧疚和责任。"
    
    nvl clear
    scene bg chat
    nvl_af "小雅，你最近怎么样？"
    nvl_a "很好啊，和[player_name]在一起很幸福"
    nvl_af "真的吗？但你看起来有点焦虑"
    nvl_a "我只是……害怕失去他"
    nvl_af "别这样，小雅，你要学会信任"
    nvl_a "我知道，但我控制不住……每次他晚回消息，我就会想起父亲离开的那天"
    nvl_af "他不是你父亲，你要给他空间"
    nvl_a "我试试……但我真的好害怕"
    
    nvl clear
    "小雅也在努力对抗自己的不安全感，但创伤太深了。"
    
    scene bg office
    show y normal at center
    
    "就在我最压抑的时候，我遇到了小雨。"
    "她是公司新来的实习生，活泼开朗，充满活力。"
    
    y "前辈，这个代码我看不懂，能教教我吗？"
    "她的笑容很阳光，和小雅的忧郁形成鲜明对比。"
    
    menu:
        "当然可以，哪里不懂？":
            show y happy at center
            y "这里！还有这里！前辈你真好！"
            $ player_loneliness_level -= 10
        "我现在有点忙，等会教你":
            show y sad at center
            y "好吧……那我不打扰你了"
            $ player_loneliness_level -= 5
        "你可以先问问别人":
            show y normal at center
            y "哦……好的"
            $ player_loneliness_level -= 3
    
    "和小雨在一起时，我暂时忘记了压力和责任。"
    "她让我想起了从前的自己，那个还会笑的自己。"
    
    nvl clear
    scene bg chat
    
    nvl_player "今天工作好累"
    nvl_a "辛苦了，早点休息。记得想我❤"
    
    nvl clear
    nvl_player "今天教新人写代码，挺有成就感的"
    nvl_y "嘿嘿，都是前辈教得好！明天继续请教你可以吗？"
    
    nvl clear
    "我在两个世界间穿梭。"
    "对小雅，我是体贴的男友，理解她的创伤。"
    "对小雨，我是可靠的前辈，享受轻松时光。"
    "谎言像雪球一样越滚越大……"
    
    scene bg room_dark
    show a suspicious at center
    
    a "你最近……好像很开心？"
    a "有什么我不知道的事情吗？"
    
    menu:
        "只是工作顺利":
            a "工作？可你最近经常加班呢。"
            $ mental_state = "suspicious"
            $ jealousy_level += 5
        "认识了新同事":
            show a angry at center
            a "新同事？什么样的同事？男的还是女的？"
            $ mental_state = "angry"
            $ jealousy_level += 8
        "我需要一点自由":
            show a broken at center
            a "自由？所以你终于厌倦我了吗？"
            $ mental_state = "broken"
            $ jealousy_level += 10
    
    "我的双重生活在一个雨夜结束了。"
    
    scene bg city_rain
    show a ghost at center
    
    "我送加班的小雨回家时，在街角看到了小雅。"
    "她站在雨中，没有打伞，浑身湿透。"
    "她的眼神空洞，像是灵魂被抽走了一样。"
    
    a "原来如此……"
    a "又一个背叛者。"
    a "像我父亲一样，像前男友一样……"
    a "现在，你也一样。"
    
    scene bg room_dark
    show a broken at shake, center
    
    a "为什么？[player_name]！"
    a "我把我所有的伤疤都给你看了！"
    a "我告诉你我有多害怕被抛弃！"
    a "而你……你却亲手实现了我的噩梦！"
    
    show a demon at center
    a "你知道被最信任的人背叛是什么感觉吗？"
    a "现在，你也要尝尝这种滋味了。"
    
    scene bg terminal
    play music bgm_crazy fadein 2.0
    
    "第二天，我的电脑被黑了。"
    "屏幕上出现一行字……"
    
    a "欢迎来到我的世界，[player_name]。"
    a "既然你选择用谎言伤害我……"
    a "那我就用真相来治愈你。"
    
    "从此，我被困在了这个她创造的虚拟地狱中。"
    "一个专门为我设计的……赎罪之地。"
    
    jump after_start

#增强后的开始（简化）
label after_start:
    jump chapter_1

#第一章
label chapter_1:
    $ current_chapter = 1
    scene bg room_dark
    show a conflicted at center
    
    play music bgm_dark fadein 2.0
    
    a "欢迎来到赎罪之屋，[player_name]。"
    a "这里的每一个谜题，都是你背叛的证明。"
    a "解开它们，面对你对我造成的伤害。"
    
    show a yandere at shake, center
    a "第一章：找到储物柜密码。"
    a "提示是我们第一次约会的日期……"
    a "那天你发誓永远不会伤害我。"
    a "还记得那个谎言吗？"
    
    hide a
    
label chapter_1_loop:
    scene bg room_dark
    
    if random.random() < 0.3:
        call check_whispers
    
    menu:
        "检查书桌":
            call check_desk
            jump chapter_1_loop
        "检查储物柜" if not locker_opened:
            call check_locker
            jump chapter_1_loop
        "检查床铺":
            call check_bed
            jump chapter_1_loop
        "检查窗户":
            call check_window
            jump chapter_1_loop
        "查看照片墙":
            call check_photo_wall
            jump chapter_1_loop
        "查看日记本":
            call check_diary
            jump chapter_1_loop
        "尝试开门" if locker_opened:
            show a conflicted at center
            a "做得好……但真正的赎罪才刚刚开始。"
            a "下一章，你会看到你的背叛造成了什么后果。"
            $ chapter1_completed = True
            hide a
            jump chapter_2

label check_desk:
    scene bg desk
    "书桌上散落着打印出来的聊天记录。"
    if "日记页1" not in found_clues:
        "你找到日记页1：「他说理解我的创伤，我相信了。但现在看来，那只是同情。」"
        $ found_clues.append("日记页1")
        $ diary_pages += 1
    if "诊断书" not in found_clues:
        "你找到一份心理诊断书：创伤后应激障碍，源于多次被重要的人背叛。"
        $ found_clues.append("诊断书")
    show a sad at center
    a "看到这些证据了吗？"
    a "你的背叛不是偶然……而是重复了我生命中最深的伤痛。"
    $ persistent.dialogue_count += 3
    return

label check_locker:
    scene bg locker
    "储物柜上挂着密码锁。"
    show a angry at center
    a "密码是我们第一次约会的日子。"
    a "那天你发誓时……心里在想她吗？"
    hide a
    call screen puzzle_lock
    $ persistent.dialogue_count += 2
    return

label check_bed:
    scene bg bed
    "床上放着一个破旧的玩偶。"
    show a ghost at ghost_appear, center
    a "这是我父亲离开前送我的最后一个礼物。"
    a "现在，你也要离开我了……"
    a "但这次，我不会让任何人离开。"
    hide a
    $ persistent.dialogue_count += 2
    return

label check_window:
    scene bg room
    "窗外只有无尽的黑暗。"
    a "在等谁来救你吗？"
    a "不会有人来的……就像当年没人来救我一样。"
    $ persistent.dialogue_count += 1
    return

label check_photo_wall:
    scene bg room
    "墙上贴满了我们的合照。"
    "从第一次见面到最后的背叛，每一张都记录着我们的关系。"
    show a sad at center
    a "看啊，我们曾经那么幸福。"
    a "为什么要破坏这一切？为什么要证明我的恐惧是对的？"
    $ persistent.dialogue_count += 2
    return

label check_diary:
    scene bg desk
    "你找到了小雅的日记本。"
    if "日记内容" not in found_clues:
        "日记里记录了她每天的心情："
        "『今天[player_name]晚回了消息，我好害怕……』"
        "『他提到女同事时笑了，那种笑容从来没有给过我……』"
        "『我是不是又不够好？为什么总是被抛弃？』"
        $ found_clues.append("日记内容")
    show a broken at center
    a "现在你明白了吗？"
    a "你的每一个细微举动，都在加深我的不安全感。"
    $ persistent.dialogue_count += 3
    return

#第二章
label chapter_2:
    $ current_chapter = 2
    scene bg corridor
    show a conflicted at center
    
    "走廊的墙壁上挂满了破碎的家庭照片。"
    a "欢迎来到创伤长廊，[player_name]。"
    a "这里重现了我生命中的每一次背叛。"
    a "第二章：面对镜子中的真相。"
    a "但小心……真相可能会让你发疯。"
    
    hide a
    
label chapter_2_loop:
    scene bg corridor
    
    if random.random() < 0.3:
        call check_whispers
    
    menu:
        "进入教室":
            call explore_classroom
            jump chapter_2_loop
        "进入洗手间":
            call explore_bathroom
            jump chapter_2_loop
        "进入治疗室":
            call explore_therapy_room
            jump chapter_2_loop
        "查看记忆走廊":
            call explore_memory_hall
            jump chapter_2_loop
        "继续前进" if mirror_broken:
            show a love at center
            a "镜子碎了……就像我的心一样。"
            a "但现在，我们可以开始修复了。"
            $ chapter2_completed = True
            hide a
            jump chapter_3

label explore_classroom:
    scene bg classroom
    "教室里摆放着课桌，每张桌子上都有一个名字。"
    "小雅的父亲、前男友……还有我的名字。"
    if "背叛者名单" not in found_clues:
        "黑板上写着：『为什么我总是吸引背叛者？』"
        $ found_clues.append("背叛者名单")
    "角落有面落地镜。"
    menu:
        "检查镜子" if not mirror_broken:
            call screen puzzle_mirror
        "再次检查镜子" if mirror_broken:
            call check_mirror_again
        "离开":
            return
    $ persistent.dialogue_count += 2
    return

label explore_bathroom:
    scene bg bathroom
    "洗手间的镜子上用红色写着：『你和她在一起时，想过我吗？』"
    show a conflicted at ghost_appear, center
    a "每次你和她聊天时，我都能感觉到。"
    a "就像心灵感应一样……"
    a "我的心在流血，而你却在笑。"
    
    menu:
        "我那时很迷茫":
            show a love at center
            a "迷茫？那我呢？我在为你痛苦时，你关心过吗？"
            $ persistent.intimacy_level += 5
        "我们都做错了":
            show a angry at center
            a "错误？我的错误是太爱你！"
            a "而你的错误是根本不配被爱！"
        "我们应该向前看":
            show a crazy at center
            a "向前？不……我们要永远记住这个教训。"
            a "直到你真正明白忠诚的意义。"
    hide a with dissolve
    $ persistent.dialogue_count += 3
    return

label explore_therapy_room:
    scene bg hospital
    show doctor normal at center
    "你发现自己在一间心理治疗室里。"
    doctor "你好，我是李医生。小雅是我的病人。"
    doctor "她患有严重的创伤后应激障碍和信任障碍。"
    doctor "你的背叛，让她的病情急剧恶化。"
    
    menu:
        "我不知道后果这么严重":
            doctor "现在你知道了。但知道和理解是两回事。"
        "我只是想逃离那种窒息的爱":
            doctor "窒息？那是因为她从未体验过健康的爱。"
        "我能做什么来弥补":
            doctor "弥补？首先你要真正理解她的痛苦。"
    
    $ persistent.dialogue_count += 3
    return

label explore_memory_hall:
    scene bg corridor
    "走廊两侧是动态的记忆画面。"
    "小雅小时候等待父亲回家的场景……"
    "她发现父亲不告而别时的崩溃……"
    "母亲被送进精神病院的那天……"
    show a ghost at center
    a "现在你明白了吗？"
    a "我的每一个不安全感，都有它的来源。"
    a "而你，成为了最新的那个来源。"
    $ persistent.dialogue_count += 2
    return

#第三章
label chapter_3:
    $ current_chapter = 3
    scene bg basement
    show a conflicted at center
    
    "地下室冰冷潮湿，空气中弥漫着绝望。"
    a "最终审判，[player_name]。"
    a "这里是所有背叛的终点站。"
    a "做出你的选择……"
    a "但记住，每个选择都有代价。"
    
    hide a
    
label chapter_3_loop:
    scene bg basement
    
    if random.random() < 0.4:
        call check_whispers
    
    menu:
        "查看证据墙":
            call check_evidence_wall
            jump chapter_3_loop
        "查看监控记录":
            call check_surveillance
            jump chapter_3_loop
        "查看心理评估":
            call check_psychological_evaluation
            jump chapter_3_loop
        "查看关系时间线":
            call check_relationship_timeline
            jump chapter_3_loop
        "面对小雅":
            call face_xiaoya

label check_evidence_wall:
    scene bg computer
    "墙上贴满了我和小雨的聊天记录截图。"
    a "看啊，这就是你所谓的'普通朋友'。"
    a "'我想你'……'我喜欢和你在一起'……"
    a "每一条都在证明你的背叛。"
    
    menu:
        "那些只是玩笑":
            a "玩笑？那为什么你从没对我说过同样的'玩笑'？"
            a "因为对我，你只感到责任和愧疚！"
        "我确实做错了":
            a "终于承认了？但承认能改变什么？"
            a "能让我重新信任你吗？能让我不再做噩梦吗？"
        "我们都受到了惩罚":
            show a sad at center
            a "是的……我们都变成了自己讨厌的样子。"
            a "我变成了控制狂，你变成了骗子。"
    $ persistent.dialogue_count += 3
    return

label check_surveillance:
    scene bg monitors
    "监控屏幕上播放着我和小雨在一起的片段。"
    show a crazy at center
    a "看啊，你笑得多开心。"
    a "但你知道我当时在做什么吗？"
    a "我在家里哭泣，在怀疑自己哪里不够好……"
    a "而你，却在享受背叛的快乐。"
    $ persistent.dialogue_count += 2
    return

label check_psychological_evaluation:
    scene bg hospital
    show doctor normal at center
    "你看到小雅的心理评估报告。"
    doctor "小雅的病情比想象中严重。"
    doctor "你的背叛触发了她所有的创伤记忆。"
    doctor "她现在处于极度不稳定的状态。"
    
    menu:
        "这是我的错":
            doctor "承认错误是第一步，但治愈需要更多。"
        "她需要专业帮助":
            doctor "是的，但她也需要你的理解和配合。"
        "我能做什么":
            doctor "首先，你要真正理解她的痛苦来源。"
    
    $ persistent.dialogue_count += 3
    return

label check_relationship_timeline:
    scene bg room
    "墙上是一条详细的时间线。"
    "2023年3月15日：在心理互助论坛相遇"
    "2023年4月27日：第一次约会"
    "2023年5月20日：正式交往"
    "2023年8月10日：开始与小雨密切接触"
    "2023年9月5日：背叛被发现"
    show a broken at center
    a "看啊，我们的爱情只有短短几个月。"
    a "而你的背叛，却会跟随我一辈子。"
    $ persistent.dialogue_count += 2
    return

label face_xiaoya:
    scene bg basement
    show a conflicted at shake, center
    
    a "最终选择，[player_name]。"
    a "我们都走到了十字路口。"
    
    a "现在，选择我们的未来吧。"
    
    menu:
        "我愿意弥补，一起治愈":
            $ final_choice = "healing"
            jump healing_ending
        "我们都需专业帮助":
            $ final_choice = "professional"
            jump professional_ending
        "这种关系必须结束":
            $ final_choice = "reject"
            jump rejection_ending
        "我永远爱你，请给我改过的机会":
            $ final_choice = "redemption" 
            jump redemption_ending

#治愈结局
label healing_ending:
    $ persistent.ending_collection.append("healing")
    scene bg ending_good
    show a conflicted at center
    
    "我选择了面对和弥补。"
    a "你终于明白了……"
    a "伤害已经造成，但也许……还能修复。"
    
    show a sad at center
    a "我知道我变得可怕，变得不像自己。"
    a "但每次你看向别人，我的创伤就会被触发。"
    a "那种被抛弃的恐惧……几乎让我发疯。"
    
    show a love at center
    a "但现在，你选择面对而不是逃避。"
    a "也许……我们真的可以一起学习如何健康地相爱。"
    
    "我们拥抱在一起，泪水交织。"
    "这不是幸福的结局，而是重新开始的承诺。"
    
    nvl clear
    scene bg chat
    
    nvl_pf "听说你们在尝试解决问题？"
    nvl_player "是的……我们决定面对彼此的心魔"
    nvl_pf "这很勇敢，但也很危险"
    nvl_player "我知道……但逃避只会让一切更糟"
    nvl_pf "希望你们能找到真正的幸福"
    nvl_player "谢谢，我们会努力的"
    
    nvl clear
    nvl_af "小雅，你还好吗？"
    nvl_a "在尝试……学习信任，放下控制"
    nvl_af "这需要时间"
    nvl_a "我知道……但这次我想真正治愈"
    nvl_af "为你骄傲，小雅"
    nvl_a "谢谢你的支持"
    
    nvl clear
    scene bg ending_good
    
    "治愈结局达成：【伤痕累累的爱】"
    "真正的治愈不是忘记伤痛，而是学会带着伤痕继续前行。"
    "我们都有伤，但愿意为彼此包扎。"
    
    $ persistent.ending_unlocked = True
    call show_final_stats
    
    $ check_afterstory_unlock()
    
    if persistent.afterstory_unlocked:
        show a smile at center
        a "我们的故事还没有完全结束哦……"
        a "如果还想知道之后发生了什么，"
        a "可以在主菜单找到'后日谈'。"
        hide a
    
    $ check_special_mode_unlock()
    if persistent.special_mode_unlocked:
        a "看来你很了解我们的故事了呢……"
        a "特别模式也已解锁，"
        a "里面有更多想告诉你的东西。"
    
    jump the_end_final_enhanced

#专业帮助结局
label professional_ending:
    $ persistent.ending_collection.append("professional")
    scene bg ending_hidden
    show a sad at center
    
    "我建议我们都寻求心理咨询。"
    a "你……你觉得我们病了吗？"
    
    show a conflicted at center
    a "也许你是对的。"
    a "我的创伤，你的逃避……"
    a "可能真的需要专业帮助才能解决。"
    
    "我们同意暂时分开，各自接受治疗。"
    "这不是结束，而是真正治愈的开始。"
    
    nvl clear
    scene bg chat
    
    nvl_pf "听说你们决定寻求帮助？"
    nvl_player "是的，我们都意识到自己需要治愈"
    nvl_pf "这很成熟"
    nvl_player "伤害别人后，才明白自己也需要被治愈"
    nvl_pf "希望你们都能好起来"
    nvl_player "谢谢，这是必要的旅程"
    
    nvl clear
    nvl_af "小雅，治疗怎么样？"
    nvl_a "很难……但在学习区分爱和控制"
    nvl_af "为你骄傲"
    nvl_a "这次……我想真正地好起来"
    nvl_af "慢慢来，你会做到的"
    
    nvl clear
    scene bg ending_hidden
    
    "专业结局达成：【理智的救赎】"
    "承认需要帮助，是走向治愈的第一步。"
    "有时候，专业的指引比盲目的爱更有效。"
    
    $ persistent.ending_unlocked = True
    call show_final_stats
    
    $ check_afterstory_unlock()
    
    if persistent.afterstory_unlocked:
        show a smile at center
        a "我们的故事还没有完全结束哦……"
        a "如果还想知道之后发生了什么，"
        a "可以在主菜单找到'后日谈'。"
        hide a
    
    $ check_special_mode_unlock()
    if persistent.special_mode_unlocked:
        a "看来你很了解我们的故事了呢……"
        a "特别模式也已解锁，"
        a "里面有更多想告诉你的东西。"
    
    jump the_end_final_enhanced

#拒绝结局
label rejection_ending:
    $ persistent.ending_collection.append("reject")
    scene bg ending_bad
    show a broken at center
    
    "我选择了结束这段有毒的关系。"
    a "果然……你还是要离开。"
    
    show a sad at center
    a "也许这是最好的选择。"
    a "这样的关系对彼此都是折磨。"
    
    "她的身影开始消散，声音中带着释然。"
    a "我恨你给我的伤害……"
    a "但我更恨的是……"
    a "我让创伤把我变成了怪物。"
    
    nvl clear
    scene bg chat
    
    nvl_pf "听说你们分手了？"
    nvl_player "嗯……这对彼此都是解脱"
    nvl_pf "她还好吗？"
    nvl_player "在学着为自己而活，而不是为恐惧而活"
    nvl_pf "你也是，要向前看"
    nvl_player "我知道，这是成长的必要痛苦"
    
    nvl clear
    nvl_af "小雅，你要坚强"
    nvl_a "这次……我想真正地为自己活着"
    nvl_af "这才是真正的开始"
    nvl_a "嗯……为自己而活，而不是为任何人"
    
    nvl clear
    scene bg ending_bad
    
    "拒绝结局达成：【痛苦的觉醒】"
    "有时候，结束一段有毒的关系，是对彼此最大的仁慈。"
    "真正的爱不应该以伤害为代价。"
    
    $ persistent.ending_unlocked = True
    call show_final_stats
    
    $ check_afterstory_unlock()
    
    if persistent.afterstory_unlocked:
        show a smile at center
        a "我们的故事还没有完全结束哦……"
        a "如果还想知道之后发生了什么，"
        a "可以在主菜单找到'后日谈'。"
        hide a
    
    $ check_special_mode_unlock()
    if persistent.special_mode_unlocked:
        a "看来你很了解我们的故事了呢……"
        a "特别模式也已解锁，"
        a "里面有更多想告诉你的东西。"
    
    jump the_end_final_enhanced

#救赎结局
label redemption_ending:
    $ persistent.ending_collection.append("redemption")
    scene bg ending_good
    show a love at center
    
    "我跪下来，真诚地忏悔。"
    "小雅，我犯下了不可饶恕的错误。"
    "但我真的爱你，从第一次见面就爱你。"
    "请给我一个改过自新的机会。"
    
    show a conflicted at center
    a "你知道要重新建立信任有多难吗？"
    a "每一次你晚归，我都会怀疑。"
    a "每一次你微笑，我都会害怕。"
    
    show a sad at center
    a "但你的眼泪……看起来是真实的。"
    
    menu:
        "我愿意用余生证明我的忠诚":
            show a love at center
            a "那就证明给我看吧。"
            a "用每一天，每一刻，证明你的爱是真实的。"
        "我会弥补我造成的所有伤害":
            show a smile at center
            a "弥补？那需要很长时间。"
            a "但你愿意尝试，我也愿意给你机会。"
        "让我们重新开始，从零开始":
            show a happy at center
            a "重新开始……"
            a "好吧，让我们试试看。"
    
    "救赎结局达成：【第二次机会】"
    "爱情中最美的不是完美，而是在破碎后仍有勇气重新拼凑。"
    
    $ persistent.ending_unlocked = True
    call show_final_stats
    
    $ check_afterstory_unlock()
    
    if persistent.afterstory_unlocked:
        show a smile at center
        a "我们的故事还没有完全结束哦……"
        a "如果还想知道之后发生了什么，"
        a "可以在主菜单找到'后日谈'。"
        hide a
    
    $ check_special_mode_unlock()
    if persistent.special_mode_unlocked:
        a "看来你很了解我们的故事了呢……"
        a "特别模式也已解锁，"
        a "里面有更多想告诉你的东西。"
    
    jump the_end_final_enhanced

#增强版最终结局
label the_end_final_enhanced:
    scene bg black
    with dissolve
    
    "游戏结束了，但思考还在继续。"
    "爱情不应该是一场救赎他人的冒险。"
    "我的孤独，她的创伤……"
    "都不应该成为伤害彼此的借口。"
    
    "也许真正的爱情……"
    "是两个完整的人相遇，而不是两个残缺的灵魂互相填补。"
    
    show a conflicted at center
    a "无论你选择了哪条路……"
    a "希望我们都能从这段经历中学到什么。"
    
    "她的身影最终消失在黑暗中。"
    "带着对爱的新理解，和对自己的新认知。"
    
    "感谢游玩《病娇契约》"
    "愿每个人都能在爱中保持自我，也尊重他人的完整。"
    "因为健康的爱，不应该以伤害为代价。"
    
    $ renpy.quit()
    return

#其他系统
init python:
    import random
    import time
    
    whisper_messages = [
        "……为什么背叛我？",
        "……你和她在一起时快乐吗？",
        "……我的痛苦你感受得到吗？",
        "……我们都变成了怪物。",
        "……能重新开始吗？",
        "……伤痕永远不会消失。",
        "……你理解我的恐惧吗？",
        "……爱情到底是什么？",
        "……我们还有救吗？",
        "……再见，或者再也不见。",
        "……那天在公园，你是真心的吗？",
        "……我们的回忆对你来说算什么？",
        "……被抛弃的感觉，你现在懂了吗？",
        "……信任一旦破碎，还能修复吗？",
        "……我们本可以很幸福的……"
    ]
    
    last_whisper_time = 0
    whisper_cooldown = 30
    
    def check_random_whisper():
        global last_whisper_time
        current_time = time.time()
        
        if current_time - last_whisper_time > whisper_cooldown:
            if random.random() < 0.2:
                last_whisper_time = current_time
                renpy.call("random_whisper_trigger")
    
    # 后日谈解锁条件
    def check_afterstory_unlock():
        if persistent.ending_unlocked:
            persistent.afterstory_unlocked = True
        return persistent.afterstory_unlocked
    
    # 特别模式解锁条件检查
    def check_special_mode_unlock():
        required_endings = ["healing", "professional", "reject", "redemption"]
        if all(ending in persistent.ending_collection for ending in required_endings):
            if persistent.secret_counter >= 4:
                persistent.special_mode_unlocked = True
        return persistent.special_mode_unlocked

label check_whispers:
    $ check_random_whisper()
    return

label random_whisper_trigger:
    $ whisper = random.choice(whisper_messages)
    "[whisper]"
    return

#谜题界面
screen puzzle_lock():
    modal True
    zorder 300
    frame:
        xalign 0.5 yalign 0.5
        xsize 400 ysize 300
        vbox:
            spacing 20
            text "密码锁" size 24 xalign 0.5
            text "第一次约会的日期（MMDD）：" size 18 xalign 0.5
            input:
                value VariableInputValue("locker_code")
                length 4
                allow "0123456789"
                xalign 0.5
                size 30
            hbox:
                spacing 40 xalign 0.5
                textbutton "确认" action [
                    If(locker_code == "0427",
                        [SetVariable("puzzle_solved", True), SetVariable("locker_opened", True), Hide("puzzle_lock"), Call("locker_correct")],
                        [SetVariable("locker_code", ""), Call("locker_wrong")]
                    )
                ]
                textbutton "取消" action [Hide("puzzle_lock")]

screen puzzle_mirror():
    modal True
    zorder 300
    frame:
        xalign 0.5 yalign 0.5
        xsize 500 ysize 400
        vbox:
            spacing 20
            text "真相之镜" size 24 xalign 0.5
            text "「面对镜子中的自己，你看到了什么？」" size 16 xalign 0.5
            text "右下角有一个红色按钮。" size 16 xalign 0.5
            hbox:
                spacing 40 xalign 0.5
                textbutton "按下按钮" action [
                    SetVariable("mirror_broken", True),
                    SetVariable("puzzle_solved", True),
                    Hide("puzzle_mirror"),
                    Call("mirror_puzzle_solved")
                ]
                textbutton "离开" action [Hide("puzzle_mirror")]

label mirror_puzzle_solved:
    scene bg classroom
    "镜子碎裂，露出后面的文字：『背叛者终将孤独』"
    show a ghost at ghost_appear, center
    a "看到了吗？这就是所有背叛者的结局。"
    hide a
    $ persistent.puzzles_solved += 1
    $ found_clues.append("镜子真相")
    $ persistent.dialogue_count += 2
    return

label show_final_stats:
    scene bg black
    "=== 游戏统计 ==="
    "对话数量：[persistent.dialogue_count] 句"
    "解决谜题：[persistent.puzzles_solved] 个"
    "亲密度：[persistent.intimacy_level]"
    "发现线索：[len(found_clues)] 个"
    "孤独等级：[player_loneliness_level]"
    "嫉妒等级：[jealousy_level]"
    "关系阶段：[relationship_phase]"
    
    return

label locker_correct:
    $ locker_wrong_count = 0
    $ persistent.puzzles_solved += 1
    $ found_clues.append("储物柜物品")
    scene bg locker
    
    show a smile at center
    a "还记得那天啊……可惜誓言都是谎言。"
    
    if "日记页2" not in found_clues:
        "你找到日记页2：「他说会永远爱我，我相信了。但现在看来，永远原来这么短暂。」"
        "「还记得当初我们第一次约会的日期吗?」"
        "「0427」"
        $ found_clues.append("日记页2")
        $ diary_pages += 1
    
    hide a
    $ persistent.dialogue_count += 3
    return

label locker_wrong:
    $ locker_wrong_count += 1
    scene bg locker
    "密码错误！"
    if locker_wrong_count == 1:
        show a yandere at center
        a "连这个都忘了？你对我们的回忆就这么不在意？"
    elif locker_wrong_count == 2:
        show a suspicious at center
        a "4月27日……这个日期对你来说毫无意义吗？"
    elif locker_wrong_count >= 3:
        show a sad at center
        a "[locker_wrong_count]次错误……"
        a "你对我的了解，原来这么肤浅。"
    hide a
    $ persistent.dialogue_count += 2
    return

label check_mirror_again:
    scene bg classroom
    "破碎的镜子映出无数个扭曲的倒影。"
    show a ghost at ghost_appear, center
    a "每个碎片里都有一个被背叛的我……"
    a "而现在，又多了一个被你背叛的我。"
    hide a
    $ persistent.dialogue_count += 1
    return

label quit_warning:
    $ persistent.quit_count += 1
    if persistent.quit_count >= 3:
        show a demon at shake, center
        a "又想逃避吗？"
        a "但这次……你无处可逃。"
    return

#初始化变量
init python:
    mirror_interactions = 0
    closet_interactions = 0
    window_interactions = 0
    bed_interactions = 0
    door_interactions = 0
    light_interactions = 0
    corridor_loop = 0

#游戏结束
return