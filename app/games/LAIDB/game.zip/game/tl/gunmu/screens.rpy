﻿# TODO: Translation updated at 2026-02-07 14:28

translate gunmu strings:

    # game/screens.rpy:42
    old "致谢名单"
    new "棍母"

    # game/screens.rpy:50
    old "感谢所有支持我们的人！"
    new "棍母"

    # game/screens.rpy:54
    old "特别鸣谢："
    new "棍母"

    # game/screens.rpy:58
    old "ChatGBT-4o"
    new "棍母"

    # game/screens.rpy:62
    old "甘茶の音楽工房"
    new "棍母"

    # game/screens.rpy:68
    old "关闭"
    new "棍母"

    # game/screens.rpy:343
    old "返回"
    new "棍母"

    # game/screens.rpy:344
    old "回忆"
    new "棍母"

    # game/screens.rpy:345
    old "快进"
    new "棍母"

    # game/screens.rpy:346
    old "自动"
    new "棍母"

    # game/screens.rpy:347
    old "存储"
    new "棍母"

    # game/screens.rpy:350
    old "设置"
    new "棍母"

    # game/screens.rpy:389
    old "开始游戏"
    new "棍母"

    # game/screens.rpy:397
    old "读取游戏"
    new "棍母"

    # game/screens.rpy:403
    old "结束回放"
    new "棍母"

    # game/screens.rpy:407
    old "标题菜单"
    new "棍母"

    # game/screens.rpy:409
    old "介绍"
    new "棍母"

    # game/screens.rpy:414
    old "帮助"
    new "棍母"

    # game/screens.rpy:419
    old "退出"
    new "棍母"

    # game/screens.rpy:659
    old "带派不老铁"
    new "棍母"

    # game/screens.rpy:666
    old "版本 [config.version!t]\n"
    new "棍母"

    # game/screens.rpy:672
    old "引擎：{a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]\n\n[renpy.license!t]"
    new "棍母"

    # game/screens.rpy:702
    old "读取"
    new "棍母"

    # game/screens.rpy:707
    old "第 {} 页"
    new "棍母"

    # game/screens.rpy:707
    old "自动存档"
    new "棍母"

    # game/screens.rpy:707
    old "快速存档"
    new "棍母"

    # game/screens.rpy:748
    old "{#file_time}%Y-%m-%d %H:%M"
    new "棍母"

    # game/screens.rpy:748
    old "空存档位"
    new "棍母"

    # game/screens.rpy:768
    old "<"
    new "棍母"

    # game/screens.rpy:772
    old "{#auto_page}A"
    new "棍母"

    # game/screens.rpy:775
    old "{#quick_page}Q"
    new "棍母"

    # game/screens.rpy:781
    old ">"
    new "棍母"

    # game/screens.rpy:786
    old "上传"
    new "棍母"

    # game/screens.rpy:790
    old "下载"
    new "棍母"

    # game/screens.rpy:848
    old "显示"
    new "棍母"

    # game/screens.rpy:849
    old "窗口"
    new "棍母"

    # game/screens.rpy:850
    old "全屏"
    new "棍母"

    # game/screens.rpy:856
    old "提示(不要点25下)"
    new "棍母"

    # game/screens.rpy:857
    old "点我有惊喜"
    new "棍母"

    # game/screens.rpy:860
    old "取消静音"
    new "棍母"

    # game/screens.rpy:862
    old "静音"
    new "棍母"

    # game/screens.rpy:866
    old "关于作者"
    new "棍母"

    # game/screens.rpy:867
    old "作者bilibili"
    new "棍母"

    # game/screens.rpy:868
    old "作者github"
    new "棍母"

    # game/screens.rpy:869
    old "作者抖音"
    new "棍母"

    # game/screens.rpy:870
    old "作者个人网站"
    new "棍母"

    # game/screens.rpy:875
    old "未读文本"
    new "棍母"

    # game/screens.rpy:876
    old "选项后继续"
    new "棍母"

    # game/screens.rpy:877
    old "忽略转场"
    new "棍母"

    # game/screens.rpy:890
    old "文字速度"
    new "棍母"

    # game/screens.rpy:894
    old "自动前进时间"
    new "棍母"

    # game/screens.rpy:901
    old "音乐音量"
    new "棍母"

    # game/screens.rpy:908
    old "音效音量"
    new "棍母"

    # game/screens.rpy:914
    old "测试"
    new "棍母"

    # game/screens.rpy:918
    old "语音音量"
    new "棍母"

    # game/screens.rpy:929
    old "全部静音"
    new "棍母"

    # game/screens.rpy:1047
    old "尚无记录。"
    new "棍母"

    # game/screens.rpy:1114
    old "键盘"
    new "棍母"

    # game/screens.rpy:1115
    old "鼠标"
    new "棍母"

    # game/screens.rpy:1118
    old "手柄"
    new "棍母"

    # game/screens.rpy:1131
    old "回车"
    new "棍母"

    # game/screens.rpy:1132
    old "推进对话并激活界面。"
    new "棍母"

    # game/screens.rpy:1135
    old "空格"
    new "棍母"

    # game/screens.rpy:1136
    old "在没有选择的情况下推进对话。"
    new "棍母"

    # game/screens.rpy:1139
    old "方向键"
    new "棍母"

    # game/screens.rpy:1140
    old "导航界面。"
    new "棍母"

    # game/screens.rpy:1143
    old "Esc"
    new "棍母"

    # game/screens.rpy:1144
    old "访问游戏菜单。"
    new "棍母"

    # game/screens.rpy:1148
    old "按住时快进对话。"
    new "棍母"

    # game/screens.rpy:1151
    old "Tab"
    new "棍母"

    # game/screens.rpy:1152
    old "切换对话快进。"
    new "棍母"

    # game/screens.rpy:1155
    old "上一页"
    new "棍母"

    # game/screens.rpy:1156
    old "回退至先前的对话。"
    new "棍母"

    # game/screens.rpy:1159
    old "下一页"
    new "棍母"

    # game/screens.rpy:1160
    old "向前至后来的对话。"
    new "棍母"

    # game/screens.rpy:1164
    old "隐藏用户界面。"
    new "棍母"

    # game/screens.rpy:1168
    old "截图。"
    new "棍母"

    # game/screens.rpy:1172
    old "切换辅助{a=https://doc.renpy.cn/zh-CN/self_voicing.html}机器朗读{/a}。"
    new "棍母"

    # game/screens.rpy:1176
    old "打开无障碍菜单。"
    new "棍母"

    # game/screens.rpy:1182
    old "左键点击"
    new "棍母"

    # game/screens.rpy:1186
    old "中键点击"
    new "棍母"

    # game/screens.rpy:1190
    old "右键点击"
    new "棍母"

    # game/screens.rpy:1194
    old "鼠标滚轮上"
    new "棍母"

    # game/screens.rpy:1198
    old "鼠标滚轮下"
    new "棍母"

    # game/screens.rpy:1205
    old "右扳机键\nA/底键"
    new "棍母"

    # game/screens.rpy:1209
    old "左扳机键\n左肩键"
    new "棍母"

    # game/screens.rpy:1213
    old "右肩键"
    new "棍母"

    # game/screens.rpy:1217
    old "十字键，摇杆"
    new "棍母"

    # game/screens.rpy:1221
    old "开始，向导，B/右键"
    new "棍母"

    # game/screens.rpy:1225
    old "Y/顶键"
    new "棍母"

    # game/screens.rpy:1291
    old "确定"
    new "棍母"

    # game/screens.rpy:1292
    old "取消"
    new "棍母"

    # game/screens.rpy:1337
    old "快进中..."
    new "棍母"

    # game/screens.rpy:1641
    old "回退"
    new "棍母"

    # game/screens.rpy:1644
    old "菜单"
    new "棍母"

