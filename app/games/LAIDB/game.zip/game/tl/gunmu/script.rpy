﻿# TODO: Translation updated at 2026-02-07 14:28

# game/script.rpy:1
translate gunmu 17b26c78:

    # "Copyright (C) 2026 moyu"
    "棍母"

# game/script.rpy:1
translate gunmu 86246a8e:

    # "This program is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version."
    "棍母"

# game/script.rpy:1
translate gunmu bf71c61e:

    # "This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details."
    "棍母"

# game/script.rpy:1
translate gunmu 82720779:

    # "You should have received a copy of the GNU Affero General Public License along with this program. If not, see <https://www.gnu.org/licenses/>."
    "棍母"

# game/script.rpy:20
translate gunmu 9cef6220:

    # "2026年1月30日 - 创建 新增demo提示 新建图像角色 2026年1月31日 - 修改部分剧情 2026年2月3日 - 新增ANe唱歌部分 新增小偷大喊 修改剧情 2026年2月4日 - 修正一些错别字 新增一些剧情 开源 修改网址 修改made in heaven部分 2026年2月5日 - 优化剧情过渡，增加场景和情绪描写 2026年2月7日 - 扩写到900句，增加大量细节描写和互动"
    "棍母"

# game/script.rpy:111
translate gunmu start_1b2d0c61:

    # "清晨的阳光透过图书馆的窗户洒了进来，空气中飘浮着细小的尘埃。"
    "棍母"

# game/script.rpy:112
translate gunmu start_09c65253:

    # "那些尘埃在光束中缓缓旋转，像微小的星星在晨光中跳舞。"
    "棍母"

# game/script.rpy:113
translate gunmu start_12a8183d:

    # "图书馆里弥漫着旧书籍特有的气味——陈年纸张、浆糊和一点点霉味的混合。"
    "棍母"

# game/script.rpy:114
translate gunmu start_495cd460:

    # "高高的书架整齐排列，上面的书籍五花八门，从厚重的百科全书到破旧的小说都有。"
    "棍母"

# game/script.rpy:116
translate gunmu start_9491f112:

    # zj "我醒来了..."
    zj "棍母"

# game/script.rpy:117
translate gunmu start_bbced2d8:

    # "我的声音在空旷的图书馆里显得格外突兀。"
    "棍母"

# game/script.rpy:118
translate gunmu start_9c102998:

    # "我揉了揉眼睛，试图适应这陌生的环境。"
    "棍母"

# game/script.rpy:120
translate gunmu start_af4fe5e6:

    # zj "这是哪里?"
    zj "棍母"

# game/script.rpy:121
translate gunmu start_f7c5436a:

    # "我环顾四周，试图找到任何熟悉的线索。"
    "棍母"

# game/script.rpy:122
translate gunmu start_883eefe5:

    # "但这里的一切都那么陌生，却又隐隐有种奇怪的熟悉感。"
    "棍母"

# game/script.rpy:124
translate gunmu start_90eb3f87:

    # "我发现自己正躺在一个陌生的房间里"
    "棍母"

# game/script.rpy:125
translate gunmu start_e893c07d:

    # "更准确地说，是躺在图书馆的地板上。"
    "棍母"

# game/script.rpy:126
translate gunmu start_ff6198b1:

    # "硬木地板冰凉，透过薄薄的衣物传来阵阵凉意。"
    "棍母"

# game/script.rpy:128
translate gunmu start_46f4b76c:

    # "这里很像一个图书馆，但是又有些不同，我能感觉到一股奇怪的气息。"
    "棍母"

# game/script.rpy:129
translate gunmu start_7da91db6:

    # "空气中除了旧书的气味，还有另一种微妙的、难以形容的气息。"
    "棍母"

# game/script.rpy:130
translate gunmu start_a1b6c950:

    # "那气息让我感到不安，却又莫名地有些好奇。"
    "棍母"

# game/script.rpy:132
translate gunmu start_9b77c1e8:

    # "我慢慢坐起身来，关节发出轻微的咔嗒声。"
    "棍母"

# game/script.rpy:133
translate gunmu start_b1bc32d3:

    # "看来我躺在这里有一段时间了。"
    "棍母"

# game/script.rpy:135
translate gunmu start_08923d26:

    # "这个味道....好像是......"
    "棍母"

# game/script.rpy:136
translate gunmu start_122d28f9:

    # "我仔细嗅了嗅空气。"
    "棍母"

# game/script.rpy:137
translate gunmu start_bdc86f79:

    # "空气中飘散着一丝甜香，很淡，但确实存在。"
    "棍母"

# game/script.rpy:139
translate gunmu start_b7c95e64:

    # "一股熟悉的甜香，带着某种特殊的气息。"
    "棍母"

# game/script.rpy:140
translate gunmu start_de5d3ab2:

    # "那香气有点像香草，又带着一丝柑橘的清新。"
    "棍母"

# game/script.rpy:141
translate gunmu start_030f5392:

    # "还有一种更微妙的、难以描述的气味，让我心跳莫名加快。"
    "棍母"

# game/script.rpy:143
translate gunmu start_3bd16594:

    # "让我想起了某个动漫角色..."
    "棍母"

# game/script.rpy:144
translate gunmu start_ad56e727:

    # "记忆的碎片在脑海中闪现。"
    "棍母"

# game/script.rpy:145
translate gunmu start_5e457553:

    # "粉色的头发，害羞的表情，还有那种独特的、令人难忘的气质。"
    "棍母"

# game/script.rpy:147
translate gunmu start_09d7c949:

    # zjdahan "绫地宁宁??????"
    zjdahan "棍母"

# game/script.rpy:149
translate gunmu start_0892a776:

    # "我几乎是脱口而出这个名字。"
    "棍母"

# game/script.rpy:150
translate gunmu start_d39f9e4c:

    # "声音在图书馆里回荡，然后又归于寂静。"
    "棍母"

# game/script.rpy:153
translate gunmu start_c9bf03b6:

    # "我往前走了几步，木质地板发出轻微的嘎吱声。"
    "棍母"

# game/script.rpy:154
translate gunmu start_ae3b4379:

    # "每走一步，回声就在空旷的房间里荡漾开来。"
    "棍母"

# game/script.rpy:155
translate gunmu start_fc90b362:

    # "这图书馆真大，书架高得几乎要顶到天花板。"
    "棍母"

# game/script.rpy:157
translate gunmu start_4a998405:

    # "图书馆里安静得只能听到自己的心跳声。"
    "棍母"

# game/script.rpy:158
translate gunmu start_6bb20d7c:

    # "咚...咚...咚..."
    "棍母"

# game/script.rpy:159
translate gunmu start_6f5240f0:

    # "心跳声在耳中回响，节奏快得有些不正常。"
    "棍母"

# game/script.rpy:161
translate gunmu start_b85fc187:

    # "突然,我看见了...."
    "棍母"

# game/script.rpy:163
translate gunmu start_9a9b3331:

    # "绫地宁宁"
    "棍母"

# game/script.rpy:164
translate gunmu start_542bce8e:

    # "她真的在这里。"
    "棍母"

# game/script.rpy:165
translate gunmu start_7366dab9:

    # "不是幻觉，不是想象，是真实的绫地宁宁。"
    "棍母"

# game/script.rpy:167
translate gunmu start_8175ba7d:

    # "她正在图书馆桌子的一角"
    "棍母"

# game/script.rpy:168
translate gunmu start_3fafed8b:

    # "蜷缩在角落里，背靠着书架。"
    "棍母"

# game/script.rpy:169
translate gunmu start_ad71318e:

    # "午后的阳光透过高处的窗户斜照在她身上。"
    "棍母"

# game/script.rpy:171
translate gunmu start_7384da24:

    # "午后的阳光斜照在她身上，给她的轮廓镀上了一层金边。"
    "棍母"

# game/script.rpy:172
translate gunmu start_5179ce53:

    # "那光芒温柔地抚摸着她浅色的头发，让她看起来像在发光。"
    "棍母"

# game/script.rpy:173
translate gunmu start_c3296766:

    # "光线在她脸上投下柔和的阴影，让她的表情有些难以看清。"
    "棍母"

# game/script.rpy:175
translate gunmu start_898f2ccc:

    # "然而她的表情...她的动作..."
    "棍母"

# game/script.rpy:176
translate gunmu start_d0364229:

    # "她的脸颊泛着不自然的红晕。"
    "棍母"

# game/script.rpy:177
translate gunmu start_21f1ee29:

    # "她的呼吸有些急促，胸口微微起伏。"
    "棍母"

# game/script.rpy:178
translate gunmu start_97d7a135:

    # "她的手似乎在桌子下做什么动作，我看不太清楚。"
    "棍母"

# game/script.rpy:180
translate gunmu start_bd2dff96:

    # "疯狂的...0721?"
    "棍母"

# game/script.rpy:181
translate gunmu start_e57eba4a:

    # "0721...这个数字突然跳进我的脑海。"
    "棍母"

# game/script.rpy:182
translate gunmu start_0ca487d8:

    # "我一时想不起它有什么特殊含义，只是觉得熟悉。"
    "棍母"

# game/script.rpy:185
translate gunmu start_dc10d08a:

    # "我的大脑一时无法处理眼前的信息。"
    "棍母"

# game/script.rpy:186
translate gunmu start_b33be9c6:

    # "这是什么情况？我为什么会在这里？"
    "棍母"

# game/script.rpy:187
translate gunmu start_878b9cdd:

    # "为什么绫地宁宁会在这里？她为什么是那种表情？"
    "棍母"

# game/script.rpy:189
translate gunmu start_44f63631:

    # "突然,她抬起了头"
    "棍母"

# game/script.rpy:190
translate gunmu start_0f5576af:

    # "动作有些慌张，像是受惊的小动物。"
    "棍母"

# game/script.rpy:191
translate gunmu start_3a63949b:

    # "可能是看见了我在看她0721"
    "棍母"

# game/script.rpy:193
translate gunmu start_bdeb498d:

    # ANe "(愣住)...."
    ANe "棍母"

# game/script.rpy:194
translate gunmu start_2441604e:

    # "她完全僵住了。"
    "棍母"

# game/script.rpy:195
translate gunmu start_ca30523f:

    # "眼睛瞪得圆圆的，嘴唇微微张开。"
    "棍母"

# game/script.rpy:196
translate gunmu start_c2cdd66f:

    # "手里的动作完全停止了。"
    "棍母"

# game/script.rpy:198
translate gunmu start_889be115:

    # "时间仿佛凝固了。她的脸上露出了惊讶的表情，随后是慌乱，最后变成了一片空白。"
    "棍母"

# game/script.rpy:199
translate gunmu start_dbbf3567:

    # "惊讶→慌乱→空白，三种情绪在几秒钟内迅速转换。"
    "棍母"

# game/script.rpy:200
translate gunmu start_c3746869:

    # "最后她的脸上什么表情都没有了，就像一张白纸。"
    "棍母"

# game/script.rpy:202
translate gunmu start_3aff78f7:

    # zj "啊,那个.........."
    zj "棍母"

# game/script.rpy:203
translate gunmu start_eba1f0f9:

    # "我试图说点什么打破沉默。"
    "棍母"

# game/script.rpy:204
translate gunmu start_6b27e077:

    # "但大脑一片空白，什么话都想不出来。"
    "棍母"

# game/script.rpy:206
translate gunmu start_ea0a8af9:

    # "空气突然变得有些尴尬，仿佛连空气都凝固了。"
    "棍母"

# game/script.rpy:207
translate gunmu start_2bb0d797:

    # "细小的尘埃在阳光中静止了，不再飘浮。"
    "棍母"

# game/script.rpy:208
translate gunmu start_bb49e7bc:

    # "连呼吸声都变得小心翼翼。"
    "棍母"

# game/script.rpy:213
translate gunmu start_71a6f79b:

    # "几秒钟的沉默后，黑暗中传来了她颤抖的声音。"
    "棍母"

# game/script.rpy:214
translate gunmu start_fca6166c:

    # "那声音很轻，几乎要被心跳声淹没。"
    "棍母"

# game/script.rpy:215
translate gunmu start_85afdc53:

    # "但在这绝对的寂静中，又清晰得刺耳。"
    "棍母"

# game/script.rpy:217
translate gunmu start_7b6160d3:

    # ANe "你...你是谁?"
    ANe "棍母"

# game/script.rpy:218
translate gunmu start_d20448a7:

    # "宁宁说着,她的声音有些颤抖，像是在努力控制情绪。"
    "棍母"

# game/script.rpy:219
translate gunmu start_af0784c8:

    # "但控制得并不成功，声音里的颤抖很明显。"
    "棍母"

# game/script.rpy:221
translate gunmu start_cb7687ea:

    # ANe "(黑脸)"
    ANe "棍母"

# game/script.rpy:222
translate gunmu start_37f90f02:

    # "我能想象她现在的表情。"
    "棍母"

# game/script.rpy:223
translate gunmu start_af6c29e1:

    # "一定是那种又羞又怒，恨不得找个地缝钻进去的样子。"
    "棍母"

# game/script.rpy:225
translate gunmu start_b8dddf76:

    # "我能感觉到她正在积聚力量，就像暴风雨前的宁静。"
    "棍母"

# game/script.rpy:226
translate gunmu start_da2b093b:

    # "空气的压力似乎在增加。"
    "棍母"

# game/script.rpy:227
translate gunmu start_2569f373:

    # "温度在下降，让我打了个寒颤。"
    "棍母"

# game/script.rpy:229
translate gunmu start_26a398e8:

    # ANedahan "hentai!!!!!!!!!!!!!"
    ANedahan "棍母"

# game/script.rpy:230
translate gunmu start_582c7821:

    # "她突然喊了出来。"
    "棍母"

# game/script.rpy:231
translate gunmu start_13ad62a8:

    # "声音比我想象的还要大，还要尖锐。"
    "棍母"

# game/script.rpy:234
translate gunmu start_bee469ac:

    # ANe "hentai hentai hentai!!!!!!!!!!!"
    ANe "棍母"

# game/script.rpy:235
translate gunmu start_3aa3e282:

    # "绫地宁宁说着,她的脸涨得通红，声音中带着羞耻和愤怒。"
    "棍母"

# game/script.rpy:236
translate gunmu start_b14cfce9:

    # "从脸颊一直红到耳根，甚至能看到脖子都泛着红晕。"
    "棍母"

# game/script.rpy:238
translate gunmu start_bdd496b1:

    # "她突然站了起来,看起来非常激动，身体微微发抖。"
    "棍母"

# game/script.rpy:239
translate gunmu start_a305a5cd:

    # "椅子腿在地板上刮出刺耳的声音。"
    "棍母"

# game/script.rpy:240
translate gunmu start_3de0a219:

    # "她的双手紧紧握成拳头，指节都发白了。"
    "棍母"

# game/script.rpy:242
translate gunmu start_197e6a39:

    # zj "啊,那个...别激动..."
    zj "棍母"

# game/script.rpy:243
translate gunmu start_de6bbc66:

    # "我试图安抚她，但发现自己的声音也在颤抖。"
    "棍母"

# game/script.rpy:244
translate gunmu start_a09e448c:

    # "完全不像平时的自己，声音又细又抖。"
    "棍母"

# game/script.rpy:246
translate gunmu start_d5af036d:

    # zj "(我又不是故意的)"
    zj "棍母"

# game/script.rpy:249
translate gunmu start_64b263b4:

    # "我内心辩解着，但这话显然不能说出口。"
    "棍母"

# game/script.rpy:250
translate gunmu start_eb5763b6:

    # "说了只会让情况更糟，火上浇油。"
    "棍母"

# game/script.rpy:252
translate gunmu start_425c8765:

    # "绫地宁宁突然扑向了我，眼中含着泪光。"
    "棍母"

# game/script.rpy:253
translate gunmu start_78cb68f9:

    # "那泪水在眼眶中打转，折射着窗外的阳光。"
    "棍母"

# game/script.rpy:254
translate gunmu start_dd218a86:

    # "她的动作很快，我几乎来不及反应。"
    "棍母"

# game/script.rpy:256
translate gunmu start_9d060e16:

    # "就在这混乱的一瞬间..."
    "棍母"

# game/script.rpy:257
translate gunmu start_a6455363:

    # "突然...她的底下掉出来了什么东西"
    "棍母"

# game/script.rpy:261
translate gunmu start_d8ca1554:

    # "一个物体落在地板上。"
    "棍母"

# game/script.rpy:262
translate gunmu start_8ffc0e30:

    # "发出清脆的金属撞击声。"
    "棍母"

# game/script.rpy:264
translate gunmu start_d1033a88:

    # zj "这是..."
    zj "棍母"

# game/script.rpy:265
translate gunmu start_aece9240:

    # "我们两人都愣住了，时间仿佛又停滞了一秒。"
    "棍母"

# game/script.rpy:266
translate gunmu start_badc0625:

    # "两人都盯着地上的那个东西，一动不动。"
    "棍母"

# game/script.rpy:268
translate gunmu start_8d324a97:

    # "我看见了她掉出来的东西"
    "棍母"

# game/script.rpy:269
translate gunmu start_41730d8f:

    # "是一个奇怪的东西,有一个加减按钮,和一个大大的红色按钮"
    "棍母"

# game/script.rpy:270
translate gunmu start_634da1db:

    # "银色的外壳，设计简洁但有种说不出的怪异感。"
    "棍母"

# game/script.rpy:273
translate gunmu start_69d7555a:

    # "我好奇地拿起了那个东西，冰凉的手感让我打了个寒颤。"
    "棍母"

# game/script.rpy:274
translate gunmu start_f4ce7dc6:

    # "金属表面光滑得不可思议，几乎能当镜子用。"
    "棍母"

# game/script.rpy:275
translate gunmu start_9fc00204:

    # "重量比看起来要轻，但拿在手里有种沉甸甸的感觉。"
    "棍母"

# game/script.rpy:277
translate gunmu start_17c845f6:

    # qbq "(os:我这是被谁捡起来了)"
    qbq "棍母"

# game/script.rpy:278
translate gunmu start_4d27fb09:

    # "一个机械的声音在我脑海中响起。"
    "棍母"

# game/script.rpy:279
translate gunmu start_c4d93eed:

    # "不是通过耳朵听到的，而是直接出现在意识里。"
    "棍母"

# game/script.rpy:280
translate gunmu start_f89df727:

    # "那种感觉很奇怪，就像有人在脑子里说话。"
    "棍母"

# game/script.rpy:282
translate gunmu start_72014fda:

    # qbq "我只知道,0d00是我主人"
    qbq "棍母"

# game/script.rpy:283
translate gunmu start_fc3c9bb3:

    # "那个声音继续说着。"
    "棍母"

# game/script.rpy:284
translate gunmu start_99664d85:

    # "语气很平淡，没有任何感情色彩。"
    "棍母"

# game/script.rpy:286
translate gunmu start_2ab46138:

    # qbq "我被设计成可以引发强烈的快感(大虚)"
    qbq "棍母"

# game/script.rpy:287
translate gunmu start_13b4a57a:

    # "我手一抖，差点把东西扔出去。"
    "棍母"

# game/script.rpy:288
translate gunmu start_1a732887:

    # "这句话的信息量太大了，我的大脑需要时间处理。"
    "棍母"

# game/script.rpy:290
translate gunmu start_4e5da549:

    # "此时,绫地宁宁的脸已经红得像熟透的苹果一样，从耳根一直红到脖子。"
    "棍母"

# game/script.rpy:291
translate gunmu start_858b52fa:

    # "红得几乎要滴出血来。"
    "棍母"

# game/script.rpy:292
translate gunmu start_de423a1e:

    # "我能看到她的颈动脉在快速跳动，一下又一下。"
    "棍母"

# game/script.rpy:294
translate gunmu start_61aa5568:

    # "她的眼神中充满了愤怒和害羞，还有一丝绝望。"
    "棍母"

# game/script.rpy:295
translate gunmu start_dbd067df:

    # "像是被看到了最不想被人知道的秘密。"
    "棍母"

# game/script.rpy:296
translate gunmu start_affc2ded:

    # "那种混合的情绪在她眼中翻腾，几乎要溢出来。"
    "棍母"

# game/script.rpy:298
translate gunmu start_b1ec8d4e:

    # "(她不害羞吗?雨姐已经看见她在0721和她的调单了)"
    "棍母"

# game/script.rpy:299
translate gunmu start_9e2d53b8:

    # "这个想法不合时宜地冒出来。"
    "棍母"

# game/script.rpy:300
translate gunmu start_15ef2867:

    # "但我马上意识到 雨姐 是谁？我为什么会想到这个名字？"
    "棍母"

# game/script.rpy:302
translate gunmu start_1225e195:

    # ANe "(黑着脸)"
    ANe "棍母"

# game/script.rpy:303
translate gunmu start_64b1b28d:

    # "她的声音像是从牙缝里挤出来的。"
    "棍母"

# game/script.rpy:304
translate gunmu start_aaed188e:

    # "每个字都咬得很重，充满了压抑的怒火。"
    "棍母"

# game/script.rpy:306
translate gunmu start_6afdebcf:

    # ANe "把那个东西还给我!"
    ANe "棍母"

# game/script.rpy:307
translate gunmu start_3a832c77:

    # "...空气再次变得紧张起来，仿佛一根绷紧的弦。"
    "棍母"

# game/script.rpy:308
translate gunmu start_798a390f:

    # "随时可能断裂，引发无法预料的后果。"
    "棍母"

# game/script.rpy:310
translate gunmu start_35fcafb2:

    # zj "啊,这个...我只是好奇..."
    zj "棍母"

# game/script.rpy:311
translate gunmu start_9ceaef42:

    # "我试图解释，但显然这个解释苍白无力。"
    "棍母"

# game/script.rpy:312
translate gunmu start_16a6c30a:

    # "连我自己都不相信，更别说她了。"
    "棍母"

# game/script.rpy:314
translate gunmu start_d5a2eb12:

    # ANedahan "还给我!!!!!"
    ANedahan "棍母"

# game/script.rpy:315
translate gunmu start_0eda1038:

    # "绫地宁宁大喊着,她的声音充满了愤怒，还带着一丝哭腔。"
    "棍母"

# game/script.rpy:316
translate gunmu start_fa0ee6f9:

    # "那声音里有一种破罐破摔的绝望感。"
    "棍母"

# game/script.rpy:318
translate gunmu start_334e840c:

    # "她突然冲向我,试图抢回那个东西，动作快得惊人。"
    "棍母"

# game/script.rpy:319
translate gunmu start_3fd5ef44:

    # "几乎是扑过来的，完全不顾形象了。"
    "棍母"

# game/script.rpy:321
translate gunmu start_57a1de70:

    # "我慌忙后退,试图躲避她的攻击，脚下的书本被踢得到处都是。"
    "棍母"

# game/script.rpy:322
translate gunmu start_4829c1d3:

    # "一本厚重的硬皮书滑到墙角，发出沉闷的撞击声。"
    "棍母"

# game/script.rpy:323
translate gunmu start_402c1ca5:

    # "几本平装书散开，书页飞舞。"
    "棍母"

# game/script.rpy:325
translate gunmu start_8fbbc0c2:

    # "但是,绫地宁宁太激动了，像一只被惹怒的小猫。"
    "棍母"

# game/script.rpy:326
translate gunmu start_c9129dda:

    # "毛发竖起，爪子全开，不顾一切地要夺回自己的东西。"
    "棍母"

# game/script.rpy:328
translate gunmu start_fa28ce26:

    # ANe "还给我!还给我!还给我!还给我!...."
    ANe "棍母"

# game/script.rpy:329
translate gunmu start_79347864:

    # "她不停地冲向我,试图抢回那个东西，完全不顾自己的形象了。"
    "棍母"

# game/script.rpy:330
translate gunmu start_0daec832:

    # "头发散乱，呼吸急促，眼睛红红的。"
    "棍母"

# game/script.rpy:332
translate gunmu start_63869fd3:

    # zj "(我得想个办法平息她的情绪)"
    zj "棍母"

# game/script.rpy:333
translate gunmu start_96ef4889:

    # "我深吸一口气，强迫自己冷静下来。"
    "棍母"

# game/script.rpy:334
translate gunmu start_a6fd4b0c:

    # "尽管心脏还在狂跳，手也在发抖。"
    "棍母"

# game/script.rpy:336
translate gunmu start_1dc6d503:

    # "我把那个东西放在桌子上，举起双手表示投降。"
    "棍母"

# game/script.rpy:337
translate gunmu start_de01010b:

    # "手掌朝向天花板，表示我没有恶意。"
    "棍母"

# game/script.rpy:338
translate gunmu start_8b3f5927:

    # "动作尽量缓慢，不刺激到她。"
    "棍母"

# game/script.rpy:340
translate gunmu start_30f8b257:

    # zj "宁宁,冷静点..."
    zj "棍母"

# game/script.rpy:341
translate gunmu start_3d7ba69e:

    # "我的声音尽量平和。"
    "棍母"

# game/script.rpy:342
translate gunmu start_656507ca:

    # "虽然心里慌得要死，但表面要保持镇定。"
    "棍母"

# game/script.rpy:344
translate gunmu start_fb73aba2:

    # zj "我们可以好好谈谈的..."
    zj "棍母"

# game/script.rpy:345
translate gunmu start_f3222428:

    # "主角被宁宁吓到了，心脏怦怦直跳。"
    "棍母"

# game/script.rpy:346
translate gunmu start_5a76763a:

    # "像是要跳出胸腔，撞得胸口发疼。"
    "棍母"

# game/script.rpy:348
translate gunmu start_f7eb634a:

    # zj "(震惊我2778年)"
    zj "棍母"

# game/script.rpy:349
translate gunmu start_42c9ac3d:

    # "这个网络用语不合时宜地冒出来。"
    "棍母"

# game/script.rpy:350
translate gunmu start_6451a87d:

    # "在这种紧张的时刻，大脑总会冒出奇怪的东西。"
    "棍母"

# game/script.rpy:352
translate gunmu start_30a0d874:

    # "绫地宁宁终于停下了脚步，胸膛因为喘息而起伏着。"
    "棍母"

# game/script.rpy:353
translate gunmu start_45eb13dd:

    # "她的呼吸很重，肩膀一起一伏。"
    "棍母"

# game/script.rpy:354
translate gunmu start_de95b643:

    # "眼睛死死盯着桌上的东西，又看看我。"
    "棍母"

# game/script.rpy:356
translate gunmu start_bb646012:

    # "了吗?"
    "棍母"

# game/script.rpy:357
translate gunmu start_57281866:

    # "她发出一个短促的音节。"
    "棍母"

# game/script.rpy:358
translate gunmu start_456b9304:

    # "声音还是很愤怒，但似乎稍微平静了一点。"
    "棍母"

# game/script.rpy:361
translate gunmu start_56799062:

    # "就在这时，我脚下一滑，踩到了一本掉落的书。"
    "棍母"

# game/script.rpy:362
translate gunmu start_fb6aa28c:

    # "书皮光滑，没有摩擦力。"
    "棍母"

# game/script.rpy:363
translate gunmu start_b7dc2c10:

    # "我失去平衡，向后倒去。"
    "棍母"

# game/script.rpy:366
translate gunmu start_9a4ae7f2:

    # "我和绫地宁宁一起摔倒了，倒在了散落一地的书本上。"
    "棍母"

# game/script.rpy:367
translate gunmu start_78ff847c:

    # "两人撞在一起，倒在书堆里。"
    "棍母"

# game/script.rpy:369
translate gunmu start_6ba44237:

    # landy "啊!"
    landy "棍母"

# game/script.rpy:370
translate gunmu start_fad3b669:

    # "两声惊呼重叠在一起。"
    "棍母"

# game/script.rpy:371
translate gunmu start_72b041bd:

    # "她的声音比我高一个八度。"
    "棍母"

# game/script.rpy:373
translate gunmu start_5d5b0b6c:

    # "我们纠缠在一起，场面更加混乱了。"
    "棍母"

# game/script.rpy:374
translate gunmu start_16a3b886:

    # "我的手肘撞到了书架，疼得我倒吸一口冷气。"
    "棍母"

# game/script.rpy:375
translate gunmu start_04426fc7:

    # "她的膝盖顶到了我的肚子，让我差点吐出来。"
    "棍母"

# game/script.rpy:377
translate gunmu start_10128837:

    # yudejiao "(带派不老铁)"
    yudejiao "棍母"

# game/script.rpy:378
translate gunmu start_1f5aa082:

    # "又一句奇怪的话。"
    "棍母"

# game/script.rpy:379
translate gunmu start_3c16f8b8:

    # "不知从哪里冒出来的声音。"
    "棍母"

# game/script.rpy:382
translate gunmu start_956ce3b5:

    # "就在这时，整个图书馆开始震动，书本从书架上掉落。"
    "棍母"

# game/script.rpy:383
translate gunmu start_7b045b15:

    # "书架剧烈摇晃，发出嘎吱嘎吱的声音。"
    "棍母"

# game/script.rpy:384
translate gunmu start_e98661ed:

    # "书本像雨点一样落下，在地上堆成小山。"
    "棍母"

# game/script.rpy:386
translate gunmu start_d9926332:

    # "神秘人" "made in heaven!!!"
    "神秘人" "棍母"

# game/script.rpy:387
translate gunmu start_6541462a:

    # "一个声音响起。"
    "棍母"

# game/script.rpy:388
translate gunmu start_a31f2404:

    # "不是来自任何一个人。"
    "棍母"

# game/script.rpy:389
translate gunmu start_d637cd72:

    # "而是来自空间本身，从四面八方传来。"
    "棍母"

# game/script.rpy:393
translate gunmu start_84cab918:

    # "刺眼的白光充满了整个空间。"
    "棍母"

# game/script.rpy:394
translate gunmu start_347a3eeb:

    # "我不得不闭上眼睛，但那白光还是透过眼皮刺进来。"
    "棍母"

# game/script.rpy:395
translate gunmu start_970e6117:

    # "周围的一切都消失了，只剩下无尽的白。"
    "棍母"

# game/script.rpy:397
translate gunmu start_c97cf018:

    # "周围的一切开始加速旋转——"
    "棍母"

# game/script.rpy:398
translate gunmu start_070ebb75:

    # "地板、书架、书本、光芒，所有东西都在旋转。"
    "棍母"

# game/script.rpy:399
translate gunmu start_0f5f5d4e:

    # "像是被扔进了洗衣机，天旋地转。"
    "棍母"

# game/script.rpy:401
translate gunmu start_c1604178:

    # landy "怎么回事?!"
    landy "棍母"

# game/script.rpy:402
translate gunmu start_d8dca937:

    # "我能感觉到时间和空间正在扭曲。"
    "棍母"

# game/script.rpy:403
translate gunmu start_4b5b3171:

    # "胃里翻江倒海，头晕目眩。"
    "棍母"

# game/script.rpy:407
translate gunmu start_61d711e6:

    # "时间开始加速——"
    "棍母"

# game/script.rpy:408
translate gunmu start_03a7f0fc:

    # "就像录像带被快进，无数影像从眼前闪过。"
    "棍母"

# game/script.rpy:409
translate gunmu start_ec4ffe15:

    # "模糊的色彩和形状，破碎的声音和画面。"
    "棍母"

# game/script.rpy:411
translate gunmu start_515eade9:

    # "再次睁眼,来到了2017年的.."
    "棍母"

# game/script.rpy:412
translate gunmu start_d3b8c1b8:

    # "这是?"
    "棍母"

# game/script.rpy:413
translate gunmu start_f97e71d1:

    # "眼前的景象从模糊逐渐清晰。"
    "棍母"

# game/script.rpy:414
translate gunmu start_852209b6:

    # "像是镜头在对焦，一点点变得清楚。"
    "棍母"

# game/script.rpy:418
translate gunmu start_d8ebc92b:

    # "喧闹的街道，复古的招牌，完全不同的时代气息。"
    "棍母"

# game/script.rpy:419
translate gunmu start_1a8f8b6b:

    # "人们的穿着打扮都很怀旧。"
    "棍母"

# game/script.rpy:420
translate gunmu start_abb21fbf:

    # "街边的店铺招牌还是那种老式的灯箱。"
    "棍母"

# game/script.rpy:422
translate gunmu start_180e33ba:

    # landyh "沈阳大街?"
    landyh "棍母"

# game/script.rpy:423
translate gunmu start_4eba0ac0:

    # "我看到了路牌。"
    "棍母"

# game/script.rpy:424
translate gunmu start_3d0f14f0:

    # "蓝底白字，写着沈阳大街。"
    "棍母"

# game/script.rpy:426
translate gunmu start_725aac65:

    # "我们往四周看了看，两人都一脸茫然。"
    "棍母"

# game/script.rpy:427
translate gunmu start_e0e532dd:

    # "完全搞不清楚状况。"
    "棍母"

# game/script.rpy:428
translate gunmu start_33db4eff:

    # "刚才还在图书馆，怎么突然就到街上了？"
    "棍母"

# game/script.rpy:430
translate gunmu start_5f9b772e:

    # "...."
    "棍母"

# game/script.rpy:433
translate gunmu start_72567cc8:

    # "汽车的声音、人们的谈话声、街边店铺的音乐声交织在一起。"
    "棍母"

# game/script.rpy:434
translate gunmu start_6d37b388:

    # "形成一种热闹的都市背景音。"
    "棍母"

# game/script.rpy:435
translate gunmu start_75274a62:

    # "和刚才图书馆的寂静形成鲜明对比。"
    "棍母"

# game/script.rpy:437
translate gunmu start_b38f35fb:

    # "这是..."
    "棍母"

# game/script.rpy:438
translate gunmu start_a35d3998:

    # "我的大脑还在处理信息。"
    "棍母"

# game/script.rpy:439
translate gunmu start_df6b0c78:

    # "试图理解这突如其来的变化。"
    "棍母"

# game/script.rpy:441
translate gunmu start_404ef78c:

    # "远处的一群人吸引了我们的注意。"
    "棍母"

# game/script.rpy:442
translate gunmu start_60407128:

    # "大约十几个人聚在一起。"
    "棍母"

# game/script.rpy:443
translate gunmu start_3baeffc8:

    # "吵吵闹闹的，很引人注目。"
    "棍母"

# game/script.rpy:445
translate gunmu start_33c92a5e:

    # "虎哥?!"
    "棍母"

# game/script.rpy:446
translate gunmu start_a8cdc2eb:

    # "我认出了那个标志性的人物。"
    "棍母"

# game/script.rpy:447
translate gunmu start_97836bdc:

    # "标志性的发型，标志性的穿着。"
    "棍母"

# game/script.rpy:449
translate gunmu start_a75bf5ae:

    # "(虎哥他们正在拍视频)"
    "棍母"

# game/script.rpy:450
translate gunmu start_7c4002ed:

    # "宁宁小声说。"
    "棍母"

# game/script.rpy:451
translate gunmu start_7a4fd9f8:

    # "她的声音里充满了困惑。"
    "棍母"

# game/script.rpy:453
translate gunmu start_d60cf6d1:

    # "他们穿着那个年代特有的服装。"
    "棍母"

# game/script.rpy:454
translate gunmu start_7bb51e94:

    # "宽松的T恤，紧身裤。"
    "棍母"

# game/script.rpy:455
translate gunmu start_b975ed66:

    # "有些人还戴着夸张的饰品。"
    "棍母"

# game/script.rpy:457
translate gunmu start_86174381:

    # "举着手机自拍杆。"
    "棍母"

# game/script.rpy:458
translate gunmu start_5159604b:

    # "那时候的自拍杆还很新鲜。"
    "棍母"

# game/script.rpy:459
translate gunmu start_1f3446c8:

    # "大家都在用这种新奇的设备。"
    "棍母"

# game/script.rpy:461
translate gunmu start_51bc96ba:

    # huandxd "来来来兄弟们"
    huandxd "棍母"

# game/script.rpy:462
translate gunmu start_2c7f7b14:

    # "一个小弟对着镜头喊。"
    "棍母"

# game/script.rpy:464
translate gunmu start_ad1101a0:

    # huge "兄弟萌！全体目光向我看齐！"
    huge "棍母"

# game/script.rpy:465
translate gunmu start_a3f909ca:

    # "虎哥张开双臂。"
    "棍母"

# game/script.rpy:466
translate gunmu start_03bb3b01:

    # "动作夸张，气势十足。"
    "棍母"

# game/script.rpy:468
translate gunmu start_03c1a229:

    # huge "我宣布个事！"
    huge "棍母"

# game/script.rpy:469
translate gunmu start_b3af091a:

    # "停顿一下制造悬念。"
    "棍母"

# game/script.rpy:470
translate gunmu start_b5d08971:

    # "所有人都看着他，等待下文。"
    "棍母"

# game/script.rpy:472
translate gunmu start_6642a702:

    # huge "我是个"
    huge "棍母"

# game/script.rpy:473
translate gunmu start_47be5266:

    # "拉长声音。"
    "棍母"

# game/script.rpy:474
translate gunmu start_acb17b72:

    # "表情严肃，像是在宣布什么重大消息。"
    "棍母"

# game/script.rpy:476
translate gunmu start_a1f20c78:

    # hugeg "sb!"
    hugeg "棍母"

# game/script.rpy:477
translate gunmu start_bb4284fc:

    # "最后两个字脱口而出。"
    "棍母"

# game/script.rpy:478
translate gunmu start_9a9240b3:

    # "语气认真得可笑。"
    "棍母"

# game/script.rpy:480
translate gunmu start_6a83e2ba:

    # "(.....)"
    "棍母"

# game/script.rpy:481
translate gunmu start_2e52a9da:

    # "宁宁完全看不懂这种幽默。"
    "棍母"

# game/script.rpy:482
translate gunmu start_67dd7c3e:

    # "她歪着头，一脸困惑。"
    "棍母"

# game/script.rpy:484
translate gunmu start_8fee7631:

    # "我们两人对视一眼，都能看到对方眼中的困惑和惊讶。"
    "棍母"

# game/script.rpy:485
translate gunmu start_c912a4cd:

    # "两人都是同样的表情：这什么情况？"
    "棍母"

# game/script.rpy:487
translate gunmu start_51547266:

    # landy "虎哥的小弟们搁那聚堆儿呢，社会摇都快给我整出来了……"
    landy "棍母"

# game/script.rpy:488
translate gunmu start_fa54a9ff:

    # "一个人开始扭动身体。"
    "棍母"

# game/script.rpy:489
translate gunmu start_c593b29c:

    # "动作夸张，节奏感很强。"
    "棍母"

# game/script.rpy:491
translate gunmu start_c3a9787b:

    # "这时,虎哥看到了一旁的东北雨姐，眼睛一亮。"
    "棍母"

# game/script.rpy:492
translate gunmu start_474df158:

    # "像是发现了宝藏。"
    "棍母"

# game/script.rpy:493
translate gunmu start_db931217:

    # "脸上立刻露出热情的笑容。"
    "棍母"

# game/script.rpy:495
translate gunmu start_869a184e:

    # huge "哟,这不是我雨姐吗!"
    huge "棍母"

# game/script.rpy:496
translate gunmu start_a1630c1b:

    # "他大声打招呼。"
    "棍母"

# game/script.rpy:497
translate gunmu start_08c4a923:

    # "声音洪亮，整条街都能听到。"
    "棍母"

# game/script.rpy:499
translate gunmu start_7dbbf89f:

    # huge "那个卖粉(土豆粉)的那个。"
    huge "棍母"

# game/script.rpy:500
translate gunmu start_609d9cce:

    # "他强调道。"
    "棍母"

# game/script.rpy:501
translate gunmu start_1db64e90:

    # "生怕别人不知道雨姐是做什么的。"
    "棍母"

# game/script.rpy:503
translate gunmu start_350685ca:

    # huge "走!带你看看我的小弟"
    huge "棍母"

# game/script.rpy:504
translate gunmu start_148e0cf5:

    # "虎哥热情地走过来。"
    "棍母"

# game/script.rpy:505
translate gunmu start_34b26719:

    # "拍了拍雨姐的肩膀。"
    "棍母"

# game/script.rpy:507
translate gunmu start_f1eab463:

    # "力道大得让雨姐晃了一下。"
    "棍母"

# game/script.rpy:508
translate gunmu start_bb5bd357:

    # "虎哥的手劲真不小。"
    "棍母"

# game/script.rpy:510
translate gunmu start_f39f0e78:

    # "此时,虎哥注意到了一旁的绫地宁宁。"
    "棍母"

# game/script.rpy:511
translate gunmu start_a9a42827:

    # "他仔细打量。"
    "棍母"

# game/script.rpy:512
translate gunmu start_aaa48ee9:

    # "眼睛上下扫视，但没有什么恶意。"
    "棍母"

# game/script.rpy:514
translate gunmu start_ed3009b6:

    # huge "这妹子是谁啊？"
    huge "棍母"

# game/script.rpy:515
translate gunmu start_b1632671:

    # "看着面生，但咋又有点眼熟？"
    "棍母"

# game/script.rpy:516
translate gunmu start_07d42754:

    # "他挠了挠头，像是在回忆什么。"
    "棍母"

# game/script.rpy:518
translate gunmu start_c8c20ff0:

    # "宁宁紧张地往后缩了缩。"
    "棍母"

# game/script.rpy:519
translate gunmu start_87ff577c:

    # "试图躲在雨姐身后。"
    "棍母"

# game/script.rpy:520
translate gunmu start_764b37a2:

    # "但虎哥的视线还是跟着她。"
    "棍母"

# game/script.rpy:522
translate gunmu start_8608d27c:

    # ANe "……私は綾地寧々です……"
    ANe "棍母"

# game/script.rpy:523
translate gunmu start_95adeda3:

    # "她用日语小声说。"
    "棍母"

# game/script.rpy:524
translate gunmu start_0dc6785b:

    # "声音轻得像蚊子叫。"
    "棍母"

# game/script.rpy:526
translate gunmu start_9f4c760d:

    # ANe "(我是绫地宁宁)"
    ANe "棍母"

# game/script.rpy:527
translate gunmu start_3174e134:

    # "她补充了中文翻译。"
    "棍母"

# game/script.rpy:528
translate gunmu start_68d06af3:

    # "声音还是很轻，但至少能听清了。"
    "棍母"

# game/script.rpy:530
translate gunmu start_1191b3b9:

    # zj "虎哥你咋在这儿呢？"
    zj "棍母"

# game/script.rpy:531
translate gunmu start_bbb264c6:

    # "雨姐问道。"
    "棍母"

# game/script.rpy:532
translate gunmu start_f4f7418c:

    # "她试图理解现状。"
    "棍母"

# game/script.rpy:534
translate gunmu start_13c87d75:

    # zj "这不2017年吗？"
    zj "棍母"

# game/script.rpy:535
translate gunmu start_161a0ccb:

    # "她看了看周围的环境。"
    "棍母"

# game/script.rpy:536
translate gunmu start_38d6093f:

    # "确实像是几年前的样子。"
    "棍母"

# game/script.rpy:538
translate gunmu start_1e159c25:

    # huge "啥2017不2017的。"
    huge "棍母"

# game/script.rpy:539
translate gunmu start_8b308a25:

    # "虎哥一脸不解。"
    "棍母"

# game/script.rpy:540
translate gunmu start_e82d5f58:

    # "显然没听懂雨姐在说什么。"
    "棍母"

# game/script.rpy:542
translate gunmu start_9b025d46:

    # huge "这不搁沈阳大街拍视频呢嘛！"
    huge "棍母"

# game/script.rpy:543
translate gunmu start_f6a46fc6:

    # "他指了指周围。"
    "棍母"

# game/script.rpy:544
translate gunmu start_9bd566b0:

    # "像是觉得雨姐在开玩笑。"
    "棍母"

# game/script.rpy:546
translate gunmu start_b78d5f77:

    # "虎哥挠了挠头。"
    "棍母"

# game/script.rpy:547
translate gunmu start_7c74417e:

    # "一脸迷惑。"
    "棍母"

# game/script.rpy:548
translate gunmu start_24ce6100:

    # "显然没理解雨姐的话。"
    "棍母"

# game/script.rpy:550
translate gunmu start_3ae065d2:

    # hugexiaodi "虎哥，这俩妹子长得挺带劲啊！"
    hugexiaodi "棍母"

# game/script.rpy:551
translate gunmu start_94952327:

    # "一个小弟凑过来。"
    "棍母"

# game/script.rpy:552
translate gunmu start_6d3ee528:

    # "眼睛在两人身上打转。"
    "棍母"

# game/script.rpy:554
translate gunmu start_d11a6570:

    # hugexiaodi "尤其是那个短头发的。"
    hugexiaodi "棍母"

# game/script.rpy:555
translate gunmu start_747d1d30:

    # "他指着雨姐。"
    "棍母"

# game/script.rpy:556
translate gunmu start_1e2549e2:

    # "雨姐的短发确实很显精神。"
    "棍母"

# game/script.rpy:558
translate gunmu start_f34d368d:

    # hugexiaodi "看着像咱东北老妹儿！"
    hugexiaodi "棍母"

# game/script.rpy:559
translate gunmu start_4127adc3:

    # "那必须的！"
    "棍母"

# game/script.rpy:560
translate gunmu start_962b78af:

    # "虎哥自豪地说。"
    "棍母"

# game/script.rpy:562
translate gunmu start_3668a7e6:

    # huge "这可是我雨姐。"
    huge "棍母"

# game/script.rpy:563
translate gunmu start_b18dde90:

    # "他搂住雨姐的肩膀。"
    "棍母"

# game/script.rpy:564
translate gunmu start_f67cde1c:

    # "动作自然得像多年的老朋友。"
    "棍母"

# game/script.rpy:566
translate gunmu start_05457c3c:

    # huge "以前在哈尔滨卖土豆粉的。"
    huge "棍母"

# game/script.rpy:567
translate gunmu start_a938916a:

    # "老能唠了！"
    "棍母"

# game/script.rpy:568
translate gunmu start_1de3f91f:

    # "走走走，正好饭点了。"
    "棍母"

# game/script.rpy:570
translate gunmu start_52592d0a:

    # "虎哥看了看手机。"
    "棍母"

# game/script.rpy:571
translate gunmu start_ee9222ef:

    # "屏幕还是那种老式的智能手机。"
    "棍母"

# game/script.rpy:573
translate gunmu start_18de4f09:

    # huge "哥带你们下馆子去！"
    huge "棍母"

# game/script.rpy:574
translate gunmu start_0cb7df9b:

    # "他大手一挥。"
    "棍母"

# game/script.rpy:575
translate gunmu start_1a78a96b:

    # "气势十足，不容拒绝。"
    "棍母"

# game/script.rpy:577
translate gunmu start_79073e0a:

    # ANe "可是……我们刚才还在图书馆……"
    ANe "棍母"

# game/script.rpy:578
translate gunmu start_7c4002ed_1:

    # "宁宁小声说。"
    "棍母"

# game/script.rpy:579
translate gunmu start_f5eeb40e:

    # "但她的声音被虎哥的热情淹没了。"
    "棍母"

# game/script.rpy:581
translate gunmu start_40e27b42:

    # zj "别可是了。"
    zj "棍母"

# game/script.rpy:582
translate gunmu start_f337766d:

    # "一个小弟打断她。"
    "棍母"

# game/script.rpy:584
translate gunmu start_5986ca1b:

    # zj "干饭要紧！"
    zj "棍母"

# game/script.rpy:585
translate gunmu start_487bcbfd:

    # "雨姐突然来劲了。"
    "棍母"

# game/script.rpy:586
translate gunmu start_f488dbb2:

    # "虎哥，整点硬菜啊！"
    "棍母"

# game/script.rpy:588
translate gunmu start_c32a21ef:

    # huge "没毛病！"
    huge "棍母"

# game/script.rpy:589
translate gunmu start_752e4991:

    # "虎哥拍胸脯保证。"
    "棍母"

# game/script.rpy:590
translate gunmu start_c1081f6c:

    # "胸口拍得砰砰响。"
    "棍母"

# game/script.rpy:592
translate gunmu start_eb6584c5:

    # huge "今天必须整个锅包肉、溜肉段、地三鲜……"
    huge "棍母"

# game/script.rpy:593
translate gunmu start_d0722b50:

    # "他报出一串菜名。"
    "棍母"

# game/script.rpy:594
translate gunmu start_f832062d:

    # "都是经典的东北菜。"
    "棍母"

# game/script.rpy:596
translate gunmu start_37537afe:

    # hugexiaodi "虎哥威武！"
    hugexiaodi "棍母"

# game/script.rpy:597
translate gunmu start_50f55a37:

    # "小弟们齐声喊。"
    "棍母"

# game/script.rpy:598
translate gunmu start_2a27bd5f:

    # "声音整齐划一，像是排练过。"
    "棍母"

# game/script.rpy:600
translate gunmu start_936a5c50:

    # "就这样，landy被虎哥和小弟们簇拥着。"
    "棍母"

# game/script.rpy:601
translate gunmu start_a64fb886:

    # "走向了街角的东北菜馆。"
    "棍母"

# game/script.rpy:602
translate gunmu start_0969102b:

    # "一群人浩浩荡荡，吸引了不少路人的目光。"
    "棍母"

# game/script.rpy:608
translate gunmu start_18dd5b6f:

    # "虎哥带着众人来到了一家看起来很有年头的东北菜馆。"
    "棍母"

# game/script.rpy:609
translate gunmu start_3dfc9d52:

    # "红底黄字的招牌。"
    "棍母"

# game/script.rpy:610
translate gunmu start_faf8759c:

    # "写着老东北家常菜。"
    "棍母"

# game/script.rpy:612
translate gunmu start_b156a36b:

    # "玻璃门上贴着各种菜品的图片。"
    "棍母"

# game/script.rpy:613
translate gunmu start_1f24bdbc:

    # "有些已经褪色，边缘卷起。"
    "棍母"

# game/script.rpy:614
translate gunmu start_8177a45a:

    # "但还能看出菜的样子。"
    "棍母"

# game/script.rpy:616
translate gunmu start_df96d7fe:

    # laoban "哟，虎哥来啦！"
    laoban "棍母"

# game/script.rpy:617
translate gunmu start_a0e9c15e:

    # "老板迎出来。"
    "棍母"

# game/script.rpy:618
translate gunmu start_6fde0531:

    # "是个中年男人，围着围裙。"
    "棍母"

# game/script.rpy:620
translate gunmu start_e3a11498:

    # laoban "今天带这么多朋友？"
    laoban "棍母"

# game/script.rpy:621
translate gunmu start_77a26d19:

    # "他看向我们。"
    "棍母"

# game/script.rpy:622
translate gunmu start_6b3fa020:

    # "眼睛在我们身上扫了一圈。"
    "棍母"

# game/script.rpy:624
translate gunmu start_61ce9edb:

    # huge "老板，把你们家最硬的菜都给我上来！"
    huge "棍母"

# game/script.rpy:625
translate gunmu start_1a4e780a:

    # "虎哥嗓门很大。"
    "棍母"

# game/script.rpy:626
translate gunmu start_3aed3e68:

    # "整间餐馆都能听到他的声音。"
    "棍母"

# game/script.rpy:628
translate gunmu start_406600f1:

    # huge "这是我雨姐。"
    huge "棍母"

# game/script.rpy:629
translate gunmu start_e5c2348c:

    # "他介绍道。"
    "棍母"

# game/script.rpy:630
translate gunmu start_92b8477c:

    # "今天必须招待好了！"
    "棍母"

# game/script.rpy:632
translate gunmu start_2e6bf1a3:

    # laoban "好嘞！"
    laoban "棍母"

# game/script.rpy:633
translate gunmu start_b77bb5f7:

    # "老板点头。"
    "棍母"

# game/script.rpy:634
translate gunmu start_8b970e32:

    # "脸上堆满笑容。"
    "棍母"

# game/script.rpy:636
translate gunmu start_c2bb430c:

    # laoban "里边请里边请！"
    laoban "棍母"

# game/script.rpy:637
translate gunmu start_b6fa32ca:

    # "他撩开门帘。"
    "棍母"

# game/script.rpy:638
translate gunmu start_a9a9d1fe:

    # "门帘是那种塑料条做的，红白相间。"
    "棍母"

# game/script.rpy:640
translate gunmu start_7b1cf064:

    # "众人找了个大圆桌坐下。"
    "棍母"

# game/script.rpy:641
translate gunmu start_df8eab68:

    # "椅子腿在地上拖出刺耳的声音。"
    "棍母"

# game/script.rpy:642
translate gunmu start_00b42c98:

    # "像是金属摩擦地面的声音。"
    "棍母"

# game/script.rpy:644
translate gunmu start_fe9082d9:

    # huge "雨姐，你这妹子朋友是日本人？"
    huge "棍母"

# game/script.rpy:645
translate gunmu start_9ed44484:

    # "虎哥坐下后问。"
    "棍母"

# game/script.rpy:646
translate gunmu start_ef78dc17:

    # "刚才说的那是日语吧？"
    "棍母"

# game/script.rpy:648
translate gunmu start_c200a696:

    # "他模仿了一下发音。"
    "棍母"

# game/script.rpy:649
translate gunmu start_c9a59b38:

    # "模仿得不太像，但能听出是在学日语。"
    "棍母"

# game/script.rpy:651
translate gunmu start_4a7e71a4:

    # zj "啊这个..."
    zj "棍母"

# game/script.rpy:652
translate gunmu start_8a6d93de:

    # "雨姐挠了挠头。"
    "棍母"

# game/script.rpy:653
translate gunmu start_c4f3a232:

    # "宁宁她确实有点特别..."
    "棍母"

# game/script.rpy:655
translate gunmu start_c7a48711:

    # "她不知道该怎么解释。"
    "棍母"

# game/script.rpy:656
translate gunmu start_3e29d086:

    # "难道说 我们是从2026年穿越过来的？"
    "棍母"

# game/script.rpy:658
translate gunmu start_88b0e9d9:

    # ANe "(紧张地) すみません..."
    ANe "棍母"

# game/script.rpy:659
translate gunmu start_7c4002ed_2:

    # "宁宁小声说。"
    "棍母"

# game/script.rpy:660
translate gunmu start_9d81ba7b:

    # "头低得更低了。"
    "棍母"

# game/script.rpy:662
translate gunmu start_35cb4ec2:

    # ANe "对不起..."
    ANe "棍母"

# game/script.rpy:663
translate gunmu start_58d15299:

    # "她又用中文道歉。"
    "棍母"

# game/script.rpy:664
translate gunmu start_17188079:

    # "声音轻得像羽毛。"
    "棍母"

# game/script.rpy:666
translate gunmu start_4ac127f4:

    # hugexiaodi "虎哥，这日本妹子还挺腼腆啊！"
    hugexiaodi "棍母"

# game/script.rpy:667
translate gunmu start_07376528:

    # "一个小弟笑道。"
    "棍母"

# game/script.rpy:668
translate gunmu start_9beaba81:

    # "语气里没有恶意，只是觉得有趣。"
    "棍母"

# game/script.rpy:670
translate gunmu start_8fe4144e:

    # huge "没事没事。"
    huge "棍母"

# game/script.rpy:671
translate gunmu start_545d4b54:

    # "虎哥摆摆手。"
    "棍母"

# game/script.rpy:672
translate gunmu start_7679e2e2:

    # "动作幅度很大。"
    "棍母"

# game/script.rpy:674
translate gunmu start_7d62891f:

    # huge "来了就是朋友！"
    huge "棍母"

# game/script.rpy:675
translate gunmu start_9477c5c8:

    # "来，先整几瓶啤酒！"
    "棍母"

# game/script.rpy:676
translate gunmu start_20f47779:

    # "他朝服务员喊。"
    "棍母"

# game/script.rpy:679
translate gunmu start_2ac9a16b:

    # "服务员很快端上了凉菜和啤酒。"
    "棍母"

# game/script.rpy:680
translate gunmu start_d0977535:

    # "玻璃瓶碰撞发出清脆的声音。"
    "棍母"

# game/script.rpy:681
translate gunmu start_6bb075c0:

    # "瓶盖上凝结着水珠，看起来很冰。"
    "棍母"

# game/script.rpy:683
translate gunmu start_8a3d9d81:

    # huge "兄弟们，先走一个！"
    huge "棍母"

# game/script.rpy:684
translate gunmu start_abf28cc9:

    # "虎哥举起酒瓶。"
    "棍母"

# game/script.rpy:685
translate gunmu start_3e17f395:

    # "动作豪爽。"
    "棍母"

# game/script.rpy:687
translate gunmu start_2c0ed67b:

    # huandxd "干了！"
    huandxd "棍母"

# game/script.rpy:688
translate gunmu start_e3876992:

    # "小弟们齐声响应。"
    "棍母"

# game/script.rpy:689
translate gunmu start_0b0f9f57:

    # "声音震耳欲聋。"
    "棍母"

# game/script.rpy:691
translate gunmu start_5121ec08:

    # "虎哥和小弟们一饮而尽。"
    "棍母"

# game/script.rpy:692
translate gunmu start_100b0fcc:

    # "雨姐也不甘示弱。"
    "棍母"

# game/script.rpy:693
translate gunmu start_01d540d6:

    # "宁宁则小口抿了一点。"
    "棍母"

# game/script.rpy:695
translate gunmu start_26ea7fc9:

    # "眉头微微皱起。"
    "棍母"

# game/script.rpy:696
translate gunmu start_6264eaaf:

    # "显然不习惯啤酒的苦味。"
    "棍母"

# game/script.rpy:697
translate gunmu start_c61b163c:

    # "但还是很礼貌地喝了一点。"
    "棍母"

# game/script.rpy:699
translate gunmu start_2711f913:

    # zj "痛快！"
    zj "棍母"

# game/script.rpy:700
translate gunmu start_a026fa98:

    # "虎哥放下空瓶。"
    "棍母"

# game/script.rpy:701
translate gunmu start_8c47ee83:

    # "瓶底敲在桌上，发出咚的一声。"
    "棍母"

# game/script.rpy:703
translate gunmu start_2b23de8a:

    # zj "还得是东北这大绿棒子！"
    zj "棍母"

# game/script.rpy:704
translate gunmu start_82c73488:

    # "他拍了拍瓶子。"
    "棍母"

# game/script.rpy:705
translate gunmu start_11e2c80d:

    # "脸上露出满足的表情。"
    "棍母"

# game/script.rpy:707
translate gunmu start_942535dc:

    # "不一会儿，热菜陆续上桌。"
    "棍母"

# game/script.rpy:708
translate gunmu start_e61c5b84:

    # "服务员端着大盘子。"
    "棍母"

# game/script.rpy:709
translate gunmu start_81211168:

    # "盘子很大，菜量很足。"
    "棍母"

# game/script.rpy:712
translate gunmu start_b04d8a40:

    # "香味充满了整个房间。"
    "棍母"

# game/script.rpy:713
translate gunmu start_5aa4dca8:

    # "各种菜肴的香气混合在一起。"
    "棍母"

# game/script.rpy:714
translate gunmu start_cc87dac9:

    # "让人食欲大开。"
    "棍母"

# game/script.rpy:716
translate gunmu start_af129a06:

    # hugexiaodi "哇！锅包肉！"
    hugexiaodi "棍母"

# game/script.rpy:717
translate gunmu start_52f99e57:

    # "金黄色的肉片淋着酱汁。"
    "棍母"

# game/script.rpy:718
translate gunmu start_7ee052af:

    # "看起来酥脆可口。"
    "棍母"

# game/script.rpy:720
translate gunmu start_c44dd56b:

    # hugexiaodi "溜肉段也上来了！"
    hugexiaodi "棍母"

# game/script.rpy:721
translate gunmu start_55a01180:

    # "另一个小弟喊道。"
    "棍母"

# game/script.rpy:722
translate gunmu start_6dc106d8:

    # "肉段炸得金黄，配着青椒和胡萝卜。"
    "棍母"

# game/script.rpy:724
translate gunmu start_d182ffa5:

    # hugexiaodi "还有酸菜炖粉条！"
    hugexiaodi "棍母"

# game/script.rpy:725
translate gunmu start_bf4d1fac:

    # "热气腾腾的一大碗。"
    "棍母"

# game/script.rpy:726
translate gunmu start_a6cd63b3:

    # "酸菜的香味扑鼻而来。"
    "棍母"

# game/script.rpy:728
translate gunmu start_c7bce4cf:

    # huge "来，雨姐，宁宁妹子。"
    huge "棍母"

# game/script.rpy:729
translate gunmu start_950ff200:

    # "虎哥拿起筷子。"
    "棍母"

# game/script.rpy:730
translate gunmu start_8702955a:

    # "动作熟练地给两人夹菜。"
    "棍母"

# game/script.rpy:732
translate gunmu start_c9a8f48b:

    # huge "别客气，随便吃！"
    huge "棍母"

# game/script.rpy:733
translate gunmu start_3bed769e:

    # "他热情地给两人夹菜。"
    "棍母"

# game/script.rpy:734
translate gunmu start_fe696ff0:

    # "碗很快就堆成了小山。"
    "棍母"

# game/script.rpy:736
translate gunmu start_3fe936f8:

    # ANe "あの...太多了..."
    ANe "棍母"

# game/script.rpy:737
translate gunmu start_a9675791:

    # "宁宁看着眼前的食物。"
    "棍母"

# game/script.rpy:738
translate gunmu start_6de9155f:

    # "有些不知所措。"
    "棍母"

# game/script.rpy:740
translate gunmu start_32eeb06e:

    # "碗里的菜已经冒尖了。"
    "棍母"

# game/script.rpy:741
translate gunmu start_55c15d2a:

    # "再多就要掉出来了。"
    "棍母"

# game/script.rpy:743
translate gunmu start_94f590a4:

    # zj "宁宁你别不好意思。"
    zj "棍母"

# game/script.rpy:744
translate gunmu start_36567a99:

    # "雨姐大口吃着。"
    "棍母"

# game/script.rpy:745
translate gunmu start_24fa744a:

    # "腮帮子鼓鼓的，像只松鼠。"
    "棍母"

# game/script.rpy:747
translate gunmu start_df1aab50:

    # zj "这锅包肉老好吃了！"
    zj "棍母"

# game/script.rpy:748
translate gunmu start_1d93c80c:

    # "她含糊不清地说。"
    "棍母"

# game/script.rpy:749
translate gunmu start_d738e61b:

    # "嘴里塞满了食物。"
    "棍母"

# game/script.rpy:751
translate gunmu start_92d34056:

    # "宁宁也慢慢尝了一口。"
    "棍母"

# game/script.rpy:752
translate gunmu start_89e59249:

    # "小心地咬了一小点。"
    "棍母"

# game/script.rpy:753
translate gunmu start_eab64f59:

    # "动作优雅，和雨姐形成鲜明对比。"
    "棍母"

# game/script.rpy:755
translate gunmu start_6267c71b:

    # "眼睛微微睁大。"
    "棍母"

# game/script.rpy:756
translate gunmu start_f254a1c4:

    # "像是发现了新大陆。"
    "棍母"

# game/script.rpy:757
translate gunmu start_2d2578f5:

    # "表情有些惊喜。"
    "棍母"

# game/script.rpy:759
translate gunmu start_068129b3:

    # ANe "おいしい..."
    ANe "棍母"

# game/script.rpy:760
translate gunmu start_bffbf5f1:

    # "她小声说。"
    "棍母"

# game/script.rpy:761
translate gunmu start_d636a68a:

    # "声音里带着一丝惊讶。"
    "棍母"

# game/script.rpy:763
translate gunmu start_7afb77db:

    # ANe "真好吃..."
    ANe "棍母"

# game/script.rpy:764
translate gunmu start_ddfe78c1:

    # "她补充翻译。"
    "棍母"

# game/script.rpy:765
translate gunmu start_a3e71451:

    # "脸上露出淡淡的微笑。"
    "棍母"

# game/script.rpy:767
translate gunmu start_4f0d7e42:

    # huge "哈哈，好吃就多吃点！"
    huge "棍母"

# game/script.rpy:768
translate gunmu start_7a6af7e3:

    # "虎哥很高兴。"
    "棍母"

# game/script.rpy:769
translate gunmu start_ba8bcb6c:

    # "自己的推荐被认可，让他很有面子。"
    "棍母"

# game/script.rpy:771
translate gunmu start_5929201a:

    # "酒过三巡。"
    "棍母"

# game/script.rpy:772
translate gunmu start_8234a496:

    # "桌上已经多了很多空瓶。"
    "棍母"

# game/script.rpy:773
translate gunmu start_fc48ad02:

    # "每个人面前都有一两个空瓶子。"
    "棍母"

# game/script.rpy:775
translate gunmu start_1d03db20:

    # "气氛越来越热闹。"
    "棍母"

# game/script.rpy:776
translate gunmu start_d0330f96:

    # "大家的脸都红扑扑的。"
    "棍母"

# game/script.rpy:777
translate gunmu start_19c41ee0:

    # "说话声音也越来越大。"
    "棍母"

# game/script.rpy:779
translate gunmu start_05ce8331:

    # huge "雨姐，我记得你以前在哈尔滨的时候。"
    huge "棍母"

# game/script.rpy:780
translate gunmu start_437a5eb0:

    # "虎哥回忆道。"
    "棍母"

# game/script.rpy:781
translate gunmu start_1725a52a:

    # "眼睛望向远方，像是在回忆往事。"
    "棍母"

# game/script.rpy:783
translate gunmu start_84b2614d:

    # huge "歌唱得不错啊！"
    huge "棍母"

# game/script.rpy:784
translate gunmu start_d82d9bdd:

    # "那是！"
    "棍母"

# game/script.rpy:785
translate gunmu start_eda8f25c:

    # "雨姐挺起胸。"
    "棍母"

# game/script.rpy:787
translate gunmu start_efa9dff7:

    # zj "当年我也是KTV一霸！"
    zj "棍母"

# game/script.rpy:788
translate gunmu start_4c36935c:

    # "她自豪地说。"
    "棍母"

# game/script.rpy:789
translate gunmu start_199a8776:

    # "脸上露出得意的笑容。"
    "棍母"

# game/script.rpy:791
translate gunmu start_6065ee40:

    # huge "正好，吃完饭咱们去KTV续摊！"
    huge "棍母"

# game/script.rpy:792
translate gunmu start_cf37f58e:

    # "虎哥提议。"
    "棍母"

# game/script.rpy:793
translate gunmu start_6bc30bae:

    # "眼睛发亮，兴致很高。"
    "棍母"

# game/script.rpy:795
translate gunmu start_0090e0c3:

    # hugexiaodi "虎哥英明！"
    hugexiaodi "棍母"

# game/script.rpy:796
translate gunmu start_60df2172:

    # "小弟们欢呼。"
    "棍母"

# game/script.rpy:797
translate gunmu start_50da0b80:

    # "气氛更加热烈了。"
    "棍母"

# game/script.rpy:799
translate gunmu start_a56a70a7:

    # ANe "(小声对雨姐) 我们去KTV...合适吗..."
    ANe "棍母"

# game/script.rpy:800
translate gunmu start_1d7fa86f:

    # "宁宁有些不安地拉了拉雨姐的衣角。"
    "棍母"

# game/script.rpy:801
translate gunmu start_db5798fe:

    # "她的手指轻轻拽着雨姐的袖子。"
    "棍母"

# game/script.rpy:803
translate gunmu start_0467fa64:

    # zj "(小声回应) 没事，有我呢！"
    zj "棍母"

# game/script.rpy:804
translate gunmu start_a5687be7:

    # "雨姐拍拍她的手。"
    "棍母"

# game/script.rpy:805
translate gunmu start_0649c27c:

    # "动作很轻，像是在安慰她。"
    "棍母"

# game/script.rpy:807
translate gunmu start_e1b0be4a:

    # "虎哥注意到两人窃窃私语。"
    "棍母"

# game/script.rpy:808
translate gunmu start_84cb1705:

    # "他探过头。"
    "棍母"

# game/script.rpy:809
translate gunmu start_49e1cce7:

    # "一脸好奇。"
    "棍母"

# game/script.rpy:811
translate gunmu start_ad2f3ec3:

    # huge "咋了雨姐。"
    huge "棍母"

# game/script.rpy:812
translate gunmu start_96adbd71:

    # "跟妹子说啥悄悄话呢？"
    "棍母"

# game/script.rpy:813
translate gunmu start_68cb795d:

    # "没啥！"
    "棍母"

# game/script.rpy:815
translate gunmu start_42846458:

    # "雨姐坐直身体。"
    "棍母"

# game/script.rpy:816
translate gunmu start_bae1a2d0:

    # "表情恢复正常。"
    "棍母"

# game/script.rpy:818
translate gunmu start_807d61aa:

    # zj "虎哥，今天不醉不归！"
    zj "棍母"

# game/script.rpy:819
translate gunmu start_c447ef85:

    # "她举起酒杯。"
    "棍母"

# game/script.rpy:820
translate gunmu start_d4929bef:

    # "杯里还有半杯啤酒。"
    "棍母"

# game/script.rpy:822
translate gunmu start_77b4b589:

    # huge "够意思！"
    huge "棍母"

# game/script.rpy:823
translate gunmu start_19a94852:

    # "虎哥也举杯。"
    "棍母"

# game/script.rpy:824
translate gunmu start_8a5aef4f:

    # "酒杯碰在一起。"
    "棍母"

# game/script.rpy:827
translate gunmu start_cce9da61:

    # "众人举起酒杯。"
    "棍母"

# game/script.rpy:828
translate gunmu start_2b5dd0c8:

    # "玻璃杯碰撞发出清脆的响声..."
    "棍母"

# game/script.rpy:829
translate gunmu start_d30ec881:

    # "叮叮当当，像是风铃。"
    "棍母"

# game/script.rpy:834
translate gunmu start_c9c22e10:

    # "一顿饭吃了两个多小时。"
    "棍母"

# game/script.rpy:835
translate gunmu start_1413ff02:

    # "桌上已经摆满了空酒瓶。"
    "棍母"

# game/script.rpy:836
translate gunmu start_174c8c37:

    # "盘子也大多见底了。"
    "棍母"

# game/script.rpy:838
translate gunmu start_44f8d4ab:

    # "外面天已经黑了。"
    "棍母"

# game/script.rpy:839
translate gunmu start_494705a4:

    # "街灯亮了起来。"
    "棍母"

# game/script.rpy:840
translate gunmu start_901ef5b9:

    # "昏黄的光晕洒在街道上。"
    "棍母"

# game/script.rpy:842
translate gunmu start_c6e7a1a3:

    # huge "兄弟们，转移阵地！"
    huge "棍母"

# game/script.rpy:843
translate gunmu start_c93dc29a:

    # "虎哥站起来。"
    "棍母"

# game/script.rpy:844
translate gunmu start_89153b8b:

    # "动作有些摇晃，但还算稳。"
    "棍母"

# game/script.rpy:846
translate gunmu start_0314b4d3:

    # huge "KTV走起！"
    huge "棍母"

# game/script.rpy:847
translate gunmu start_e39a1c3f:

    # "哦吼！！！"
    "棍母"

# game/script.rpy:849
translate gunmu start_4aa802e8:

    # "众人欢呼。"
    "棍母"

# game/script.rpy:850
translate gunmu start_549299a9:

    # "声音充满兴奋。"
    "棍母"

# game/script.rpy:852
translate gunmu start_aefa9a80:

    # "大家走出餐馆。"
    "棍母"

# game/script.rpy:853
translate gunmu start_e008392c:

    # "夜晚的空气微凉。"
    "棍母"

# game/script.rpy:854
translate gunmu start_81775d87:

    # "吹在脸上很舒服。"
    "棍母"

# game/script.rpy:856
translate gunmu start_cfae697d:

    # "众人来到一家装修豪华的KTV。"
    "棍母"

# game/script.rpy:857
translate gunmu start_e3c125af:

    # "霓虹灯招牌在夜色中闪烁。"
    "棍母"

# game/script.rpy:858
translate gunmu start_64becc60:

    # " 金色年华KTV 几个字不断变色。"
    "棍母"

# game/script.rpy:864
translate gunmu start_82fb493a:

    # "虎哥来啦！"
    "棍母"

# game/script.rpy:865
translate gunmu start_e208d9ec:

    # "前台接待认得他。"
    "棍母"

# game/script.rpy:866
translate gunmu start_ca9d6d98:

    # "是个年轻的女孩，画着浓妆。"
    "棍母"

# game/script.rpy:868
translate gunmu start_c704fe5f:

    # "还是老包厢？"
    "棍母"

# game/script.rpy:869
translate gunmu start_997bd249:

    # "对！大包。"
    "棍母"

# game/script.rpy:871
translate gunmu start_3e13c072:

    # "虎哥点头。"
    "棍母"

# game/script.rpy:872
translate gunmu start_dbdbdac4:

    # "动作很熟练。"
    "棍母"

# game/script.rpy:874
translate gunmu start_e40b2440:

    # huge "音响给我整最好的！"
    huge "棍母"

# game/script.rpy:875
translate gunmu start_fb4f7084:

    # "他特别强调。"
    "棍母"

# game/script.rpy:876
translate gunmu start_67fe9fd5:

    # "音量很重要。"
    "棍母"

# game/script.rpy:878
translate gunmu start_dd540c09:

    # "进入包厢后。"
    "棍母"

# game/script.rpy:879
translate gunmu start_861af083:

    # "霓虹灯闪烁。"
    "棍母"

# game/script.rpy:880
translate gunmu start_076c8dd2:

    # "灯光不断变换颜色。"
    "棍母"

# game/script.rpy:882
translate gunmu start_43811d21:

    # "音乐震耳欲聋。"
    "棍母"

# game/script.rpy:883
translate gunmu start_ef4abdc1:

    # "是动感的舞曲。"
    "棍母"

# game/script.rpy:884
translate gunmu start_a51b1d08:

    # "节奏很强。"
    "棍母"

# game/script.rpy:886
translate gunmu start_1a2efb1f:

    # "墙上的彩色灯光不断变换。"
    "棍母"

# game/script.rpy:887
translate gunmu start_7f48ec6e:

    # "营造出迷离的氛围。"
    "棍母"

# game/script.rpy:888
translate gunmu start_f4507606:

    # "让人有些眼花缭乱。"
    "棍母"

# game/script.rpy:890
translate gunmu start_71ea8bf3:

    # hugexiaodi "虎哥先来一首！"
    hugexiaodi "棍母"

# game/script.rpy:891
translate gunmu start_d6477abc:

    # "一个小弟递上麦克风。"
    "棍母"

# game/script.rpy:892
translate gunmu start_3d950b5c:

    # "麦克风是那种有线的话筒。"
    "棍母"

# game/script.rpy:894
translate gunmu start_658ae06c:

    # huge "那我就献丑了！"
    huge "棍母"

# game/script.rpy:895
translate gunmu start_494f4248:

    # "虎哥接过。"
    "棍母"

# game/script.rpy:896
translate gunmu start_cf4da899:

    # "动作豪迈。"
    "棍母"

# game/script.rpy:898
translate gunmu start_ef0b909d:

    # huge "来首《朋友的酒》！"
    huge "棍母"

# game/script.rpy:899
translate gunmu start_f0c39e97:

    # "他点歌。"
    "棍母"

# game/script.rpy:900
translate gunmu start_4b4f7c25:

    # "动作熟练地操作点歌机。"
    "棍母"

# game/script.rpy:903
translate gunmu start_1a1467dc:

    # "前奏响起。"
    "棍母"

# game/script.rpy:904
translate gunmu start_405f5681:

    # "熟悉的旋律。"
    "棍母"

# game/script.rpy:906
translate gunmu start_58831dd2:

    # "虎哥声嘶力竭地唱了起来。"
    "棍母"

# game/script.rpy:907
translate gunmu start_355b7493:

    # "虽然跑调严重。"
    "棍母"

# game/script.rpy:908
translate gunmu start_3d733e42:

    # "但气势十足，感情饱满。"
    "棍母"

# game/script.rpy:910
translate gunmu start_81417fab:

    # "脖子上的青筋都暴出来了。"
    "棍母"

# game/script.rpy:911
translate gunmu start_f8bcb5ba:

    # "唱得很投入。"
    "棍母"

# game/script.rpy:912
translate gunmu start_9fc007d4:

    # "完全沉浸在自己的世界里。"
    "棍母"

# game/script.rpy:914
translate gunmu start_82798e35:

    # hugexiaodi "虎哥牛逼！！！"
    hugexiaodi "棍母"

# game/script.rpy:915
translate gunmu start_b61c2540:

    # "小弟们鼓掌。"
    "棍母"

# game/script.rpy:916
translate gunmu start_3aad6ece:

    # "掌声热烈。"
    "棍母"

# game/script.rpy:918
translate gunmu start_a1052724:

    # "一首唱完。"
    "棍母"

# game/script.rpy:919
translate gunmu start_bb4bc8fd:

    # "虎哥把麦克风递给雨姐。"
    "棍母"

# game/script.rpy:920
translate gunmu start_98a74ac6:

    # "额头上已经冒出了细汗。"
    "棍母"

# game/script.rpy:922
translate gunmu start_9e8c806e:

    # huge "雨姐，来一首！"
    huge "棍母"

# game/script.rpy:923
translate gunmu start_2f90d5b2:

    # "他喘着气说。"
    "棍母"

# game/script.rpy:924
translate gunmu start_c1a5746f:

    # "胸口起伏。"
    "棍母"

# game/script.rpy:926
translate gunmu start_adc00930:

    # zj "那我可不客气了！"
    zj "棍母"

# game/script.rpy:927
translate gunmu start_63cdb382:

    # "雨姐接过麦克风。"
    "棍母"

# game/script.rpy:928
translate gunmu start_b4801653:

    # "握在手里掂了掂。"
    "棍母"

# game/script.rpy:931
translate gunmu start_92e8f579:

    # "她点了一首《套马杆》。"
    "棍母"

# game/script.rpy:932
translate gunmu start_5cafd475:

    # "前奏很有草原风情。"
    "棍母"

# game/script.rpy:934
translate gunmu start_796da484:

    # "唱得比虎哥好了不少。"
    "棍母"

# game/script.rpy:935
translate gunmu start_795ace36:

    # "声音洪亮有力。"
    "棍母"

# game/script.rpy:936
translate gunmu start_8c04e2d9:

    # "高音部分轻松上去。"
    "棍母"

# game/script.rpy:938
translate gunmu start_74ff053a:

    # "雨姐可以啊！"
    "棍母"

# game/script.rpy:939
translate gunmu start_37aa5107:

    # "虎哥赞叹。"
    "棍母"

# game/script.rpy:940
translate gunmu start_bea51035:

    # "竖起大拇指。"
    "棍母"

# game/script.rpy:942
translate gunmu start_d4ad2f73:

    # "宁宁坐在角落。"
    "棍母"

# game/script.rpy:943
translate gunmu start_dfb9036f:

    # "看着热闹的场面有些不知所措。"
    "棍母"

# game/script.rpy:944
translate gunmu start_d3437f16:

    # "手指紧张地绞在一起。"
    "棍母"

# game/script.rpy:946
translate gunmu start_d54d88b5:

    # "霓虹灯的光扫过她的脸。"
    "棍母"

# game/script.rpy:947
translate gunmu start_fa6f57f7:

    # "一会儿红，一会儿蓝，一会儿绿。"
    "棍母"

# game/script.rpy:948
translate gunmu start_6fbc2633:

    # "让她的表情看起来有些迷离。"
    "棍母"

# game/script.rpy:950
translate gunmu start_49b63168:

    # zj "宁宁，你也来一首！"
    zj "棍母"

# game/script.rpy:951
translate gunmu start_ef7096f7:

    # "雨姐走过来。"
    "棍母"

# game/script.rpy:952
translate gunmu start_ba87f29c:

    # "脚步有些摇晃。"
    "棍母"

# game/script.rpy:954
translate gunmu start_8acf7a71:

    # "把麦克风塞到宁宁手里。"
    "棍母"

# game/script.rpy:955
translate gunmu start_e99afb07:

    # "动作有些粗暴。"
    "棍母"

# game/script.rpy:956
translate gunmu start_567f5dae:

    # "但没什么恶意。"
    "棍母"

# game/script.rpy:958
translate gunmu start_f6b11cb8:

    # ANe "えっ？"
    ANe "棍母"

# game/script.rpy:959
translate gunmu start_e913b09c:

    # "宁宁吓了一跳。"
    "棍母"

# game/script.rpy:960
translate gunmu start_7527574c:

    # "差点把麦克风掉地上。"
    "棍母"

# game/script.rpy:962
translate gunmu start_4286d098:

    # ANe "我...我不会中文歌..."
    ANe "棍母"

# game/script.rpy:963
translate gunmu start_41d1c63e:

    # "她红着脸说。"
    "棍母"

# game/script.rpy:964
translate gunmu start_f4b90037:

    # "声音很小。"
    "棍母"

# game/script.rpy:966
translate gunmu start_cee78529:

    # huge "唱日语的也行啊！"
    huge "棍母"

# game/script.rpy:967
translate gunmu start_d0b83379:

    # "虎哥也走过来。"
    "棍母"

# game/script.rpy:968
translate gunmu start_6ad8d809:

    # "小弟们开始起哄。"
    "棍母"

# game/script.rpy:970
translate gunmu start_d1498d34:

    # "来一首！来一首！"
    "棍母"

# game/script.rpy:971
translate gunmu start_558748a9:

    # "声音整齐，像是排练过。"
    "棍母"

# game/script.rpy:973
translate gunmu start_f8aafd99:

    # "在众人的起哄下。"
    "棍母"

# game/script.rpy:974
translate gunmu start_bbf017d0:

    # "宁宁扭扭捏捏地接过麦克风。"
    "棍母"

# game/script.rpy:975
translate gunmu start_e3234bc3:

    # "动作很慢，很不情愿。"
    "棍母"

# game/script.rpy:977
translate gunmu start_9a00b7d9:

    # "她犹豫了一下。"
    "棍母"

# game/script.rpy:978
translate gunmu start_c03dfa06:

    # "眼睛在点歌机上扫来扫去。"
    "棍母"

# game/script.rpy:979
translate gunmu start_cff7912e:

    # "终于点了一首歌。"
    "棍母"

# game/script.rpy:982
translate gunmu start_1a1467dc_1:

    # "前奏响起。"
    "棍母"

# game/script.rpy:983
translate gunmu start_82dbe44b:

    # "是《恋爱循环》熟悉的旋律。"
    "棍母"

# game/script.rpy:984
translate gunmu start_c2410383:

    # "轻快而甜美。"
    "棍母"

# game/script.rpy:986
translate gunmu start_6c1dc8ce:

    # "宁宁深吸一口气。"
    "棍母"

# game/script.rpy:987
translate gunmu start_c41d9166:

    # "握紧了麦克风。"
    "棍母"

# game/script.rpy:988
translate gunmu start_532b89d6:

    # "指节微微发白。"
    "棍母"

# game/script.rpy:990
translate gunmu start_7a64cc2d:

    # ANedahan "セーノ.."
    ANedahan "棍母"

# game/script.rpy:991
translate gunmu start_d9467f24:

    # "她小声念出台词。"
    "棍母"

# game/script.rpy:992
translate gunmu start_a8a0fc09:

    # "(预备)"
    "棍母"

# game/script.rpy:994
translate gunmu start_627b0630:

    # "翻译在脑海中同步。"
    "棍母"

# game/script.rpy:995
translate gunmu start_d0b5458e:

    # "她的声音起初有些颤抖。"
    "棍母"

# game/script.rpy:997
translate gunmu start_765b8833:

    # "但很快就稳定下来。"
    "棍母"

# game/script.rpy:998
translate gunmu start_b34a7cf1:

    # "甜甜的嗓音贴合旋律。"
    "棍母"

# game/script.rpy:999
translate gunmu start_809d4bc7:

    # "让人听了心情愉悦。"
    "棍母"

# game/script.rpy:1001
translate gunmu start_11e2a3c0:

    # ANe "でも そんなんじゃ だめ"
    ANe "棍母"

# game/script.rpy:1002
translate gunmu start_e716bacd:

    # "她唱道。"
    "棍母"

# game/script.rpy:1003
translate gunmu start_29d83f5a:

    # "(但是 那样 可不行)"
    "棍母"

# game/script.rpy:1005
translate gunmu start_6259151e:

    # ANe "もう そんなんじゃ ほら"
    ANe "棍母"

# game/script.rpy:1006
translate gunmu start_3a8664e5:

    # "(那样 已经不行 你看)"
    "棍母"

# game/script.rpy:1008
translate gunmu start_1898672e:

    # ANe "心は進化するよ"
    ANe "棍母"

# game/script.rpy:1009
translate gunmu start_25021a81:

    # "(不然这颗心会进化哦)"
    "棍母"

# game/script.rpy:1011
translate gunmu start_90b09117:

    # ANe "もっともっと"
    ANe "棍母"

# game/script.rpy:1012
translate gunmu start_f71826bb:

    # "(不断地 不断地)"
    "棍母"

# game/script.rpy:1014
translate gunmu start_f5fdd478:

    # ANe "...."
    ANe "棍母"

# game/script.rpy:1015
translate gunmu start_786e1b61:

    # "随着歌曲进行。"
    "棍母"

# game/script.rpy:1016
translate gunmu start_165bbf4f:

    # "宁宁渐渐放开了。"
    "棍母"

# game/script.rpy:1018
translate gunmu start_2e420a8f:

    # "声音变得甜美而自信。"
    "棍母"

# game/script.rpy:1019
translate gunmu start_d0f86a51:

    # "身体轻轻摇摆。"
    "棍母"

# game/script.rpy:1020
translate gunmu start_9d76665f:

    # "跟着节奏晃动。"
    "棍母"

# game/script.rpy:1022
translate gunmu start_fcb97d42:

    # hugexiaodi "哇！这日本妹子唱歌这么好听！"
    hugexiaodi "棍母"

# game/script.rpy:1023
translate gunmu start_c9e64762:

    # "一个小弟惊叹。"
    "棍母"

# game/script.rpy:1024
translate gunmu start_c5c4dbbc:

    # "眼睛都直了。"
    "棍母"

# game/script.rpy:1026
translate gunmu start_a1052724_1:

    # "一首唱完。"
    "棍母"

# game/script.rpy:1027
translate gunmu start_c4dfda73:

    # "掌声雷动。"
    "棍母"

# game/script.rpy:1028
translate gunmu start_a97a1e93:

    # "宁宁的脸红得像苹果。"
    "棍母"

# game/script.rpy:1030
translate gunmu start_42429b4e:

    # "深深鞠了一躬。"
    "棍母"

# game/script.rpy:1031
translate gunmu start_f42f5e24:

    # "动作标准，很有礼貌。"
    "棍母"

# game/script.rpy:1033
translate gunmu start_c44b205f:

    # huge "来来来，接着喝！"
    huge "棍母"

# game/script.rpy:1034
translate gunmu start_b0ae66e6:

    # "虎哥又开酒。"
    "棍母"

# game/script.rpy:1035
translate gunmu start_f90f7bbb:

    # "瓶盖飞出去，掉在地上。"
    "棍母"

# game/script.rpy:1037
translate gunmu start_c3e1a72c:

    # "服务员又搬进来一箱啤酒。"
    "棍母"

# game/script.rpy:1038
translate gunmu start_b3499f10:

    # "放在墙角。"
    "棍母"

# game/script.rpy:1039
translate gunmu start_14d3b85f:

    # "箱子很重，落地有声。"
    "棍母"

# game/script.rpy:1041
translate gunmu start_c11b5644:

    # "虎哥和小弟们轮番给雨姐和宁宁敬酒。"
    "棍母"

# game/script.rpy:1042
translate gunmu start_933ca5de:

    # "气氛达到了高潮。"
    "棍母"

# game/script.rpy:1043
translate gunmu start_840fe051:

    # "每个人都兴致很高。"
    "棍母"

# game/script.rpy:1045
translate gunmu start_fae5b192:

    # zj "宁宁，咱俩也喝一个！"
    zj "棍母"

# game/script.rpy:1046
translate gunmu start_8bc4786b:

    # "雨姐已经有些醉了。"
    "棍母"

# game/script.rpy:1047
translate gunmu start_5c88f469:

    # "搂着宁宁的肩膀。"
    "棍母"

# game/script.rpy:1049
translate gunmu start_211d4d9f:

    # "身体微微摇晃。"
    "棍母"

# game/script.rpy:1050
translate gunmu start_7cc9f9a5:

    # "但手很稳，没洒出来。"
    "棍母"

# game/script.rpy:1052
translate gunmu start_7a68fc51:

    # ANe "でも...我已经喝了不少了..."
    ANe "棍母"

# game/script.rpy:1053
translate gunmu start_fc4ad5d9:

    # "宁宁为难地说。"
    "棍母"

# game/script.rpy:1054
translate gunmu start_371a372c:

    # "眉头微皱。"
    "棍母"

# game/script.rpy:1056
translate gunmu start_fb7407ea:

    # zj "没事！今天高兴！"
    zj "棍母"

# game/script.rpy:1057
translate gunmu start_8bd98355:

    # "雨姐说着。"
    "棍母"

# game/script.rpy:1058
translate gunmu start_24dfd16a:

    # "又给宁宁倒了一杯。"
    "棍母"

# game/script.rpy:1060
translate gunmu start_ee77a850:

    # "酒液溢出杯沿。"
    "棍母"

# game/script.rpy:1061
translate gunmu start_4a390db2:

    # "顺着瓶身流下。"
    "棍母"

# game/script.rpy:1062
translate gunmu start_a8c54e96:

    # "滴在桌上。"
    "棍母"

# game/script.rpy:1064
translate gunmu start_9511185a:

    # "两人又喝了几杯。"
    "棍母"

# game/script.rpy:1065
translate gunmu start_7b528613:

    # "宁宁的脸越来越红。"
    "棍母"

# game/script.rpy:1066
translate gunmu start_a713d0cd:

    # "眼神开始迷离。"
    "棍母"

# game/script.rpy:1068
translate gunmu start_0f52a364:

    # "雨姐的酒量似乎更好一些。"
    "棍母"

# game/script.rpy:1069
translate gunmu start_d7a601e6:

    # "但也开始摇晃。"
    "棍母"

# game/script.rpy:1070
translate gunmu start_0c614c06:

    # "说话有些大舌头。"
    "棍母"

# game/script.rpy:1072
translate gunmu start_27926d77:

    # huge "雨姐，你这妹子朋友酒量不行啊！"
    huge "棍母"

# game/script.rpy:1073
translate gunmu start_89517868:

    # "虎哥笑道。"
    "棍母"

# game/script.rpy:1074
translate gunmu start_0ae693a3:

    # "语气里没有恶意。"
    "棍母"

# game/script.rpy:1076
translate gunmu start_86b13703:

    # zj "谁...谁说的！"
    zj "棍母"

# game/script.rpy:1077
translate gunmu start_05c7b1c3:

    # "雨姐反驳。"
    "棍母"

# game/script.rpy:1078
translate gunmu start_0a799716:

    # "声音很大。"
    "棍母"

# game/script.rpy:1080
translate gunmu start_61c8c843:

    # zj "宁宁还能喝！"
    zj "棍母"

# game/script.rpy:1081
translate gunmu start_3f5c1e7a:

    # "她说着。"
    "棍母"

# game/script.rpy:1082
translate gunmu start_24dfd16a_1:

    # "又给宁宁倒了一杯。"
    "棍母"

# game/script.rpy:1084
translate gunmu start_25997631:

    # "手已经不稳了。"
    "棍母"

# game/script.rpy:1085
translate gunmu start_842243bb:

    # "酒洒到桌子上。"
    "棍母"

# game/script.rpy:1086
translate gunmu start_b416fefc:

    # "形成一小摊水渍。"
    "棍母"

# game/script.rpy:1088
translate gunmu start_3fd31f27:

    # ANe "やめて...我真的不行了..."
    ANe "棍母"

# game/script.rpy:1089
translate gunmu start_e47b6609:

    # "宁宁摇头。"
    "棍母"

# game/script.rpy:1090
translate gunmu start_ab721a06:

    # "但雨姐已经听不进去了。"
    "棍母"

# game/script.rpy:1092
translate gunmu start_b4b85cbd:

    # "硬是让宁宁又喝了几杯。"
    "棍母"

# game/script.rpy:1093
translate gunmu start_df568994:

    # "终于，宁宁彻底醉了。"
    "棍母"

# game/script.rpy:1094
translate gunmu start_4aa810f5:

    # "倒在沙发上。"
    "棍母"

# game/script.rpy:1096
translate gunmu start_3f9ddf15:

    # "发出均匀的呼吸声。"
    "棍母"

# game/script.rpy:1097
translate gunmu start_f555f957:

    # "胸口轻轻起伏。"
    "棍母"

# game/script.rpy:1098
translate gunmu start_922cd70b:

    # "眼睛闭着，睡着了。"
    "棍母"

# game/script.rpy:1100
translate gunmu start_884f657f:

    # zj "嘿嘿...宁宁你不行啊..."
    zj "棍母"

# game/script.rpy:1101
translate gunmu start_81313aef:

    # "雨姐话还没说完。"
    "棍母"

# game/script.rpy:1102
translate gunmu start_16f16f33:

    # "自己也倒在了宁宁旁边。"
    "棍母"

# game/script.rpy:1104
translate gunmu start_3f82ef73:

    # "手还搭在宁宁肩膀上。"
    "棍母"

# game/script.rpy:1105
translate gunmu start_66c2a608:

    # "像是搂着她。"
    "棍母"

# game/script.rpy:1106
translate gunmu start_a6fc8fd5:

    # "姿势有些亲密。"
    "棍母"

# game/script.rpy:1108
translate gunmu start_5a0af50f:

    # huge "哎呀，这俩妹子都喝倒了。"
    huge "棍母"

# game/script.rpy:1109
translate gunmu start_59b42ba1:

    # "虎哥走过来。"
    "棍母"

# game/script.rpy:1110
translate gunmu start_c67be6a8:

    # "看着倒在沙发上的两人。"
    "棍母"

# game/script.rpy:1112
translate gunmu start_ac374f43:

    # "摇了摇头。"
    "棍母"

# game/script.rpy:1113
translate gunmu start_59fb3e51:

    # "脸上露出无奈的笑容。"
    "棍母"

# game/script.rpy:1115
translate gunmu start_194b0021:

    # hugexiaodi "虎哥，咋整？"
    hugexiaodi "棍母"

# game/script.rpy:1116
translate gunmu start_7a39cee5:

    # "一个小弟问。"
    "棍母"

# game/script.rpy:1117
translate gunmu start_f329efe0:

    # "看着沙发上的两人。"
    "棍母"

# game/script.rpy:1119
translate gunmu start_13fea223:

    # huge "还能咋整，送酒店去呗！"
    huge "棍母"

# game/script.rpy:1120
translate gunmu start_58be09e0:

    # "虎哥回答。"
    "棍母"

# game/script.rpy:1121
translate gunmu start_9593563d:

    # "语气很自然。"
    "棍母"

# game/script.rpy:1123
translate gunmu start_8e8c5b65:

    # huge "老板，开两间房！"
    huge "棍母"

# game/script.rpy:1124
translate gunmu start_4ad48242:

    # "他朝KTV老板喊。"
    "棍母"

# game/script.rpy:1125
translate gunmu start_0a799716_1:

    # "声音很大。"
    "棍母"

# game/script.rpy:1127
translate gunmu start_d55047e7:

    # "虎哥掏出钱包。"
    "棍母"

# game/script.rpy:1128
translate gunmu start_81fa48fc:

    # "开始结账。"
    "棍母"

# game/script.rpy:1129
translate gunmu start_62641874:

    # "数出一叠钞票。"
    "棍母"

# game/script.rpy:1134
translate gunmu start_d6cdd3e7:

    # "虎哥和小弟们扶着醉醺醺的雨姐和宁宁来到附近的酒店。"
    "棍母"

# game/script.rpy:1135
translate gunmu start_5bb77ea7:

    # "酒店大堂的灯光很柔和。"
    "棍母"

# game/script.rpy:1136
translate gunmu start_fc780632:

    # "米色的大理石地面。"
    "棍母"

# game/script.rpy:1138
translate gunmu start_e233ea81:

    # "前台服务员看了看他们。"
    "棍母"

# game/script.rpy:1139
translate gunmu start_2ed5c06b:

    # "没有多问。"
    "棍母"

# game/script.rpy:1140
translate gunmu start_b7786599:

    # "显然见惯了这种场面。"
    "棍母"

# game/script.rpy:1142
translate gunmu start_23ecf90c:

    # landy "我好困....."
    landy "棍母"

# game/script.rpy:1143
translate gunmu start_ade30d35:

    # "雨姐含糊地说着。"
    "棍母"

# game/script.rpy:1144
translate gunmu start_8e955b10:

    # "几乎站不稳。"
    "棍母"

# game/script.rpy:1146
translate gunmu start_f87e6fd5:

    # "腿软得像面条。"
    "棍母"

# game/script.rpy:1147
translate gunmu start_dcfdd46e:

    # "要不是虎哥扶着，早就倒在地上了。"
    "棍母"

# game/script.rpy:1149
translate gunmu start_e9eca62c:

    # huge "困了睡觉!"
    huge "棍母"

# game/script.rpy:1150
translate gunmu start_9b129633:

    # "虎哥费力地扶着两人。"
    "棍母"

# game/script.rpy:1151
translate gunmu start_2c96e45b:

    # "一手一个。"
    "棍母"

# game/script.rpy:1153
translate gunmu start_9372388e:

    # "进了电梯。"
    "棍母"

# game/script.rpy:1154
translate gunmu start_2ade691e:

    # "电梯门缓缓关闭。"
    "棍母"

# game/script.rpy:1156
translate gunmu start_893ef06f:

    # "镜面映出歪歪扭扭的一群人。"
    "棍母"

# game/script.rpy:1157
translate gunmu start_74fb85a6:

    # "看起来有些滑稽。"
    "棍母"

# game/script.rpy:1159
translate gunmu start_75a7604d:

    # "房间里。"
    "棍母"

# game/script.rpy:1160
translate gunmu start_f91a8b3e:

    # "两人被小心地放在床上。"
    "棍母"

# game/script.rpy:1161
translate gunmu start_0d560f97:

    # "床垫柔软。"
    "棍母"

# game/script.rpy:1164
translate gunmu start_a8e6f332:

    # "床发出轻微的吱呀声。"
    "棍母"

# game/script.rpy:1165
translate gunmu start_4e677fe9:

    # "两人倒在一起。"
    "棍母"

# game/script.rpy:1167
translate gunmu start_e91e08d7:

    # ANe "（头好晕…雨姐的手好暖…）"
    ANe "棍母"

# game/script.rpy:1168
translate gunmu start_44c4802c:

    # "宁宁在半梦半醒间想着。"
    "棍母"

# game/script.rpy:1169
translate gunmu start_ee014cc9:

    # "意识模糊。"
    "棍母"

# game/script.rpy:1171
translate gunmu start_8c819d2a:

    # ANe "（我从来没喝过这么多酒…但是…感觉不坏…）"
    ANe "棍母"

# game/script.rpy:1172
translate gunmu start_a6292531:

    # "雨姐的手搭在她身上。"
    "棍母"

# game/script.rpy:1173
translate gunmu start_3ed0f3a3:

    # "很温暖，很安心。"
    "棍母"

# game/script.rpy:1175
translate gunmu start_af26ecc8:

    # zj "宁宁？宁宁？"
    zj "棍母"

# game/script.rpy:1176
translate gunmu start_f173be10:

    # "雨姐轻声叫。"
    "棍母"

# game/script.rpy:1177
translate gunmu start_45c76d11:

    # "声音很轻，像是在说梦话。"
    "棍母"

# game/script.rpy:1179
translate gunmu start_87b1a982:

    # zj "嘿嘿，睡着了啊…"
    zj "棍母"

# game/script.rpy:1180
translate gunmu start_90278f66:

    # "她看着宁宁安静的睡脸。"
    "棍母"

# game/script.rpy:1181
translate gunmu start_e4a03dc9:

    # "突然觉得这个平时害羞的日本女孩此刻格外可爱。"
    "棍母"

# game/script.rpy:1183
translate gunmu start_bf8843c0:

    # "她的睫毛很长。"
    "棍母"

# game/script.rpy:1184
translate gunmu start_82693437:

    # "在眼下投出阴影。"
    "棍母"

# game/script.rpy:1185
translate gunmu start_8b59ed41:

    # "像两把小扇子。"
    "棍母"

# game/script.rpy:1187
translate gunmu start_f336a594:

    # "脸颊因为醉酒而泛红。"
    "棍母"

# game/script.rpy:1188
translate gunmu start_fcebb66d:

    # "嘴唇微微张开。"
    "棍母"

# game/script.rpy:1189
translate gunmu start_97416f44:

    # "呼吸均匀。"
    "棍母"

# game/script.rpy:1191
translate gunmu start_35cab27c:

    # zj "（其实…她也没那么难相处嘛…）"
    zj "棍母"

# game/script.rpy:1192
translate gunmu start_dbbacf3d:

    # "雨姐也倒了下去。"
    "棍母"

# game/script.rpy:1193
translate gunmu start_1ef7d206:

    # "两人的手不知不觉地搭在了一起。"
    "棍母"

# game/script.rpy:1195
translate gunmu start_a5bda4aa:

    # "手指交错。"
    "棍母"

# game/script.rpy:1196
translate gunmu start_b319bd21:

    # "像是握着对方的手。"
    "棍母"

# game/script.rpy:1197
translate gunmu start_24bd2eca:

    # "很自然，很舒服。"
    "棍母"

# game/script.rpy:1199
translate gunmu start_8e85f8e3:

    # "房间里只剩下均匀的呼吸声。"
    "棍母"

# game/script.rpy:1200
translate gunmu start_b26e28bf:

    # "还有空调的低鸣。"
    "棍母"

# game/script.rpy:1201
translate gunmu start_283e569f:

    # "嗡嗡作响。"
    "棍母"

# game/script.rpy:1206
translate gunmu start_539ee779:

    # "(半夜0:27分)"
    "棍母"

# game/script.rpy:1207
translate gunmu start_4d8b34ba:

    # "时间悄然流逝。"
    "棍母"

# game/script.rpy:1208
translate gunmu start_b87fbdf3:

    # "走廊里静悄悄的。"
    "棍母"

# game/script.rpy:1210
translate gunmu start_1856d7a2:

    # "只有安全出口的绿灯发出微弱的光。"
    "棍母"

# game/script.rpy:1211
translate gunmu start_dd030d6a:

    # "在地面投下幽幽的绿色。"
    "棍母"

# game/script.rpy:1212
translate gunmu start_5242b60d:

    # "像是鬼火。"
    "棍母"

# game/script.rpy:1214
translate gunmu start_e5e5f981:

    # "这时,门外面传来轻微的声响。"
    "棍母"

# game/script.rpy:1215
translate gunmu start_df8a94b1:

    # "像是脚步声。"
    "棍母"

# game/script.rpy:1216
translate gunmu start_f95850aa:

    # "但很轻很轻。"
    "棍母"

# game/script.rpy:1218
translate gunmu start_61384f4b:

    # xiaotou "这间应该都睡着了。"
    xiaotou "棍母"

# game/script.rpy:1219
translate gunmu start_20e0d888:

    # "一个男人的声音。"
    "棍母"

# game/script.rpy:1220
translate gunmu start_7cc6800e:

    # "压得很低。"
    "棍母"

# game/script.rpy:1222
translate gunmu start_8ab8dab7:

    # "沙哑而谨慎。"
    "棍母"

# game/script.rpy:1223
translate gunmu start_d2ac6651:

    # "听起来不像是好人。"
    "棍母"

# game/script.rpy:1225
translate gunmu start_ccee909f:

    # xiaotou "行动。"
    xiaotou "棍母"

# game/script.rpy:1226
translate gunmu start_3012f044:

    # "另一个声音回答。"
    "棍母"

# game/script.rpy:1227
translate gunmu start_38fef790:

    # "同样很轻。"
    "棍母"

# game/script.rpy:1230
translate gunmu start_8521c66b:

    # "门锁传来轻微的咔嗒声。"
    "棍母"

# game/script.rpy:1231
translate gunmu start_fcd8437c:

    # "像是金属工具在拨动。"
    "棍母"

# game/script.rpy:1232
translate gunmu start_12e259f0:

    # "很专业的手法。"
    "棍母"

# game/script.rpy:1234
translate gunmu start_26d3e501:

    # "此时,虎哥刚好出来上厕所。"
    "棍母"

# game/script.rpy:1235
translate gunmu start_b1ccccd9:

    # "听到了动静。"
    "棍母"

# game/script.rpy:1236
translate gunmu start_e2e7ed46:

    # "他刚从厕所出来。"
    "棍母"

# game/script.rpy:1238
translate gunmu start_c69fb6be:

    # huge "(os:哎我操,这他妈谁,半夜....发出这么大声)"
    huge "棍母"

# game/script.rpy:1239
translate gunmu start_534ef581:

    # "他揉着眼睛。"
    "棍母"

# game/script.rpy:1240
translate gunmu start_d7b43796:

    # "朝声音的方向看去。"
    "棍母"

# game/script.rpy:1242
translate gunmu start_4faa19ac:

    # "虎哥看了一眼门牌号。"
    "棍母"

# game/script.rpy:1243
translate gunmu start_40adfe63:

    # "昏暗的光线下。"
    "棍母"

# game/script.rpy:1244
translate gunmu start_bf1e958a:

    # "他辨认出门牌号。"
    "棍母"

# game/script.rpy:1246
translate gunmu start_5e8d65b7:

    # "“207”。"
    "棍母"

# game/script.rpy:1247
translate gunmu start_dd33d16a:

    # "正是雨姐和宁宁的房间。"
    "棍母"

# game/script.rpy:1249
translate gunmu start_81e8bbff:

    # "发现是东北雨姐和绫地宁宁的房间。"
    "棍母"

# game/script.rpy:1250
translate gunmu start_ae016f83:

    # "(愤怒)"
    "棍母"

# game/script.rpy:1252
translate gunmu start_abdb5755:

    # "虎哥的酒一下子醒了。"
    "棍母"

# game/script.rpy:1253
translate gunmu start_3e792c2e:

    # "眉头紧锁。"
    "棍母"

# game/script.rpy:1254
translate gunmu start_ae681bab:

    # "眼神变得锐利。"
    "棍母"

# game/script.rpy:1256
translate gunmu start_ec52dcfc:

    # "虎哥悄悄地走到了小偷后面。"
    "棍母"

# game/script.rpy:1257
translate gunmu start_4bb668d3:

    # "像一只捕食的老虎。"
    "棍母"

# game/script.rpy:1258
translate gunmu start_5a792338:

    # "脚步轻盈无声。"
    "棍母"

# game/script.rpy:1260
translate gunmu start_5cfcd195:

    # "这时,小偷刚好也往后看。"
    "棍母"

# game/script.rpy:1261
translate gunmu start_022082c7:

    # "顿时被虎哥的高大个吓到了。"
    "棍母"

# game/script.rpy:1262
translate gunmu start_78c00aa5:

    # "手里的工具掉在地上。"
    "棍母"

# game/script.rpy:1265
translate gunmu start_ee1a4c84:

    # "发出清脆的响声。"
    "棍母"

# game/script.rpy:1266
translate gunmu start_8f7884e2:

    # "在安静的走廊里格外刺耳。"
    "棍母"

# game/script.rpy:1268
translate gunmu start_563d0d0d:

    # huge "(强忍着怒火)"
    huge "棍母"

# game/script.rpy:1269
translate gunmu start_fa64646a:

    # "虎哥咬紧牙关。"
    "棍母"

# game/script.rpy:1270
translate gunmu start_29d3e988:

    # "拳头握紧。"
    "棍母"

# game/script.rpy:1272
translate gunmu start_07c2da1f:

    # huge "(压低声音)"
    huge "棍母"

# game/script.rpy:1273
translate gunmu start_ba7e85c4:

    # "他开口。"
    "棍母"

# game/script.rpy:1274
translate gunmu start_e01c0594:

    # "声音很低，但充满威胁。"
    "棍母"

# game/script.rpy:1276
translate gunmu start_fad35b65:

    # hugeg "干啥呢。"
    hugeg "棍母"

# game/script.rpy:1277
translate gunmu start_6cf0d9b4:

    # "三个字。"
    "棍母"

# game/script.rpy:1278
translate gunmu start_4a0b202c:

    # "但充满压迫感。"
    "棍母"

# game/script.rpy:1280
translate gunmu start_fd0cd536:

    # xiaotou "(吓一跳) 啊？！"
    xiaotou "棍母"

# game/script.rpy:1281
translate gunmu start_1c1c1b0a:

    # "小偷后退一步。"
    "棍母"

# game/script.rpy:1282
translate gunmu start_49730ddd:

    # "撞到了墙上。"
    "棍母"

# game/script.rpy:1284
translate gunmu start_90b6beda:

    # "咚的一声闷响。"
    "棍母"

# game/script.rpy:1285
translate gunmu start_1902ea3d:

    # "在走廊里回荡。"
    "棍母"

# game/script.rpy:1287
translate gunmu start_93f248e3:

    # hugeg "干啥呢??"
    hugeg "棍母"

# game/script.rpy:1288
translate gunmu start_942ee230:

    # "虎哥的声音更低沉了。"
    "棍母"

# game/script.rpy:1289
translate gunmu start_7b723822:

    # "充满了威胁。"
    "棍母"

# game/script.rpy:1291
translate gunmu start_52a40d90:

    # xiaotou "(惊慌) 我...我找错房间了..."
    xiaotou "棍母"

# game/script.rpy:1292
translate gunmu start_0c8fc518:

    # "小偷结结巴巴。"
    "棍母"

# game/script.rpy:1293
translate gunmu start_27b7b420:

    # "声音发抖。"
    "棍母"

# game/script.rpy:1295
translate gunmu start_88c716f1:

    # huge "找错房间？"
    huge "棍母"

# game/script.rpy:1296
translate gunmu start_e9709ec7:

    # "虎哥冷笑一声。"
    "棍母"

# game/script.rpy:1297
translate gunmu start_dc82c7c3:

    # "显然不相信。"
    "棍母"

# game/script.rpy:1299
translate gunmu start_a7fd3d17:

    # "这时,虎哥向后一看。"
    "棍母"

# game/script.rpy:1300
translate gunmu start_6dfc6778:

    # "他的目光落在小偷的手上。"
    "棍母"

# game/script.rpy:1301
translate gunmu start_80f5aef3:

    # "发现了可疑的东西。"
    "棍母"

# game/script.rpy:1303
translate gunmu start_d7935525:

    # "..............."
    "棍母"

# game/script.rpy:1304
translate gunmu start_4885ae55:

    # "他沉默了几秒。"
    "棍母"

# game/script.rpy:1305
translate gunmu start_e22b66dd:

    # "眼睛眯起来。"
    "棍母"

# game/script.rpy:1307
translate gunmu start_278c7e29:

    # "........."
    "棍母"

# game/script.rpy:1308
translate gunmu start_84a62f1d:

    # "盯着小偷的手。"
    "棍母"

# game/script.rpy:1309
translate gunmu start_e08893f4:

    # "一动不动。"
    "棍母"

# game/script.rpy:1311
translate gunmu start_07bdde05:

    # "....."
    "棍母"

# game/script.rpy:1312
translate gunmu start_c091c60a:

    # "瞳孔收缩。"
    "棍母"

# game/script.rpy:1313
translate gunmu start_bb7e87c4:

    # "像是发现了猎物。"
    "棍母"

# game/script.rpy:1315
translate gunmu start_0c61e318:

    # "虎哥看到小偷手里拿着一个钱包。"
    "棍母"

# game/script.rpy:1316
translate gunmu start_8a0ec491:

    # "正是雨姐的钱包。"
    "棍母"

# game/script.rpy:1317
translate gunmu start_fe5ba7a8:

    # "在昏暗的光线下依稀可见。"
    "棍母"

# game/script.rpy:1319
translate gunmu start_599d3fbc:

    # "粉色的皮质。"
    "棍母"

# game/script.rpy:1320
translate gunmu start_ec155d3e:

    # "边缘有磨损。"
    "棍母"

# game/script.rpy:1321
translate gunmu start_8a0ec491_1:

    # "正是雨姐的钱包。"
    "棍母"

# game/script.rpy:1323
translate gunmu start_debe78c0:

    # huge "手里拿的啥玩意儿？"
    huge "棍母"

# game/script.rpy:1324
translate gunmu start_16601ca5:

    # "虎哥问。"
    "棍母"

# game/script.rpy:1325
translate gunmu start_8e7c07de:

    # "语气冰冷。"
    "棍母"

# game/script.rpy:1327
translate gunmu start_96ccc58b:

    # xiaotou "(想跑) 没...没什么..."
    xiaotou "棍母"

# game/script.rpy:1328
translate gunmu start_1b440834:

    # "小偷想把钱包藏到身后。"
    "棍母"

# game/script.rpy:1329
translate gunmu start_aafb5574:

    # "但已经来不及了。"
    "棍母"

# game/script.rpy:1331
translate gunmu start_572bc36d:

    # "虎哥一把抓住小偷的衣领。"
    "棍母"

# game/script.rpy:1332
translate gunmu start_50385985:

    # "像拎小鸡一样把他提了起来。"
    "棍母"

# game/script.rpy:1333
translate gunmu start_3eeca142:

    # "双脚离地。"
    "棍母"

# game/script.rpy:1335
translate gunmu start_9707c764:

    # hugeg "我再问你一遍。"
    hugeg "棍母"

# game/script.rpy:1336
translate gunmu start_4f0b98c4:

    # "虎哥盯着他的眼睛。"
    "棍母"

# game/script.rpy:1337
translate gunmu start_dce79461:

    # "眼神凶狠。"
    "棍母"

# game/script.rpy:1339
translate gunmu start_ac08980f:

    # hugeg "手里拿的啥玩意儿？"
    hugeg "棍母"

# game/script.rpy:1340
translate gunmu start_d7935525_1:

    # "..............."
    "棍母"

# game/script.rpy:1341
translate gunmu start_cdebe60b:

    # "小偷不敢说话。"
    "棍母"

# game/script.rpy:1342
translate gunmu start_5f58ef7a:

    # "只能发出呜咽。"
    "棍母"

# game/script.rpy:1344
translate gunmu start_278c7e29_1:

    # "........."
    "棍母"

# game/script.rpy:1345
translate gunmu start_56f1fbdd:

    # "虎哥的眼睛里冒着火。"
    "棍母"

# game/script.rpy:1346
translate gunmu start_daeb4d3c:

    # "酒气混合着怒气。"
    "棍母"

# game/script.rpy:1348
translate gunmu start_a5d665f6:

    # huge "(怒气爆发) 偷我雨姐东西？！"
    huge "棍母"

# game/script.rpy:1349
translate gunmu start_e4e0ab1a:

    # "他吼道。"
    "棍母"

# game/script.rpy:1350
translate gunmu start_7d171673:

    # "声音很大，但没吵醒房间里的人。"
    "棍母"

# game/script.rpy:1352
translate gunmu start_38ebf78a:

    # hugeg "你他妈活腻歪了！"
    hugeg "棍母"

# game/script.rpy:1353
translate gunmu start_8fce1316:

    # "(颤抖) 大哥我错了！"
    "棍母"

# game/script.rpy:1354
translate gunmu start_f86cd815:

    # "小偷发抖。"
    "棍母"

# game/script.rpy:1356
translate gunmu start_41ac489a:

    # xiaotou "我...我还回去！"
    xiaotou "棍母"

# game/script.rpy:1357
translate gunmu start_72e181ea:

    # "现在知道错了？"
    "棍母"

# game/script.rpy:1358
translate gunmu start_9f4859b1:

    # "虎哥冷笑。"
    "棍母"

# game/script.rpy:1360
translate gunmu start_9d4653f4:

    # huge "晚了！"
    huge "棍母"

# game/script.rpy:1361
translate gunmu start_cdb165c9:

    # "他一只手拎着小偷。"
    "棍母"

# game/script.rpy:1362
translate gunmu start_3abbc85c:

    # "另一只手敲了敲雨姐房间的门。"
    "棍母"

# game/script.rpy:1365
translate gunmu start_a057ab26:

    # "咚，咚，咚。"
    "棍母"

# game/script.rpy:1366
translate gunmu start_3d961fac:

    # "三声敲门。"
    "棍母"

# game/script.rpy:1368
translate gunmu start_647760d1:

    # huge "雨姐！醒醒！"
    huge "棍母"

# game/script.rpy:1369
translate gunmu start_9dd9bc6e:

    # "他喊道。"
    "棍母"

# game/script.rpy:1370
translate gunmu start_23b34bc5:

    # "声音有些大。"
    "棍母"

# game/script.rpy:1372
translate gunmu start_67a57f9a:

    # huge "抓了个小偷！"
    huge "棍母"

# game/script.rpy:1373
translate gunmu start_3016c8b6:

    # "房间里传来含糊的回应。"
    "棍母"

# game/script.rpy:1374
translate gunmu start_f10ca7b4:

    # "但没人开门。"
    "棍母"

# game/script.rpy:1376
translate gunmu start_e4c9abe9:

    # "显然两人睡得很沉。"
    "棍母"

# game/script.rpy:1377
translate gunmu start_66d4bab4:

    # "酒精的作用还没过去。"
    "棍母"

# game/script.rpy:1379
translate gunmu start_30bfa54e:

    # huge "啧..."
    huge "棍母"

# game/script.rpy:1380
translate gunmu start_036f81ae:

    # "虎哥咂嘴。"
    "棍母"

# game/script.rpy:1381
translate gunmu start_0424f44d:

    # "有些不耐烦。"
    "棍母"

# game/script.rpy:1383
translate gunmu start_3c5a4f8e:

    # huge "这俩妹子喝得够呛..."
    huge "棍母"

# game/script.rpy:1384
translate gunmu start_c5020307:

    # "他无奈地摇了摇头。"
    "棍母"

# game/script.rpy:1385
translate gunmu start_fff96c34:

    # "脸上露出无奈的表情。"
    "棍母"

# game/script.rpy:1387
translate gunmu start_d83bcbf1:

    # hugexiaodi "(听到动静走过来) 虎哥，咋回事？"
    hugexiaodi "棍母"

# game/script.rpy:1388
translate gunmu start_4e5e1964:

    # "一个小弟出现。"
    "棍母"

# game/script.rpy:1389
translate gunmu start_284533a0:

    # "睡眼惺忪。"
    "棍母"

# game/script.rpy:1391
translate gunmu start_5eb5fc73:

    # huge "抓了个偷东西的！"
    huge "棍母"

# game/script.rpy:1392
translate gunmu start_58be09e0_1:

    # "虎哥回答。"
    "棍母"

# game/script.rpy:1393
translate gunmu start_51ae04db:

    # "语气严肃。"
    "棍母"

# game/script.rpy:1395
translate gunmu start_84df5ea5:

    # huge "去把兄弟们叫起来！"
    huge "棍母"

# game/script.rpy:1396
translate gunmu start_b34d3057:

    # "好嘞！"
    "棍母"

# game/script.rpy:1398
translate gunmu start_b0c76519:

    # "小弟跑开。"
    "棍母"

# game/script.rpy:1399
translate gunmu start_4c26f7c2:

    # "脚步声在走廊里回荡。"
    "棍母"

# game/script.rpy:1401
translate gunmu start_08e9199d:

    # "不一会儿，几个小弟都围了过来。"
    "棍母"

# game/script.rpy:1402
translate gunmu start_81eca436:

    # "睡眼惺忪但很快清醒了。"
    "棍母"

# game/script.rpy:1403
translate gunmu start_17c551cf:

    # "看到小偷，都明白了情况。"
    "棍母"

# game/script.rpy:1405
translate gunmu start_caf992e4:

    # xiaotou "(快哭了) 各位大哥..."
    xiaotou "棍母"

# game/script.rpy:1406
translate gunmu start_44ac42bd:

    # "小偷哀求。"
    "棍母"

# game/script.rpy:1407
translate gunmu start_258bbe7b:

    # "声音带着哭腔。"
    "棍母"

# game/script.rpy:1409
translate gunmu start_357c53cb:

    # xiaotou "我真错了..."
    xiaotou "棍母"

# game/script.rpy:1410
translate gunmu start_e3067737:

    # "错？"
    "棍母"

# game/script.rpy:1411
translate gunmu start_8d7d3d6d:

    # "虎哥盯着他。"
    "棍母"

# game/script.rpy:1413
translate gunmu start_be1836df:

    # huge "偷我朋友东西。"
    huge "棍母"

# game/script.rpy:1414
translate gunmu start_aad628fb:

    # "这事儿没完！"
    "棍母"

# game/script.rpy:1415
translate gunmu start_13f7caa5:

    # "虎哥掏出手机。"
    "棍母"

# game/script.rpy:1417
translate gunmu start_f2019960:

    # "但想了想又放回去了。"
    "棍母"

# game/script.rpy:1418
translate gunmu start_65acd50a:

    # "似乎觉得没必要报警。"
    "棍母"

# game/script.rpy:1420
translate gunmu start_b539b725:

    # huge "都给我过来！"
    huge "棍母"

# game/script.rpy:1421
translate gunmu start_7341aa86:

    # "他命令。"
    "棍母"

# game/script.rpy:1422
translate gunmu start_ad436ac4:

    # "语气不容置疑。"
    "棍母"

# game/script.rpy:1424
translate gunmu start_e5da9afc:

    # huge "今天给这兄弟上上课！"
    huge "棍母"

# game/script.rpy:1425
translate gunmu start_bc490bb6:

    # "好嘞虎哥！"
    "棍母"

# game/script.rpy:1427
translate gunmu start_3ff2981e:

    # "小弟们响应。"
    "棍母"

# game/script.rpy:1428
translate gunmu start_105f11d3:

    # "声音整齐。"
    "棍母"

# game/script.rpy:1430
translate gunmu start_acf9538e:

    # "几个小弟把小偷围在中间。"
    "棍母"

# game/script.rpy:1431
translate gunmu start_983b8dc2:

    # "酒店走廊顿时变成了'课堂'。"
    "棍母"

# game/script.rpy:1432
translate gunmu start_78a463eb:

    # "气氛有些诡异。"
    "棍母"

# game/script.rpy:1434
translate gunmu start_c99c119a:

    # "昏暗的灯光下。"
    "棍母"

# game/script.rpy:1435
translate gunmu start_76c7a714:

    # "几个身影围成一圈。"
    "棍母"

# game/script.rpy:1436
translate gunmu start_926f3383:

    # "影子拉得很长。"
    "棍母"

# game/script.rpy:1438
translate gunmu start_d198d07d:

    # huge "第一课：不能偷东西，懂不？"
    huge "棍母"

# game/script.rpy:1439
translate gunmu start_d489ec57:

    # "虎哥开始'教学'。"
    "棍母"

# game/script.rpy:1440
translate gunmu start_51ae04db_1:

    # "语气严肃。"
    "棍母"

# game/script.rpy:1442
translate gunmu start_d11008af:

    # xiaotou "懂...懂了..."
    xiaotou "棍母"

# game/script.rpy:1443
translate gunmu start_d6fa2e61:

    # "小偷小声回答。"
    "棍母"

# game/script.rpy:1444
translate gunmu start_27b7b420_1:

    # "声音发抖。"
    "棍母"

# game/script.rpy:1446
translate gunmu start_e3e79544:

    # hugexiaodi "大声点！没吃饭啊！"
    hugexiaodi "棍母"

# game/script.rpy:1447
translate gunmu start_c4fcca1f:

    # "一个小弟吼道。"
    "棍母"

# game/script.rpy:1448
translate gunmu start_0a799716_2:

    # "声音很大。"
    "棍母"

# game/script.rpy:1450
translate gunmu start_411da774:

    # xiaotouh "懂了！！！"
    xiaotouh "棍母"

# game/script.rpy:1451
translate gunmu start_bc5e2303:

    # "小偷几乎是喊出来的。"
    "棍母"

# game/script.rpy:1452
translate gunmu start_7d904e37:

    # "声音在走廊里回荡。"
    "棍母"

# game/script.rpy:1454
translate gunmu start_95086231:

    # huge "第二课：偷谁都不能偷我朋友！"
    huge "棍母"

# game/script.rpy:1455
translate gunmu start_ae7c8a0b:

    # "虎哥继续说。"
    "棍母"

# game/script.rpy:1456
translate gunmu start_79e8b30a:

    # "语气更严肃了。"
    "棍母"

# game/script.rpy:1458
translate gunmu start_57d61471:

    # hugexiaodi "特别是雨姐！"
    hugexiaodi "棍母"

# game/script.rpy:1459
translate gunmu start_852a2f51:

    # "他强调。"
    "棍母"

# game/script.rpy:1460
translate gunmu start_35294095:

    # "语气很重。"
    "棍母"

# game/script.rpy:1462
translate gunmu start_906c416d:

    # xiaotou "我记住了...再也不敢了..."
    xiaotou "棍母"

# game/script.rpy:1463
translate gunmu start_98c1c3b1:

    # "小偷的声音带着哭腔。"
    "棍母"

# game/script.rpy:1464
translate gunmu start_424c4896:

    # "真的快哭了。"
    "棍母"

# game/script.rpy:1466
translate gunmu start_f98ea894:

    # "虎哥拿过钱包检查了一下。"
    "棍母"

# game/script.rpy:1467
translate gunmu start_99d00abc:

    # "打开看了看。"
    "棍母"

# game/script.rpy:1468
translate gunmu start_1d148d4b:

    # "确认东西都在。"
    "棍母"

# game/script.rpy:1470
translate gunmu start_fc702b56:

    # "几张钞票。"
    "棍母"

# game/script.rpy:1471
translate gunmu start_dd9a7e4a:

    # "一张身份证。"
    "棍母"

# game/script.rpy:1472
translate gunmu start_7c7c6070:

    # "几枚硬币。"
    "棍母"

# game/script.rpy:1474
translate gunmu start_74b8bf23:

    # huge "钱少了没？"
    huge "棍母"

# game/script.rpy:1475
translate gunmu start_0a94498e:

    # "他问。"
    "棍母"

# game/script.rpy:1476
translate gunmu start_9a9a3523:

    # "眼睛盯着小偷。"
    "棍母"

# game/script.rpy:1478
translate gunmu start_27c6f127:

    # xiaotou "没...还没来得及..."
    xiaotou "棍母"

# game/script.rpy:1479
translate gunmu start_c7003e79:

    # "小偷老实回答。"
    "棍母"

# game/script.rpy:1480
translate gunmu start_1bd2c6a9:

    # "不敢撒谎。"
    "棍母"

# game/script.rpy:1482
translate gunmu start_6c018ff4:

    # huge "算你走运。"
    huge "棍母"

# game/script.rpy:1483
translate gunmu start_20fc63fd:

    # "虎哥合上钱包。"
    "棍母"

# game/script.rpy:1484
translate gunmu start_a5b09f88:

    # "表情稍微缓和了一点。"
    "棍母"

# game/script.rpy:1486
translate gunmu start_71d473d4:

    # huge "第三课：以后走正道，听见没？"
    huge "棍母"

# game/script.rpy:1487
translate gunmu start_d4ebe4c9:

    # "听见了！"
    "棍母"

# game/script.rpy:1489
translate gunmu start_6542206c:

    # "小偷大声回答。"
    "棍母"

# game/script.rpy:1490
translate gunmu start_5fa8e5d3:

    # "不敢再小声了。"
    "棍母"

# game/script.rpy:1492
translate gunmu start_46bfdd60:

    # "虎哥盯着小偷看了几秒钟。"
    "棍母"

# game/script.rpy:1493
translate gunmu start_b2ea2968:

    # "然后松开了手。"
    "棍母"

# game/script.rpy:1494
translate gunmu start_1a4a6493:

    # "小偷摔在地上。"
    "棍母"

# game/script.rpy:1497
translate gunmu start_8ff70eae:

    # "摔得很重。"
    "棍母"

# game/script.rpy:1498
translate gunmu start_3fdfe5e4:

    # "但不敢喊疼。"
    "棍母"

# game/script.rpy:1500
translate gunmu start_a4e591fd:

    # huge "行了，给他手机拍个照。"
    huge "棍母"

# game/script.rpy:1501
translate gunmu start_415d37bc:

    # "虎哥对小弟说。"
    "棍母"

# game/script.rpy:1502
translate gunmu start_c18436e9:

    # "留个档案。"
    "棍母"

# game/script.rpy:1504
translate gunmu start_f84157a5:

    # huge "再让我逮着..."
    huge "棍母"

# game/script.rpy:1505
translate gunmu start_3dbda9e3:

    # "他停顿。"
    "棍母"

# game/script.rpy:1506
translate gunmu start_04309d5a:

    # "制造悬念。"
    "棍母"

# game/script.rpy:1508
translate gunmu start_b8221e7d:

    # hugexiaodi "(齐声) 腿给你打折！"
    hugexiaodi "棍母"

# game/script.rpy:1509
translate gunmu start_56ee7f25:

    # "小弟们接话。"
    "棍母"

# game/script.rpy:1510
translate gunmu start_54282379:

    # "声音整齐，气势十足。"
    "棍母"

# game/script.rpy:1512
translate gunmu start_cfa3deac:

    # "小偷连滚带爬地跑了。"
    "棍母"

# game/script.rpy:1513
translate gunmu start_c44088f0:

    # "脚步声在走廊里渐行渐远。"
    "棍母"

# game/script.rpy:1514
translate gunmu start_13bebb4e:

    # "很慌张。"
    "棍母"

# game/script.rpy:1516
translate gunmu start_220c26e6:

    # hugexiaodi "虎哥，就这么放他走了？"
    hugexiaodi "棍母"

# game/script.rpy:1517
translate gunmu start_7a39cee5_1:

    # "一个小弟问。"
    "棍母"

# game/script.rpy:1518
translate gunmu start_e9bda210:

    # "似乎觉得太便宜小偷了。"
    "棍母"

# game/script.rpy:1520
translate gunmu start_16b5f78f:

    # huge "钱包拿回来了就行。"
    huge "棍母"

# game/script.rpy:1521
translate gunmu start_545d4b54_1:

    # "虎哥摆摆手。"
    "棍母"

# game/script.rpy:1522
translate gunmu start_1972aadb:

    # "显得有些不耐烦。"
    "棍母"

# game/script.rpy:1524
translate gunmu start_c7d73618:

    # huge "把钱包放回雨姐房间去。"
    huge "棍母"

# game/script.rpy:1525
translate gunmu start_7341aa86_1:

    # "他命令。"
    "棍母"

# game/script.rpy:1526
translate gunmu start_d7b943b0:

    # "语气恢复平静。"
    "棍母"

# game/script.rpy:1528
translate gunmu start_feee6834:

    # "虎哥轻轻打开门。"
    "棍母"

# game/script.rpy:1529
translate gunmu start_a5baada1:

    # "门没锁。"
    "棍母"

# game/script.rpy:1530
translate gunmu start_88862749:

    # "只是虚掩着。"
    "棍母"

# game/script.rpy:1533
translate gunmu start_66f247fa:

    # "他走进房间。"
    "棍母"

# game/script.rpy:1534
translate gunmu start_04b3f750:

    # "脚步很轻。"
    "棍母"

# game/script.rpy:1536
translate gunmu start_b3a1b4f5:

    # "他把钱包放在桌上。"
    "棍母"

# game/script.rpy:1537
translate gunmu start_0e3885df:

    # "月光透过窗帘照进来。"
    "棍母"

# game/script.rpy:1538
translate gunmu start_105b7bd0:

    # "在桌面投下窗格的影子。"
    "棍母"

# game/script.rpy:1540
translate gunmu start_1de2ac5c:

    # "床上两人睡得正香。"
    "棍母"

# game/script.rpy:1541
translate gunmu start_1851d47c:

    # "对刚才发生的一切毫无察觉。"
    "棍母"

# game/script.rpy:1542
translate gunmu start_470c0fb8:

    # "宁宁翻了个身。"
    "棍母"

# game/script.rpy:1545
translate gunmu start_a8e6f332_1:

    # "床发出轻微的吱呀声。"
    "棍母"

# game/script.rpy:1546
translate gunmu start_eda6069e:

    # "她又不动了。"
    "棍母"

# game/script.rpy:1548
translate gunmu start_eb33eea1:

    # huge "(看了眼床上) 这俩睡得够死的..."
    huge "棍母"

# game/script.rpy:1549
translate gunmu start_a959b886:

    # "虎哥摇摇头。"
    "棍母"

# game/script.rpy:1550
translate gunmu start_59fb3e51_1:

    # "脸上露出无奈的笑容。"
    "棍母"

# game/script.rpy:1552
translate gunmu start_ea3b22cb:

    # "轻轻关上了门。"
    "棍母"

# game/script.rpy:1554
translate gunmu start_24989d7b:

    # "咔哒一声轻响。"
    "棍母"

# game/script.rpy:1555
translate gunmu start_d50761b2:

    # "很轻，不会吵醒她们。"
    "棍母"

# game/script.rpy:1560
translate gunmu start_4b654bb0:

    # "第二天早上..."
    "棍母"

# game/script.rpy:1561
translate gunmu start_07bcf6c0:

    # "阳光透过窗帘缝隙照进来。"
    "棍母"

# game/script.rpy:1562
translate gunmu start_f1fae0d3:

    # "形成一道光柱。"
    "棍母"

# game/script.rpy:1564
translate gunmu start_61a5dfb4:

    # "灰尘在光柱中飞舞。"
    "棍母"

# game/script.rpy:1565
translate gunmu start_87b3c88b:

    # "像是微小的星星。"
    "棍母"

# game/script.rpy:1566
translate gunmu start_4221a45f:

    # "缓缓旋转。"
    "棍母"

# game/script.rpy:1568
translate gunmu start_c84916e1:

    # zj "唔…头好痛…"
    zj "棍母"

# game/script.rpy:1569
translate gunmu start_4e2e3a9f:

    # "雨姐先醒了过来。"
    "棍母"

# game/script.rpy:1570
translate gunmu start_16c75e4f:

    # "揉着太阳穴。"
    "棍母"

# game/script.rpy:1572
translate gunmu start_bf999468:

    # "眉头紧皱。"
    "棍母"

# game/script.rpy:1573
translate gunmu start_3f9e1b0a:

    # "宿醉的感觉很糟糕。"
    "棍母"

# game/script.rpy:1575
translate gunmu start_1309ea9e:

    # ANe "私も…我头也好痛…"
    ANe "棍母"

# game/script.rpy:1576
translate gunmu start_5e9d5528:

    # "宁宁也醒了。"
    "棍母"

# game/script.rpy:1577
translate gunmu start_d033716d:

    # "声音沙哑。"
    "棍母"

# game/script.rpy:1579
translate gunmu start_81c35a16:

    # "带着浓浓的睡意。"
    "棍母"

# game/script.rpy:1580
translate gunmu start_f4b5a357:

    # "眼睛还半闭着。"
    "棍母"

# game/script.rpy:1582
translate gunmu start_f36b1c4e:

    # "两人几乎同时醒来。"
    "棍母"

# game/script.rpy:1583
translate gunmu start_d120761f:

    # "然后同时发现了不对劲——"
    "棍母"

# game/script.rpy:1585
translate gunmu start_fdfa2067:

    # zj "？！"
    zj "棍母"

# game/script.rpy:1586
translate gunmu start_79f09e3c:

    # "雨姐睁大眼睛。"
    "棍母"

# game/script.rpy:1587
translate gunmu start_11c132a5:

    # "看着身边的宁宁。"
    "棍母"

# game/script.rpy:1589
translate gunmu start_44ca1a59:

    # ANe "！？"
    ANe "棍母"

# game/script.rpy:1590
translate gunmu start_78c634e5:

    # "宁宁也睁大眼睛。"
    "棍母"

# game/script.rpy:1591
translate gunmu start_54f4ae2c:

    # "看着身边的雨姐。"
    "棍母"

# game/script.rpy:1593
translate gunmu start_e25f1838:

    # "她们都感觉到了身边有人的体温。"
    "棍母"

# game/script.rpy:1594
translate gunmu start_ee423684:

    # "温暖而真实。"
    "棍母"

# game/script.rpy:1595
translate gunmu start_f303e79c:

    # "不是做梦。"
    "棍母"

# game/script.rpy:1597
translate gunmu start_9e159e69:

    # landyh "??????"
    landyh "棍母"

# game/script.rpy:1598
translate gunmu start_1d9f0a70:

    # "两人都僵住了。"
    "棍母"

# game/script.rpy:1599
translate gunmu start_36e722a5:

    # "像两尊雕像。"
    "棍母"

# game/script.rpy:1601
translate gunmu start_9962f1fd:

    # "她们正睡在同一张床上。"
    "棍母"

# game/script.rpy:1602
translate gunmu start_64f735d3:

    # "而且…"
    "棍母"

# game/script.rpy:1603
translate gunmu start_ef2f1f13:

    # "盖着同一条被子。"
    "棍母"

# game/script.rpy:1605
translate gunmu start_3135881c:

    # zj "（我怎么搂着宁宁的腰？！）"
    zj "棍母"

# game/script.rpy:1606
translate gunmu start_a572eec8:

    # "雨姐发现自己的手。"
    "棍母"

# game/script.rpy:1607
translate gunmu start_76bc3b91:

    # "正搭在宁宁腰上。"
    "棍母"

# game/script.rpy:1609
translate gunmu start_070f588f:

    # "隔着薄薄的衣物。"
    "棍母"

# game/script.rpy:1610
translate gunmu start_34cc73b6:

    # "能感觉到身体的曲线。"
    "棍母"

# game/script.rpy:1611
translate gunmu start_d53e3816:

    # "温暖而柔软。"
    "棍母"

# game/script.rpy:1613
translate gunmu start_1166bb9d:

    # ANe "（雨姐的手放在我肚子上？！）"
    ANe "棍母"

# game/script.rpy:1614
translate gunmu start_dabf612c:

    # "宁宁感觉到腹部温暖的压力。"
    "棍母"

# game/script.rpy:1615
translate gunmu start_f2120b6e:

    # "那只手自然地放在那里。"
    "棍母"

# game/script.rpy:1617
translate gunmu start_af9af7a5:

    # "像是已经放了一整夜。"
    "棍母"

# game/script.rpy:1618
translate gunmu start_8ed6dff2:

    # "很温暖，很舒服。"
    "棍母"

# game/script.rpy:1619
translate gunmu start_24bf5346:

    # "但现在很尴尬。"
    "棍母"

# game/script.rpy:1621
translate gunmu start_20b280fe:

    # "空气凝固了三秒钟。"
    "棍母"

# game/script.rpy:1622
translate gunmu start_1d9f0a70_1:

    # "两人都僵住了。"
    "棍母"

# game/script.rpy:1623
translate gunmu start_73888362:

    # "一动不敢动。"
    "棍母"

# game/script.rpy:1625
translate gunmu start_f4396104:

    # landyh "啊啊啊啊啊——！！！"
    landyh "棍母"

# game/script.rpy:1626
translate gunmu start_d934c3d0:

    # "两人同时弹开。"
    "棍母"

# game/script.rpy:1627
translate gunmu start_e0e63571:

    # "滚到了床的两边。"
    "棍母"

# game/script.rpy:1630
translate gunmu start_a39515de:

    # "被子被扯得乱七八糟。"
    "棍母"

# game/script.rpy:1631
translate gunmu start_7a9418c8:

    # "枕头掉在地上。"
    "棍母"

# game/script.rpy:1632
translate gunmu start_64481a89:

    # "场面一片混乱。"
    "棍母"

# game/script.rpy:1634
translate gunmu start_65fbad94:

    # zj "对不起对不起我喝多了！"
    zj "棍母"

# game/script.rpy:1635
translate gunmu start_0878d7b8:

    # "雨姐赶紧道歉。"
    "棍母"

# game/script.rpy:1636
translate gunmu start_a51ad7f9:

    # "脸涨得通红。"
    "棍母"

# game/script.rpy:1638
translate gunmu start_4048d3e1:

    # "像是煮熟的虾。"
    "棍母"

# game/script.rpy:1639
translate gunmu start_914a12c7:

    # "耳朵都红了。"
    "棍母"

# game/script.rpy:1641
translate gunmu start_04c7709a:

    # ANe "沒、没关系！我也喝多了！"
    ANe "棍母"

# game/script.rpy:1642
translate gunmu start_7cbd5e3c:

    # "宁宁也红着脸。"
    "棍母"

# game/script.rpy:1643
translate gunmu start_ea1f6f09:

    # "低着头不敢看雨姐。"
    "棍母"

# game/script.rpy:1645
translate gunmu start_c703f470:

    # "两人红着脸不敢看对方。"
    "棍母"

# game/script.rpy:1646
translate gunmu start_fa669719:

    # "房间里弥漫着尴尬又微妙的气氛。"
    "棍母"

# game/script.rpy:1647
translate gunmu start_68629426:

    # "阳光越来越亮。"
    "棍母"

# game/script.rpy:1649
translate gunmu start_526991d5:

    # "街上的声音开始传来。"
    "棍母"

# game/script.rpy:1650
translate gunmu start_37ebd4f5:

    # "汽车的喇叭。"
    "棍母"

# game/script.rpy:1651
translate gunmu start_0bf6f3c9:

    # "行人的谈话。"
    "棍母"

# game/script.rpy:1656
translate gunmu start_a5a48d17:

    # "突然，周围的一切又开始扭曲。"
    "棍母"

# game/script.rpy:1657
translate gunmu start_dc6978fa:

    # "空气像水面一样波动。"
    "棍母"

# game/script.rpy:1658
translate gunmu start_819a2fce:

    # "景象变得模糊。"
    "棍母"

# game/script.rpy:1660
translate gunmu start_d9926332_1:

    # "神秘人" "made in heaven!!!"
    "神秘人" "棍母"

# game/script.rpy:1661
translate gunmu start_f63daf54:

    # "熟悉的声音再次响起。"
    "棍母"

# game/script.rpy:1662
translate gunmu start_6ebe34cb:

    # "但这次似乎带着某种满足。"
    "棍母"

# game/script.rpy:1664
translate gunmu start_17e17a21:

    # "像是完成了任务。"
    "棍母"

# game/script.rpy:1665
translate gunmu start_2acd9118:

    # "语气里有一丝得意。"
    "棍母"

# game/script.rpy:1670
translate gunmu start_2346c492:

    # "头好痛..."
    "棍母"

# game/script.rpy:1671
translate gunmu start_a14de61e:

    # "雨姐捂住头。"
    "棍母"

# game/script.rpy:1672
translate gunmu start_2b56192e:

    # "宿醉的感觉还没完全消失。"
    "棍母"

# game/script.rpy:1674
translate gunmu start_1ae15188:

    # zj "呃...这是哪儿..."
    zj "棍母"

# game/script.rpy:1675
translate gunmu start_7d87a861:

    # "她睁开眼睛。"
    "棍母"

# game/script.rpy:1676
translate gunmu start_bb1890a4:

    # "发现自己在硬木地板上。"
    "棍母"

# game/script.rpy:1678
translate gunmu start_76c69219:

    # "冰冷而坚硬。"
    "棍母"

# game/script.rpy:1679
translate gunmu start_8e70288f:

    # "和酒店的床完全不一样。"
    "棍母"

# game/script.rpy:1681
translate gunmu start_ac992158:

    # ANe "私も...我也..."
    ANe "棍母"

# game/script.rpy:1682
translate gunmu start_5e9d5528_1:

    # "宁宁也醒了。"
    "棍母"

# game/script.rpy:1683
translate gunmu start_e60c4333:

    # "两人同时睁开眼睛。"
    "棍母"

# game/script.rpy:1685
translate gunmu start_fd87b4dc:

    # "发现正躺在图书馆的地板上。"
    "棍母"

# game/script.rpy:1686
translate gunmu start_68db38c4:

    # "阳光还是那样斜照进来。"
    "棍母"

# game/script.rpy:1687
translate gunmu start_4ba84255:

    # "但位置已经不同了。"
    "棍母"

# game/script.rpy:1689
translate gunmu start_b57ef2cb:

    # "更低了，像是下午。"
    "棍母"

# game/script.rpy:1690
translate gunmu start_6f7b9fe2:

    # "时间似乎过去了一些。"
    "棍母"

# game/script.rpy:1692
translate gunmu start_4ba4faaf:

    # zj "等等，我们不是..."
    zj "棍母"

# game/script.rpy:1693
translate gunmu start_c4265f57:

    # "雨姐坐起来。"
    "棍母"

# game/script.rpy:1694
translate gunmu start_00fde3ae:

    # "环顾四周。"
    "棍母"

# game/script.rpy:1696
translate gunmu start_0847d660:

    # ANe "在酒店吗？"
    ANe "棍母"

# game/script.rpy:1697
translate gunmu start_378cd75d:

    # "两人迅速坐起身来。"
    "棍母"

# game/script.rpy:1698
translate gunmu start_dbe9ebdd:

    # "动作同步。"
    "棍母"

# game/script.rpy:1700
translate gunmu start_00fde3ae_1:

    # "环顾四周。"
    "棍母"

# game/script.rpy:1701
translate gunmu start_23e07838:

    # "熟悉的书架。"
    "棍母"

# game/script.rpy:1702
translate gunmu start_0268ce86:

    # "熟悉的桌子。"
    "棍母"

# game/script.rpy:1704
translate gunmu start_ae547ce8:

    # "一切都和离开时一样。"
    "棍母"

# game/script.rpy:1705
translate gunmu start_50377207:

    # "就像什么都没发生过。"
    "棍母"

# game/script.rpy:1707
translate gunmu start_8a1b4e3c:

    # zj "我们回来了？"
    zj "棍母"

# game/script.rpy:1708
translate gunmu start_f3e5a8ae:

    # "雨姐问。"
    "棍母"

# game/script.rpy:1709
translate gunmu start_9e81d84f:

    # "声音里充满疑惑。"
    "棍母"

# game/script.rpy:1711
translate gunmu start_41399050:

    # ANe "回到2026年了？"
    ANe "棍母"

# game/script.rpy:1712
translate gunmu start_dba15652:

    # "宁宁看了看自己的衣服。"
    "棍母"

# game/script.rpy:1713
translate gunmu start_411024e6:

    # "还是穿越前的那一身。"
    "棍母"

# game/script.rpy:1715
translate gunmu start_ba28bf75:

    # "校服整齐。"
    "棍母"

# game/script.rpy:1716
translate gunmu start_4973657b:

    # "没有酒味。"
    "棍母"

# game/script.rpy:1717
translate gunmu start_e1210fab:

    # "就像刚洗过一样。"
    "棍母"

# game/script.rpy:1719
translate gunmu start_4126adae:

    # "突然，雨姐的目光落在了图书馆角落的桌子上。"
    "棍母"

# game/script.rpy:1720
translate gunmu start_e18838dc:

    # "等等...那个是..."
    "棍母"

# game/script.rpy:1721
translate gunmu start_c3cac56c:

    # "她指着。"
    "棍母"

# game/script.rpy:1723
translate gunmu start_9166a227:

    # "两人看到了桌上那个熟悉的东西 - 起爆器。"
    "棍母"

# game/script.rpy:1724
translate gunmu start_77f2a4b1:

    # "它就安静地躺在那里。"
    "棍母"

# game/script.rpy:1725
translate gunmu start_62c83bbe:

    # "好像从未被移动过。"
    "棍母"

# game/script.rpy:1727
translate gunmu start_74209e38:

    # "表面反射着阳光。"
    "棍母"

# game/script.rpy:1728
translate gunmu start_3a53c12c:

    # "闪着金属的光泽。"
    "棍母"

# game/script.rpy:1730
translate gunmu start_56150592:

    # qbq "我又来了兄弟们"
    qbq "棍母"

# game/script.rpy:1731
translate gunmu start_6e4ddb3b:

    # "起爆器的声音响起。"
    "棍母"

# game/script.rpy:1732
translate gunmu start_ad68d281:

    # "在安静的图书馆里格外清晰。"
    "棍母"

# game/script.rpy:1734
translate gunmu start_0ed1171b:

    # "带着一丝戏谑。"
    "棍母"

# game/script.rpy:1735
translate gunmu start_d35ad3a1:

    # "像是在嘲笑什么。"
    "棍母"

# game/script.rpy:1737
translate gunmu start_e5bab837:

    # ANe "啊！"
    ANe "棍母"

# game/script.rpy:1738
translate gunmu start_5369af90:

    # "宁宁的脸一下子红了。"
    "棍母"

# game/script.rpy:1739
translate gunmu start_d54b16da:

    # "想起了之前的事。"
    "棍母"

# game/script.rpy:1741
translate gunmu start_7572e77f:

    # "羞耻感涌上来。"
    "棍母"

# game/script.rpy:1742
translate gunmu start_c2868234:

    # "脸热得发烫。"
    "棍母"

# game/script.rpy:1744
translate gunmu start_8166f2c4:

    # zj "所以...那一切是..."
    zj "棍母"

# game/script.rpy:1745
translate gunmu start_d7648328:

    # "雨姐思考着。"
    "棍母"

# game/script.rpy:1746
translate gunmu start_8b42b27e:

    # "试图理清头绪。"
    "棍母"

# game/script.rpy:1748
translate gunmu start_51a9a594:

    # ANe "梦吗？"
    ANe "棍母"

# game/script.rpy:1749
translate gunmu start_e893ab40:

    # "宁宁小声问。"
    "棍母"

# game/script.rpy:1750
translate gunmu start_55f44f76:

    # "但自己也不太相信。"
    "棍母"

# game/script.rpy:1752
translate gunmu start_dc48e037:

    # "太真实了。"
    "棍母"

# game/script.rpy:1753
translate gunmu start_2ecfeb0e:

    # "每一个细节都清晰。"
    "棍母"

# game/script.rpy:1754
translate gunmu start_37bbbfa1:

    # "不像是梦。"
    "棍母"

# game/script.rpy:1756
translate gunmu start_298ea91c:

    # "但雨姐摸到了口袋里的东西。"
    "棍母"

# game/script.rpy:1757
translate gunmu start_5b3ffe79:

    # "一个硬硬的方块。"
    "棍母"

# game/script.rpy:1758
translate gunmu start_696643bb:

    # "有棱有角。"
    "棍母"

# game/script.rpy:1760
translate gunmu start_d1033a88_1:

    # zj "这是..."
    zj "棍母"

# game/script.rpy:1761
translate gunmu start_6cffea7e:

    # "她掏出了一个钱包。"
    "棍母"

# game/script.rpy:1762
translate gunmu start_e5f80adf:

    # "正是昨晚在酒店的那个。"
    "棍母"

# game/script.rpy:1764
translate gunmu start_c1b11052:

    # "皮质已经有些磨损。"
    "棍母"

# game/script.rpy:1765
translate gunmu start_60cdf1e1:

    # "但确实是那个钱包。"
    "棍母"

# game/script.rpy:1766
translate gunmu start_1f8c2486:

    # "粉色的。"
    "棍母"

# game/script.rpy:1768
translate gunmu start_8e02441a:

    # "边缘发白。"
    "棍母"

# game/script.rpy:1769
translate gunmu start_d595fdf7:

    # "看起来用了很久。"
    "棍母"

# game/script.rpy:1771
translate gunmu start_d91d9c2f:

    # ANe "那...那是虎哥的钱包？"
    ANe "棍母"

# game/script.rpy:1772
translate gunmu start_4d662d27:

    # "宁宁惊讶地捂住嘴。"
    "棍母"

# game/script.rpy:1773
translate gunmu start_9a340c44:

    # "眼睛瞪大。"
    "棍母"

# game/script.rpy:1775
translate gunmu start_91eafb54:

    # zj "上面还有张纸条..."
    zj "棍母"

# game/script.rpy:1776
translate gunmu start_1d924595:

    # "雨姐打开钱包。"
    "棍母"

# game/script.rpy:1777
translate gunmu start_cf708424:

    # "里面确实有一张纸条。"
    "棍母"

# game/script.rpy:1779
translate gunmu start_66ef5fcb:

    # "折叠整齐。"
    "棍母"

# game/script.rpy:1780
translate gunmu start_10d65ef1:

    # "像是精心保存的。"
    "棍母"

# game/script.rpy:1782
translate gunmu start_e334a1df:

    # "她小心翼翼地展开。"
    "棍母"

# game/script.rpy:1783
translate gunmu start_9175dcba:

    # "纸张有些粗糙。"
    "棍母"

# game/script.rpy:1784
translate gunmu start_a35e71e4:

    # "像是从笔记本上撕下来的。"
    "棍母"

# game/script.rpy:1786
translate gunmu start_26182aad:

    # "上面用歪歪扭扭的字写着："
    "棍母"

# game/script.rpy:1787
translate gunmu start_b08a35e2:

    # "『雨姐，宁宁妹子，有事儿还来沈阳找我！——虎哥 2017.7.21』"
    "棍母"

# game/script.rpy:1789
translate gunmu start_450eac33:

    # "笔画很重。"
    "棍母"

# game/script.rpy:1790
translate gunmu start_a8ed876a:

    # "有些字还写错了。"
    "棍母"

# game/script.rpy:1791
translate gunmu start_cfcd6861:

    # "但能看懂意思。"
    "棍母"

# game/script.rpy:1793
translate gunmu start_9c71cc5f:

    # ANe "7月21日...0721..."
    ANe "棍母"

# game/script.rpy:1794
translate gunmu start_078f57a0:

    # "宁宁喃喃自语。"
    "棍母"

# game/script.rpy:1795
translate gunmu start_53170173:

    # "想起了那个日期。"
    "棍母"

# game/script.rpy:1797
translate gunmu start_92dafe5b:

    # "那个特殊的数字。"
    "棍母"

# game/script.rpy:1798
translate gunmu start_9ff024ad:

    # "原来是这样。"
    "棍母"

# game/script.rpy:1800
translate gunmu start_69fca387:

    # zj "所以昨天真的是..."
    zj "棍母"

# game/script.rpy:1801
translate gunmu start_4afabcf0:

    # "雨姐也明白了。"
    "棍母"

# game/script.rpy:1802
translate gunmu start_f9418595:

    # "两人对视一眼。"
    "棍母"

# game/script.rpy:1804
translate gunmu start_2f2c188d:

    # "突然明白了什么。"
    "棍母"

# game/script.rpy:1805
translate gunmu start_94986c80:

    # "眼神交流。"
    "棍母"

# game/script.rpy:1806
translate gunmu start_35c19334:

    # "不用说话就懂了。"
    "棍母"

# game/script.rpy:1808
translate gunmu start_94b41cfa:

    # "这不是梦，是真的穿越了时空。"
    "棍母"

# game/script.rpy:1809
translate gunmu start_a135cb8e:

    # "我们真的回到了过去。"
    "棍母"

# game/script.rpy:1810
translate gunmu start_a864dedb:

    # "遇到了虎哥，经历了那些事。"
    "棍母"

# game/script.rpy:1812
translate gunmu start_c99350dc:

    # zj "等等，宁宁，你的那个..."
    zj "棍母"

# game/script.rpy:1813
translate gunmu start_e36439f1:

    # "雨姐指向桌子上的起爆器。"
    "棍母"

# game/script.rpy:1814
translate gunmu start_adffd940:

    # "嘴角带着一丝坏笑。"
    "棍母"

# game/script.rpy:1816
translate gunmu start_088a3ca9:

    # "故意拉长声音。"
    "棍母"

# game/script.rpy:1817
translate gunmu start_a67b1b36:

    # "想逗逗她。"
    "棍母"

# game/script.rpy:1819
translate gunmu start_ad3deff7:

    # ANe "(脸突然红了) やめて！别说了！"
    ANe "棍母"

# game/script.rpy:1820
translate gunmu start_b5694672:

    # "宁宁双手捂住脸。"
    "棍母"

# game/script.rpy:1821
translate gunmu start_9fbc5ff8:

    # "耳根都红了。"
    "棍母"

# game/script.rpy:1823
translate gunmu start_f31ddcdc:

    # "像是要冒烟。"
    "棍母"

# game/script.rpy:1824
translate gunmu start_87bf26de:

    # "羞得不行。"
    "棍母"

# game/script.rpy:1826
translate gunmu start_794708f9:

    # zj "嘿嘿..."
    zj "棍母"

# game/script.rpy:1827
translate gunmu start_aadc0d12:

    # "雨姐笑了。"
    "棍母"

# game/script.rpy:1828
translate gunmu start_a8401150:

    # "气氛变得轻松了一些。"
    "棍母"

# game/script.rpy:1830
translate gunmu start_f86f9cdd:

    # "尴尬慢慢消散。"
    "棍母"

# game/script.rpy:1831
translate gunmu start_c1dccb80:

    # "两人之间的关系似乎有了一些微妙的变化。"
    "棍母"

# game/script.rpy:1834
translate gunmu start_86bef53e:

    # "突然，图书馆的门开了。"
    "棍母"

# game/script.rpy:1835
translate gunmu start_c4a9825f:

    # "吱呀一声。"
    "棍母"

# game/script.rpy:1837
translate gunmu start_3e4b375a:

    # "一阵风吹了进来。"
    "棍母"

# game/script.rpy:1838
translate gunmu start_4cc83e19:

    # "带来外面青草的气息。"
    "棍母"

# game/script.rpy:1839
translate gunmu start_cab8a70a:

    # "还有阳光的味道。"
    "棍母"

# game/script.rpy:1841
translate gunmu start_d960e894:

    # "神秘声音" "时间恢复正轨。Made in Heaven的效果结束了。"
    "神秘声音" "棍母"

# game/script.rpy:1842
translate gunmu start_f0b015df:

    # "声音像是从很远的地方传来。"
    "棍母"

# game/script.rpy:1843
translate gunmu start_132ad963:

    # "又像是在耳边低语。"
    "棍母"

# game/script.rpy:1845
translate gunmu start_2f9be9fb:

    # "分不清方向。"
    "棍母"

# game/script.rpy:1846
translate gunmu start_9360996c:

    # "空灵而神秘。"
    "棍母"

# game/script.rpy:1848
translate gunmu start_38233c8d:

    # zj "谁？！"
    zj "棍母"

# game/script.rpy:1849
translate gunmu start_498bbaf5:

    # "雨姐站起来。"
    "棍母"

# game/script.rpy:1850
translate gunmu start_509a35ae:

    # "朝门口看去。"
    "棍母"

# game/script.rpy:1852
translate gunmu start_141172b0:

    # "但图书馆里已经空无一人。"
    "棍母"

# game/script.rpy:1853
translate gunmu start_65a58dc3:

    # "只有她们两个。"
    "棍母"

# game/script.rpy:1854
translate gunmu start_e1b6139b:

    # "门自己关上了。"
    "棍母"

# game/script.rpy:1857
translate gunmu start_a854cf87:

    # "轻轻合拢。"
    "棍母"

# game/script.rpy:1858
translate gunmu start_2e16ee1c:

    # "仿佛从未开过。"
    "棍母"

# game/script.rpy:1860
translate gunmu start_b6dfafee:

    # ANe "雨姐..."
    ANe "棍母"

# game/script.rpy:1861
translate gunmu start_db713bdb:

    # "宁宁轻声说。"
    "棍母"

# game/script.rpy:1862
translate gunmu start_bc60489b:

    # "声音还有些颤抖。"
    "棍母"

# game/script.rpy:1864
translate gunmu start_949a739b:

    # "带着不确定。"
    "棍母"

# game/script.rpy:1865
translate gunmu start_5e52b114:

    # "像是想问什么。"
    "棍母"

# game/script.rpy:1867
translate gunmu start_0e3a6801:

    # zj "嗯？"
    zj "棍母"

# game/script.rpy:1868
translate gunmu start_076c32f6:

    # "雨姐看向她。"
    "棍母"

# game/script.rpy:1869
translate gunmu start_c8ca4508:

    # "表情柔和。"
    "棍母"

# game/script.rpy:1871
translate gunmu start_28f6567c:

    # ANe "今天的事...请保密..."
    ANe "棍母"

# game/script.rpy:1872
translate gunmu start_8242b3a9:

    # "宁宁低下头。"
    "棍母"

# game/script.rpy:1873
translate gunmu start_66e71003:

    # "手指绞在一起。"
    "棍母"

# game/script.rpy:1875
translate gunmu start_d9340678:

    # "非常用力。"
    "棍母"

# game/script.rpy:1876
translate gunmu start_5d354235:

    # "指节都发白了。"
    "棍母"

# game/script.rpy:1878
translate gunmu start_fa3867e5:

    # zj "(坏笑) 那得看你表现咯~"
    zj "棍母"

# game/script.rpy:1879
translate gunmu start_79a0d2eb:

    # "雨姐故意逗她。"
    "棍母"

# game/script.rpy:1880
translate gunmu start_94930487:

    # "拖着长音。"
    "棍母"

# game/script.rpy:1882
translate gunmu start_af2b44e4:

    # "想看看她的反应。"
    "棍母"

# game/script.rpy:1883
translate gunmu start_1cd9fa7f:

    # "觉得很有趣。"
    "棍母"

# game/script.rpy:1885
translate gunmu start_f152bd74:

    # ANe "えっ？！"
    ANe "棍母"

# game/script.rpy:1886
translate gunmu start_6c0c77c3:

    # "宁宁抬起头。"
    "棍母"

# game/script.rpy:1887
translate gunmu start_20cb63ae:

    # "眼睛瞪得圆圆的。"
    "棍母"

# game/script.rpy:1889
translate gunmu start_4904f7f7:

    # "像是受惊的小动物。"
    "棍母"

# game/script.rpy:1890
translate gunmu start_3d7457f7:

    # "不知道雨姐什么意思。"
    "棍母"

# game/script.rpy:1892
translate gunmu start_96acc179:

    # "图书馆里。"
    "棍母"

# game/script.rpy:1893
translate gunmu start_eaaf3eda:

    # "两人的声音渐渐远去..."
    "棍母"

# game/script.rpy:1894
translate gunmu start_f6d0d853:

    # "被书海吸收。"
    "棍母"

# game/script.rpy:1896
translate gunmu start_948aefb4:

    # "阳光慢慢移动。"
    "棍母"

# game/script.rpy:1897
translate gunmu start_54fde678:

    # "照在桌上的起爆器上。"
    "棍母"

# game/script.rpy:1898
translate gunmu start_7ea97297:

    # "给它镀上了一层金色。"
    "棍母"

# game/script.rpy:1900
translate gunmu start_e33aa8a6:

    # "像是珍贵的文物。"
    "棍母"

# game/script.rpy:1901
translate gunmu start_db6d7de2:

    # "在阳光下闪闪发光。"
    "棍母"

# game/script.rpy:1906
translate gunmu start_166e7d00:

    # "完"
    "棍母"

# game/script.rpy:1907
translate gunmu start_b09e5a10:

    # "最后一个字落下。"
    "棍母"

# game/script.rpy:1908
translate gunmu start_cda37e38:

    # "故事告一段落。"
    "棍母"

# game/script.rpy:1910
translate gunmu start_863f1a3a:

    # "p.s.这是demo版。"
    "棍母"

# game/script.rpy:1911
translate gunmu start_91b61662:

    # "可能有数不清的错误。"
    "棍母"

# game/script.rpy:1912
translate gunmu start_b0a1e824:

    # "但至少，这是一段难忘的经历。"
    "棍母"

# game/script.rpy:1914
translate gunmu start_db9981ee:

    # "一段奇妙的冒险。"
    "棍母"

# game/script.rpy:1915
translate gunmu start_29618139:

    # "一次跨越时空的相遇。"
    "棍母"

# game/script.rpy:1917
translate gunmu start_1928d8ac:

    # "在图书馆的午后。"
    "棍母"

# game/script.rpy:1918
translate gunmu start_495e2f07:

    # "在沈阳大街的喧闹中。"
    "棍母"

# game/script.rpy:1919
translate gunmu start_0585058e:

    # "在KTV的歌声里。"
    "棍母"

# game/script.rpy:1921
translate gunmu start_ff17f034:

    # "这一切都会成为回忆。"
    "棍母"

# game/script.rpy:1922
translate gunmu start_00ab9cf6:

    # "珍藏心底。"
    "棍母"

# game/script.rpy:1923
translate gunmu start_48984c72:

    # "不会忘记。"
    "棍母"

# game/script.rpy:1925
translate gunmu start_1c224d10:

    # "感谢游玩。"
    "棍母"

# game/script.rpy:1926
translate gunmu start_fac4b0ae:

    # "期待正式版的到来。"
    "棍母"

# game/script.rpy:1927
translate gunmu start_72bbad2f:

    # "再见。"
    "棍母"

