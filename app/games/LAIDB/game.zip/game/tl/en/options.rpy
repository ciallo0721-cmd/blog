﻿# TODO: Translation updated at 2026-02-07 14:25

translate en strings:

    # game/options.rpy:14
    old "来东北指定没有你好果子吃"
    new ""

    # game/options.rpy:30
    old "来东北指定没有你好果子吃\n\n作者：ciarchiveo0721-cmd\n\n感谢所有支持和帮助过我的人们！\n\n祝你们...飞起来!!!!\n\n...................\n\nfor more information, visit:\n\n{a=https://ciarchiveo0721-cmd.github.io}网站{/a}\n\nP.S:在2026年2月7日这一天,这些对话达到了惊人的1294句,我觉得这是个不错的里程碑,所以就把它放在了这里,哈哈哈\n\n"
    new ""

